'use strict';
angular.module('LocalStorageModule').value('prefix', 'gkClientIndex');
angular.module('gkClientFrame',['gettext','GKCommon','gkClientIndex.filters','gkClientIndex.directives','gkClientIndex.services','gkClientFrame.controllers','LocalStorageModule','ngSanitize','gk.window'])
    .run(['GKI18n',function (GKI18n) {
        GKI18n.setLocal();
    }])
