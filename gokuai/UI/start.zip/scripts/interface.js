﻿var gkClientInterface = {
    //判断是否是新东方的客户端
    isXDFClient:function(){
        var configInfo = this.getConfigInfo();
        return configInfo && configInfo['source'] && configInfo['source'] == 'xdf';
    },
    isGKSyncClient:function(){
        var sync = this.getUserAgent()[0] || '';
        return sync.toLowerCase() == 'gk_sync';
    },
    isZZClient:function(){
        var configInfo = this.getConfigInfo();
        return configInfo && configInfo['expand'] && configInfo['expand'] == 1;
    },
    isShOnlineClient:function(){
        var configInfo = this.getConfigInfo();
        return configInfo && configInfo['source'] == 'shonline';
    },
    isYoufuClient:function(){
        var configInfo = this.getConfigInfo();
        return configInfo && configInfo['source'] == 'youfu';
    },
    isCustomClient:function(){
        var configInfo = this.getConfigInfo();
        return configInfo && configInfo['source'];
    },
    getWebContext:function(key,isTop){
        if(!isTop) {
            if (key && key.length > 0) {
                return WEB_CONSTANT[key];
            }
            else {
                return WEB_CONSTANT;
            }
        }else{
            var webConstant = {};
            try{
                webConstant = window.WEB_CONSTANT ? window.WEB_CONSTANT : window.parent.WEB_CONSTANT ? window.parent.WEB_CONSTANT: window.top.WEB_CONSTANT;
            }catch (e){
                webConstant = {};
            }

            if (key && key.length > 0) {
                return webConstant[key];
            }
            else {
                return  webConstant;
            }
        }
    },
    getAjaxError: function (request, textStatus, errorThrown) {
        var error = {
            code: 0,
            msg: '出错了'
        };
        if (request.responseText) {
            var result = JSON.parse(request.responseText);
            jQuery.extend(error, {
                code: result.error_code,
                msg: result.error_msg || request.responseText
            })
        } else {
            error.code = request.status;
            if (textStatus === 'timeout') {
                error.msg = '网络连接超时';
            } else {
                switch (request.status) {
                    case 0:
                    case 404:
                        error.msg = '网络未连接或当前网络不支持HTTPS安全连接，请在“设置”中关闭HTTPS安全连接后重试';
                        break;
                    case 401:
                        error.msg = '网络连接超时或当前网络不支持HTTPS安全连接，请在“设置”中关闭HTTPS安全连接后重试';
                        break;
                    case 501:
                    case 502:
                        error.msg = '服务器繁忙, 请稍候重试';
                        break;
                    case 503:
                    case 504:
                        error.msg = '因您的操作太过频繁, 操作已被取消';
                        break;
                    default:
                        error.msg = request.statusText;
                        break;
                }
            }
        }
        return error;
    },
    /**
     * 处理异常
     * @param e
     */

    _handleException: function (e) {
        throw new Error(e.name + ":" + e.message);
    },
    isFunc:function(func){
        return typeof func === 'function';
    },
    isFuncAvaiable:function(func){
        return  typeof gkClient !== 'undefined' && typeof gkClient[func] !== 'undefined';
    },
    isWebFengCloud:function(){
        return !this.isGKSyncClient();
    },
    invoke:function(method,param,callback){
        if(this.isFuncAvaiable(method)){
            if(typeof callback === 'function'){
                gkClient[method](JSON.stringify(param),function(re){
                    re = typeof re ==='object'?re:JSON.parse(re);
                    callback(re);
                });
            }else{
                var re = gkClient[method](JSON.stringify(param));
                if(!re){
                   return '';
                }else{
                   return JSON.parse(re);
                }
            }
        }
    },
    getClipboardData:function(){
        if(!this.isFuncAvaiable('gGetClipboardData')){
            return '';
        }
        var re = gkClient.gGetClipboardData();
        if(!re){
            return '';
        }else{
            return JSON.parse(re);
        }
    },
    setDragStart:function(param){
        if(!this.isFuncAvaiable('gSetDragStart')){
            return;
        }
        gkClient.gSetDragStart(JSON.stringify(param));
    },
    setDragEnd:function(param){
        if(!this.isFuncAvaiable('gSetDragEnd')){
            return;
        }
        gkClient.gSetDragEnd(JSON.stringify(param));
    },
    upgradeClient:function(){
        if(!this.isFuncAvaiable('gUpgradeClient')){
            return;
        }
        gkClient.gUpgradeClient();
    },
    needLoading:function(){
        if(!this.isFuncAvaiable('gGetNeedloading')){
            return 0;
        }
        return gkClient.gGetNeedloading();
    },
    getDownloadUrl:function(param){
        if(!this.isFuncAvaiable('gGetDownloadUrl')){
            return '';
        }
        var re =  gkClient.gGetDownloadUrl(JSON.stringify(param));
        if(!re){
            return '';
        }else{
            return JSON.parse(re);
        }
    },
    getCachePath:function(param){
        if(!this.isFuncAvaiable('gGetCachePath')){
            return '';
        }
        var re =  gkClient.gGetCachePath(JSON.stringify(param));
        if(!re){
            return '';
        }else{
            return JSON.parse(re);
        }
    },
    getEnt:function(param){
        if(!this.isFuncAvaiable('gGetEnt')){
            if(this.isWebFengCloud()){
                var ent = '';
                for(var i=0;i<gkClientInterface.getWebContext('ent',true).length;i++){
                    var v = gkClientInterface.getWebContext('ent',true)[i];
                    if(v.ent_id == param.entid){
                        ent =  v;
                        break;
                    }
                }
               if(ent){
                   $.extend(ent,{
                       entid:ent.ent_id,
                       entname:ent.ent_name
                   });
               }
                return ent;

            }else{
               return '';
            }
        }else{
            var re =  gkClient.gGetEnt(JSON.stringify(param));
            if(!re){
                return '';
            }else{
                return JSON.parse(re);
            }
        }

    },
    removeMember:function(param){
        if(!this.isFuncAvaiable('gRemoveMember')){
            return;
        }
        gkClient.gRemoveMember(JSON.stringify(param));
    },
    editMember:function(param){
        if(!this.isFuncAvaiable('gEditMember')){
            return;
        }
        gkClient.gEditMember(JSON.stringify(param));
    },
    getChatMessage:function(param,callback){
        var _self = this;
        if(this.isWebFengCloud()){
            var serverParam = {
                protocol:gkClientInterface.getWebContext('chatServer',true).protocol,
                host:gkClientInterface.getWebContext('chatServer',true).host,
                port:gkClientInterface.getWebContext('chatServer',true).port
            }
            var serverQueryString = $.param(serverParam);
            if(param.before == 0){
                var param = {
                    time:param.dateline,
                    token: gkClientInterface.getWebContext('user',true).token
                }
                gkClientInterface.api_getMessage(param,function(data){
                    var msgObj = {
                        list: data.reverse()
                    };
                    _self.isFunc(callback) && callback(msgObj);
                });
            }else {
                var param = {
                    receiver: param.receiver,
                    limit: param.count,
                    time: param.dateline,
                    token: gkClientInterface.getWebContext('user',true).token,
                    type:param.type
                }

                jQuery.ajax({
                    url: '/chat/search-message?' + serverQueryString,
                    type: 'GET',
                    data: param,
                    success: function (data) {
                        var msgObj = {
                            list: data.reverse()
                        };
                        _self.isFunc(callback) && callback(msgObj);
                    },
                    error: function (data) {
                        _self.isFunc(callback)&&callback(data);
                    }
                });
            }
        }else{
            if(!this.isFuncAvaiable('gGetMessage')){
                return '';
            }
            gkClient.gGetMessage(JSON.stringify(param),function(re){
                re = typeof re ==='object'?re:JSON.parse(re);
                if(typeof callback === 'function'){
                    callback(re);
                }
            });
        }
    },
    postChatMessage:function(param,callback){
        if(this.isWebFengCloud()){
            var params = {
                protocol:gkClientInterface.getWebContext('chatServer',true).protocol,
                host:gkClientInterface.getWebContext('chatServer',true).host,
                port:gkClientInterface.getWebContext('chatServer',true).port,
                token:gkClientInterface.getWebContext('user',true).token
            }
            var serverQueryString = $.param(params);
            jQuery.ajax({
                url:'/chat/post-message?' + serverQueryString,
                type: 'POST',
                data: param,
                success: function(re){
                    re = typeof re === 'object' ? re : JSON.parse(re);
                    if (typeof callback === 'function') {
                        callback(re);
                    }
                },
                error: function(re){
                    re = typeof re === 'object' ? re : JSON.parse(re);
                    re.error = true;
                    if (typeof callback === 'function') {
                        callback(re);
                    }
                }
            });
        }else {
            if (!this.isFuncAvaiable('gSendMessage')) {
                return;
            }
            gkClient.gSendMessage(JSON.stringify(param), function (re) {
                re = typeof re === 'object' ? re : JSON.parse(re);
                if (typeof callback === 'function') {
                    callback(re);
                }
            });
        }
    },
    getChateState:function(){
        if(!this.isFuncAvaiable('gGetMessageUpdate')){
            return '';
        }
        var re = gkClient.gGetMessageUpdate();
        if(!re){
            return '';
        }else{
            return JSON.parse(re);
        }
    },
    openLaunchpad:function(param){
        if(!this.isFuncAvaiable('gShowLaunchpad')){
            return;
        }
        return gkClient.gShowLaunchpad(JSON.stringify(param));
    },
    openPath:function(param){
        if(!this.isFuncAvaiable('gSelectWebPathDlg')){
            return;
        }
        return gkClient.gSelectWebPathDlg(JSON.stringify(param));
    },
    clearMessage:function(){
        if(!this.isFuncAvaiable('gClearMessage')){
            return;
        }
        return gkClient.gClearMessage();
    },
    getOrgMebersByPage:function(param){
          if(!this.isFuncAvaiable('gGetMembers')){
              return '';
          }
          var re = gkClient.gGetMembers(JSON.stringify(param));
          if(!re){
            return '';
          }
          return JSON.parse(re);
    },
    getOrgMembers:function(param){
        if(!this.isFuncAvaiable('gGetOrgMembers')){
            return '';
        }
        var re = gkClient.gGetOrgMembers(JSON.stringify(param));
        if(!re){
            return '';
        }
        return JSON.parse(re);
    },
    setWindowTop:function(){
        if(!this.isFuncAvaiable('gSetForegroundWindow')){
            return;
        }

        gkClient.gSetForegroundWindow();
    },
    getWindow:function(param){
        if(!this.isFuncAvaiable('gGetWindow')){
            return null;
        }
        return gkClient.gGetWindow(JSON.stringify(param));
    },
    getNetworkStatus:function(){
        if(!this.isFuncAvaiable('gGetNetworkStatus')){
            return 1;
        }
        return gkClient.gGetNetworkStatus();
    },
    checkFileCache:function(filehash){
        if(!this.isFuncAvaiable('gCheckFileCache')){
            return 0;
        }
        return Number(gkClient.gCheckFileCache(JSON.stringify({filehash:filehash})));
    },
    getMount:function(params){
        if(!this.isFuncAvaiable('gGetMountInfo')){
            return '';
        }
        var re = gkClient.gGetMountInfo(JSON.stringify(params));
        if(re){
            return JSON.parse(re);
        }else{
            return '';
        }
    },
     getMountPath:function(rootMountId,subMountId){
         if(!this.isFuncAvaiable('gGetRootMountPath')){
	     return '';
	 }
      var param = {
          rootmountid:rootMountId,
          submountid:subMountId
      }
      var re = gkClient.gGetRootMountPath(JSON.stringify(param));
        if(re){
            return JSON.parse(re).list;
        }else{
            return '';
        }
    },
    revert:function(params,callback){

        var _self = this;
        if(!this.isFuncAvaiable('gRevert')){
                if(this.isWebFengCloud()){

                    jQuery.ajax({
                        type: 'POST',
                        url: gkClientInterface.getApiHost() + '/1/file/revert',
                        dataType: 'json',
                        data: {
                            mount_id:params.mountid,
                            fullpath:params.fullpath,
                            version:params.version
                        },
                        success:function(data){
                            _self.isFunc(callback)&&callback(data);
                        },
                        error:function(request, textStatus, errorThrown){
                            var error = _self.getAjaxError(request, textStatus, errorThrown);
                            _self.isFunc(callback)&&callback({
                                error:1,
                                message:error.msg
                            });
                        }
                    });
                }else{
                    return;
                }

        }else {
            gkClient.gRevert(JSON.stringify(params), function (re) {
                re = typeof re === 'object' ? re : JSON.parse(re);
                if (typeof callback === 'function') {
                    callback(re);
                }
            });
        }
    },
    openAbout:function(){
        try {
            if(!this.isFuncAvaiable('gAbout')){
                if(this.isWebFengCloud()){
                    window.open('/about');
                }
            }else{
                return gkClient.gAbout();
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    getOauthKey:function(){
        try {
            if(!this.isFuncAvaiable('gOAuthKey')){
                return '';
            }
            return gkClient.gOAuthKey();
        } catch (e) {
            this._handleException(e);
        }
    },
    loginByKey:function(param){
        try {
            if(!this.isFuncAvaiable('gLoginByKey')){
                return;
            }
            gkClient.gLoginByKey(param);
        } catch (e) {
            this._handleException(e);
        }
    },
    selectPhotoPath:function(params){
        try {
            if(!this.isFuncAvaiable('gGetUserImagePath')){
                return '';
            }
            return gkClient.gGetUserImagePath();
        } catch (e) {
            this._handleException(e);
        }
    },
    setUserInfo:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gSetUserInfo')){
                return;
            }
            gkClient.gSetUserInfo(JSON.stringify(params),function(re){
                re = typeof re ==='object'?re:JSON.parse(re);
                if(typeof callback === 'function'){
                    callback(re);
                }
            });
        } catch (e) {
            this._handleException(e);
        }
    },
    getOpenWithMenu:function(param){
        try {
            if(!this.isFuncAvaiable('gGetOpenWithMenu')){
                return {};
            }
            var re = gkClient.gGetOpenWithMenu(JSON.stringify(param));
            return JSON.parse(re);
        } catch (e) {
            this._handleException(e);
        }
    },
    copyToClipboard:function(text){
        try {
            if(!this.isFuncAvaiable('gSetClipboardData')){
                return;
            }
            gkClient.gSetClipboardData(text);
        } catch (e) {
            this._handleException(e);
        }
    },
    setFilePublic:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gPublic')){
                return;
            }
            gkClient.gPublic(JSON.stringify(params),function(re){
                re = typeof re ==='object'?re:JSON.parse(re);
                if(typeof callback === 'function'){
                    callback(re);
                }
            });
        } catch (e) {
            this._handleException(e);
        }
    },
    renameSmartFolder:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gRenameMagic')){
                if(this.isWebFengCloud()){
                   var _self = this;
                    var param = {
                        favorite_type:params.condition,
                        favorite_name:params.name,
                        token:gkClientInterface.getWebContext('user',true).token
                    }
                    var sign = gkClientInterface.getApiAuthorization(param);
                    param.sign = sign;

                    jQuery.ajax({
                        type: 'GET',
                        url: gkClientInterface.getApiHost() + '/1/file/set_favorite_name',
                        dataType: 'json',
                        data:param,
                        success:function(data){
                            _self.isFunc(callback)&&callback(data);
                        },
                        error:function(request, textStatus, errorThrown){
                            var error = _self.getAjaxError(request, textStatus, errorThrown);
                            _self.isFunc(callback)&&callback({
                                error:1,
                                message:error.msg
                            });
                        }
                    });
                }
                return;
            }
            params.condition = String(params.condition);
            gkClient.gRenameMagic(JSON.stringify(params),function(re){
                re = typeof re ==='object'?re:JSON.parse(re);
                if(typeof callback === 'function'){
                    callback(re);
                }
            });
        } catch (e) {
            this._handleException(e);
        }
    },
    getTransInfo:function(param){
        try {
            if(!this.isFuncAvaiable('gGetTransInfo')){
                return {};
            }
            var re = gkClient.gGetTransInfo(JSON.stringify(param));
            return JSON.parse(re);
        } catch (e) {
            this._handleException(e);
        }
    },
    getDragFiles:function(){
        try {
            if(!this.isFuncAvaiable('gGetDragFiles')){
                return {};
            }
            var re = gkClient.gGetDragFiles();
            return JSON.parse(re);
        } catch (e) {
            this._handleException(e);
        }
    },
    recover:function(params,callback){
        try {
            var _self = this;
            if(!this.isFuncAvaiable('gRecover')){
               if(this.isWebFengCloud()){
                   var fullpaths = [];
                   $.each(params.list,function(i,v){
                       fullpaths.push(v.webpath);
                   })
                   jQuery.ajax({
                       type: 'POST',
                       url: gkClientInterface.getApiHost() + '/1/file/recover',
                       dataType: 'json',
                       data: {
                           mount_id:params.mountid,
                           fullpaths:fullpaths.join('|')
                       },
                       success:function(data){
                           _self.isFunc(callback)&&callback(data);
                       },
                       error:function(request, textStatus, errorThrown){
                           var error = _self.getAjaxError(request, textStatus, errorThrown);
                           _self.isFunc(callback)&&callback({
                               error:1,
                               message:error.msg
                           });
                       }
                   });
               }else{
                   return;
               }
            }else{
                gkClient.gRecover(JSON.stringify(params),function(re){

                    re = typeof re ==='object'?re:JSON.parse(re);
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                });
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    notice:function(params,callback){
        var _self = this;
        if(!this.isFuncAvaiable('gNotice')){
            if(this.isWebFengCloud()){
                switch (params.type){
                    case 'getOrg':
                        jQuery.ajax({
                            type: 'GET',
                            url: gkClientInterface.getApiHost() + '/1/account/mount',
                            dataType: 'json',
                            data: {
                                org_id:params.org_id
                            },
                            success:function(data){
                                if(data && data.list && data.list[0]){
                                    if(typeof WEB_CONSTANT !== 'undefined'){
                                        if(typeof WEB_CONSTANT.mount === 'undefined'){
                                            WEB_CONSTANT.mount = {list:[]};
                                        }
                                        if(!$.isArray(WEB_CONSTANT.mount.list)){
                                            WEB_CONSTANT.mount.list = [];
                                        }
                                        WEB_CONSTANT.mount.list.push(data.list[0]);
                                    }
                                    _self.isFunc(callback)&&callback(data.list[0]);
                                }
                            },
                            error:function(request, textStatus, errorThrown){
                                var error = _self.getAjaxError(request, textStatus, errorThrown);
                                _self.isFunc(callback)&&callback({
                                    error:1,
                                    message:error.msg
                                });
                            }
                        });
                        break;
                    default :
                        _self.isFunc(callback)&&callback({});
                        break;
                }
            }
        }else{
            gkClient.gNotice(JSON.stringify(params),function(re){
                re = typeof re ==='object'?re:JSON.parse(re);
                if(typeof callback === 'function'){
                    callback(re);
                }
            });
        }

    },
    getComputePath:function(param){
        if(!this.isFuncAvaiable('gGetComputerPath')){
            return '';
        }
        var re = gkClient.gGetComputerPath(JSON.stringify(param));
        return re;
    },
    getLanguage:function(){
        if(!this.isFuncAvaiable('gGetLanguage')){
            return '';
        }
        var re = gkClient.gGetLanguage();
        return JSON.parse(re);
    },
    getClientInfo:function(){
        if(!this.isFuncAvaiable('gGetClientInfo')){
            return {};
        }
      var re = gkClient.gGetClientInfo();
        return JSON.parse(re);
    },
    closeWindow:function(){
        if(!this.isFuncAvaiable('gClose')){
            return;
        }
        gkClient.gClose();
    },
    setDevice:function(params){
        if(!this.isFuncAvaiable('gSetDevice')){
            return;
        }
        gkClient.gSetDevice(JSON.stringify(params));
    },
    getComputerInfo:function(){
        if(!this.isFuncAvaiable('gComputerInfo')){
            return {};
        }
        var re = gkClient.gComputerInfo();
        return JSON.parse(re);
    },
    getLinkDomain:function(){
        if(!this.isFuncAvaiable('gSiteDomain')){
            return '';
        }
        return gkClient.gSiteDomain()+'/link';
    },
    getSiteDomain:function(){
        if(!this.isFuncAvaiable('gSiteDomain')){
            //return 'http://www.gokuai.com';
            if(this.isWebFengCloud()){
                return location.protocol + '//' + gkClientInterface.getWebContext('siteDomain',true);
            }else{
                return location.protocol + '//www.gokuai.com';
            }

        }
        return gkClient.gSiteDomain();
    },
    login:function(params){
        try {
            if(!this.isFuncAvaiable('gLogin')){
                return;
            }
            gkClient.gLogin(JSON.stringify(params));
        } catch (e) {
            this._handleException(e);
        }

    },
    logOff:function(param){
        try {
            if(!this.isFuncAvaiable('gLogoff')){
               if(this.isWebFengCloud()){
                   if(this.isShOnlineClient()){
                       window.location = this.getSiteDomain() + '/account/logout';
                   }else{
                       window.location = '/logout';
                   }
               }
            }else{
                if(!param){
                    gkClient.gLogoff();
                }else{
                    gkClient.gLogoff(JSON.stringify(param));
                }
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    quit:function(){
        try {
            if(!this.isFuncAvaiable('gQuit')){
                this.logOff();
            }else{
                gkClient.gQuit();
            }
        } catch (e) {
            this._handleException(e);
        }
    },
    startFind:function(){
        try {
            if(!this.isFuncAvaiable('gStartFind')){
                return;
            }
            gkClient.gStartFind();
        } catch (e) {
            this._handleException(e);
        }
    },
    stopFind:function(){
        try {
            if(!this.isFuncAvaiable('gStopFind')){
                return;
            }
            gkClient.gStopFind();
        } catch (e) {
            this._handleException(e);
        }
    },
    /**
     * 打开lanchpad页面
     * @param params
     */
    launchpad:function(params){
        if(typeof params ==='undefined'){
            if(!this.isFuncAvaiable('gLaunchpad')){
                return;
            }
            gkClient.gLaunchpad('');
        }else{
            gkClient.gLaunchpad(JSON.stringify(params));
        }

    },
    /**
     * 获取文件信息
     * @param params
     * @returns {*}
     */
    getFileInfo:function(fileObj){
        if(this.isWebFengCloud()){
            fileObj.mount_id = fileObj.mountid;
            fileObj.fullpath = fileObj.path || fileObj.webpath;
            return fileObj;
        }else {
            if (!this.isFuncAvaiable('gGetFileInfo')) {
                return {};
            }
            var params = {}
            if(!fileObj.hash && !fileObj.uuidhash){
                params = {
                    mountid: Number(fileObj.mountid),
                    webpath: fileObj.webpath
                }
            }else{
                params = {
                    mountid: Number(fileObj.mountid),
                    uuidhash: fileObj.hash ||fileObj.uuidhash
                }
            }
            var re = gkClient.gGetFileInfo(JSON.stringify(params));
            var fileObject = JSON.parse(re);
	    
	    if(fileObject && (fileObject.filehash || fileObject.hash)){
                  jQuery.extend(fileObject, {
                mount_id: params.mountid
            });
            }
          
            return fileObject;
        }
    },
    setMessageDate:function(dateline){
        try {
            if(!this.isFuncAvaiable('gSetMessage')){
                return;
            }
           gkClient.gSetMessage(JSON.stringify({
                dateline:dateline
           }));
        } catch (e) {
            this._handleException(e);
        }
    },
    /**
     * 获取文件列表
     * @param params
     * exp.
     * {
     *      “webpath”:”文档”,
     *      ”mountid”:10,
     *      ”dir”:1
     * }
     */
    getFileList: function (params,callback) {
        try {
            if(!this.isFuncAvaiable('gGetFileList')){
                return {};
            }
           gkClient.gGetFileList(JSON.stringify(params),function(re){
               re = typeof re ==='object'?re:JSON.parse(re);
               if(typeof callback === 'function'){
                   callback(re);
               }
           });
        } catch (e) {
            this._handleException(e);
        }
    },


    /**
     * 获取最新修改的文件
     *
     *eg:{
     *        mountid:'',
     *        start:0,
     *        count10
     * }
     *
     */
    getFileUpdateList:function(params,callback){
        try{
            if(!this.isFuncAvaiable('gGetFileListByTime')){
                return {};
            }
            gkClient.gGetFileListByTime(JSON.stringify(params),function(re){
                re = typeof re ==='object'?re:JSON.parse(re);
                if(typeof callback === 'function'){
                    callback(re);
                }
            });
        }catch(e){
            this._handleException(e);
        }
    },
    /**
     * 通过浏览器打开链接
     * @param url
     */
    openUrl:function(url){
        try {
            if(!this.isFuncAvaiable('gOpenUrl')){
                window.open(url,'_blank');
            }else{
                gkClient.gOpenUrl(JSON.stringify({
                    url:url
                }));
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    getUIPath:function(){
        if(!this.isFuncAvaiable('gGetUIPath')){
            return '';
        }
        return gkClient.gGetUIPath();
    },
    /**
     * 获取左侧树数据
     * @param params
     * exp.
     * {
     *      “sidetype”:<org:云库的文件夹|other:其他存储|magic:智能文件夹c>
     * }
     */
    getSideTreeList: function (params) {
        try {
            if(!this.isFuncAvaiable('gSideTreeList')){
                if(this.isWebFengCloud()){
                    if(params.sidetype == 'org'){
                        return gkClientInterface.getWebContext('mount',true);
                    }else if(params.sidetype == 'magic'){
                        var list = [];
                        $.each(gkClientInterface.getWebContext('user',true).favorite_names,function(i,v){
                            list.push({
                                condition:i,
                                name:v
                            })
                        })
                        return {
                            list:list
                        };
                    }else{
                        return {};
                    }
                }else{
                    return {};
                }
            }

            var re = gkClient.gSideTreeList(JSON.stringify(params));
            return JSON.parse(re);
        } catch (e) {
            this._handleException(e);
        }
    },
    /**
     * 显示添加文件的对话框
     * @returns {*}
     */
    addFileDialog: function (param,callback) {
        try {
            var _self = this;
            if(!this.isFuncAvaiable('gAddFileDlg')){
                if(this.isWebFengCloud()){
                    var options = {
                        url: '/mount/upload',
                        params: {
                            stopCallback: 'gkClientCallback.updateFileList',
                            redirectURL: _self.getSiteDomain() + '/index/upload_cb?',
                            uploadParams: encodeURIComponent(JSON.stringify({
                                member_id: gkClientInterface.getWebContext('user',true).member_id,
                                path: param.fullpath,
                                mount_id: param.mount_id,
                                filefield: 'file'
                            })),
                            fullpath: param.fullpath,
                            mount_id: param.mount_id,
                            from:"web_fengcloud"
                        }
                    };
                    var opts = $.extend(true, {}, $.fn.gkUpload.defaults, options);
                    var params = $.param(opts.params);
                    var url = opts.url + '?' + params;
                    $.fn.gkUpload.open(url, opts.width, opts.height, opts.name);
                }else{
                    return;
                }
            }else{
                gkClient.gAddFileDlg(function(re){
                    re = typeof re ==='object'?re:JSON.parse(re);
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                });
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    addFile: function (params,callback) {
        try {
            if(!this.isFuncAvaiable('gAdd')){
                return;
            }
             gkClient.gAdd(JSON.stringify(params),function(re){
                 re = typeof re ==='object'?re:JSON.parse(re);
                 if(typeof callback === 'function'){
                     callback(re);
                 }
             });
        } catch (e) {
            this._handleException(e);
        }
    },
    createFolder: function (params,callback) {
        var _self = this;
        try {
            if(!this.isFuncAvaiable('gNewFile')){
                var param = {
                    mount_id:params.mountid,
                    fullpath:params.webpath
                };
                var requestUrl = gkClientInterface.getApiHost() + '/1/file/create_folder';
                if(params.dir == 0){
                    var files = {
                        gknote:{
                            filehash:'fd9e194c7e82aeb25c6b3e857e631680a19df3b2',
                            filesize:316
                        }
                    };
                    requestUrl = gkClientInterface.getApiHost() + '/1/file/create_file';
                    var ext = Util.String.getExt(Util.String.baseName(param.fullpath));
                    jQuery.extend(param,files[ext]);
                }
                jQuery.ajax({
                    type: 'POST',
                    url: requestUrl,
                    dataType: 'json',
                    data: param,
                    success:function(data){
                        _self.isFunc(callback)&&callback(data);
                    },
                    error:function(request, textStatus, errorThrown){
                        var error = _self.getAjaxError(request, textStatus, errorThrown);
                        _self.isFunc(callback)&&callback({
                            error:1,
                            message:error.msg
                        });
                    }
                });
            }else{
                gkClient.gNewFile(JSON.stringify(params),function(re){
                    re = typeof re ==='object'?re:JSON.parse(re);
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                });
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    toggleLock: function (params,callback) {
        try {
            var _self = this;
            if(!this.isFuncAvaiable('gLock')){
                if(this.isWebFengCloud()){
                    jQuery.ajax({
                        type: 'POST',
                        url: gkClientInterface.getApiHost() + '/1/file/lock',
                        dataType: 'json',
                        data: {
                            mount_id:params.mountid,
                            fullpath:params.webpath,
                            lock:params.status?'lock':'unlock'
                        },
                        success:function(data){
                            _self.isFunc(callback)&&callback(data);
                        },
                        error:function(request, textStatus, errorThrown){
                            var error = _self.getAjaxError(request, textStatus, errorThrown);
                            _self.isFunc(callback)&&callback({
                                error:1,
                                message:error.msg
                            });
                        }
                    });
                }else{
                    return;
                }
            }else{
                gkClient.gLock(JSON.stringify(params),function(re){
                    re = typeof re ==='object'?re:JSON.parse(re);
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                });
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    getUser:function(){
        if(!this.isFuncAvaiable('gUserInfo')){
            if(this.isWebFengCloud())
            {
                return gkClientInterface.getWebContext('user',true);
            }else{
                return {};
            }

        }
        return JSON.parse(gkClient.gUserInfo());
    },
    saveToLocal:function(params,callback){
        try {
            var _self = this;
            if(!this.isFuncAvaiable('gSaveToLocal')){
               var list = params.list;
                if(list.length ==1 &&(!list[0].dir || list[0].dir==0))
                {
                    var _url = '/down?mount_id='+list[0].mountid+'&file='+encodeURIComponent(list[0].webpath);
                    if(params.version){
                        _url += '&v='+params.version;
                    }
                    location.href = _url;
                }else{
                    var dir = 0;
                    if (list.length == 1 && list[0].dir==1) {
                        dir = 1;
                    }
                    var mount_id = 0,fullpaths = [];
                    $.each(list,function(i,v){
                        if(!mount_id) mount_id = v.mountid;
                        if(v.mountid == mount_id){
                            fullpaths.push(v.dir==1 ? v.webpath + '/' : v.webpath);
                        }
                    })
                    jQuery.ajax({
                        type: 'POST',
                        url: '/mount/zip_list',
                        dataType: 'json',
                        data: {
                            mount_id:mount_id,
                            fullpaths:fullpaths,
                            dir:dir
                        },
                        success:function(data){
                            var action = data.server + '/' + data.filename;
                            var form = $('<form style="display:none;" method="post" action="' + action + '">'
                                + '<input type="hidden" name="list" value="' + encodeURIComponent(data.list) + '" >'
                                + '</form>');
                            $('body').append(form);
                            form.submit();
                            form.remove();
                            $.isFunc(callback) && callback(data);
                        },
                        error:function(request, textStatus, errorThrown){
                            var error = _self.getAjaxError(request, textStatus, errorThrown);
                            _self.isFunc(callback)&&callback({
                                error:1,
                                message:error.msg
                            });
                        }
                    });
                }
            }else{
                gkClient.gSaveToLocal(JSON.stringify(params));
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    del:function(params,callback){
        var _self = this;
        try {
            if(!this.isFuncAvaiable('gDelete')){
                var fullpaths = [];
                $.each(params.list,function(i,v){
                    fullpaths.push(v.webpath);
                })
                jQuery.ajax({
                    type: 'POST',
                    url: gkClientInterface.getApiHost() + '/1/file/del',
                    dataType: 'json',
                    data: {
                        mount_id:params.mountid,
                        fullpaths:fullpaths.join('|')
                    },
                    success:function(data){
                        _self.isFunc(callback)&&callback(data);
                    },
                    error:function(request, textStatus, errorThrown){
                        var error = _self.getAjaxError(request, textStatus, errorThrown);
                        _self.isFunc(callback)&&callback({
                            error:1,
                            message:error.msg
                        });
                    }
                });
            }else{
                gkClient.gDelete(JSON.stringify(params),function(re){
                    re = typeof re ==='object'?re:JSON.parse(re);
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                });
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    rename:function(params,callback){
        var _self = this;
        try {
            if(!this.isFuncAvaiable('gRename')){
                jQuery.ajax({
                    type: 'POST',
                    url: gkClientInterface.getApiHost() + '/1/file/rename',
                    dataType: 'json',
                    data: {
                        mount_id:params.mountid,
                        fullpath:params.oldpath,
                        newname:Util.String.baseName(params.newpath)
                    },
                    success:function(data){
                        _self.isFunc(callback)&&callback(data);
                    },
                    error:function(request, textStatus, errorThrown){
                        var error = _self.getAjaxError(request, textStatus, errorThrown);
                        _self.isFunc(callback)&&callback({
                            error:1,
                            message:error.msg
                        });
                    }
                });
            }else{
                gkClient.gRename(JSON.stringify(params),function(re){
                    re = typeof re ==='object'?re:JSON.parse(re);
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                });
            }
        } catch (e) {
            this._handleException(e);
        }
    },
    copy:function(params,callback){
        try {
            var _self = this;
            if(!this.isFuncAvaiable('gCopy')){
                var fullpaths = [];
                $.each(params.fromlist,function(i,v){
                    fullpaths.push(v.webpath);
                })
                jQuery.ajax({
                    type: 'POST',
                    url: gkClientInterface.getApiHost() + '/1/file/copy',
                    dataType: 'json',
                    data: {
                        mount_id:params.frommountid,
                        fullpaths:fullpaths.join('|'),
                        target_mount_id:params.targetmountid,
                        target_fullpath:params.target
                    },
                    success:function(data){
                        _self.isFunc(callback)&&callback(data);
                    },
                    error:function(request, textStatus, errorThrown){
                        var error = _self.getAjaxError(request, textStatus, errorThrown);
                        _self.isFunc(callback)&&callback({
                            error:1,
                            message:error.msg
                        });
                    }
                });
            }else{
                gkClient.gCopy(JSON.stringify(params),function(re){
                    re = typeof re ==='object'?re:JSON.parse(re);
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                });
            }


        } catch (e) {
            this._handleException(e);
        }
    },
    move:function(params,callback){
        try {
            var _self = this;
            if(!this.isFuncAvaiable('gMove')){
                var fullpaths = [];
                $.each(params.fromlist,function(i,v){
                    fullpaths.push(v.webpath);
                })
                jQuery.ajax({
                    type: 'POST',
                    url: gkClientInterface.getApiHost() + '/1/file/move',
                    dataType: 'json',
                    data: {
                        mount_id:params.frommountid,
                        fullpaths:fullpaths.join('|'),
                        target_mount_id:params.targetmountid,
                        target_fullpath:params.target
                    },
                    success:function(data){
                        _self.isFunc(callback)&&callback(data);
                    },
                    error:function(request, textStatus, errorThrown){
                        var error = _self.getAjaxError(request, textStatus, errorThrown);
                        _self.isFunc(callback)&&callback({
                            error:1,
                            message:error.msg
                        });
                    }
                });
            }else{
                gkClient.gMove(JSON.stringify(params),function(re){
                    re = typeof re ==='object'?re:JSON.parse(re);
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                });
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    open:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gOpen')){
                var url = '/down?mount_id='+params.mountid+'&file='+encodeURIComponent(params.webpath);
                if(params.version){
                    url += '&v='+ params.version;
                }
                if(this.isWebFengCloud()){
                    var ext = Util.String.getExt(Util.String.baseName(params.webpath));
                    if(ext == 'gknote'){
                        var queryString = jQuery.param({
                            'fullpath':params.webpath,
                            'mount_id':params.mountid
                        });
                        if(params.win){
                            params.win.location = '/web/note?'+queryString;
                        }else{
                            window.open('/web/note?'+queryString);
                        }
                    }else{
                        location.href = url;
                    }
                }
            }else{
                if(!params.opentype){
                    params.opentype = 'open';
                }
                gkClient.gOpen(JSON.stringify(params),function(){
                    if(typeof callback === 'function'){
                        callback();
                    }
                });
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    openLocation:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gOpen')){
                return;
            }
            params.opentype = 'select';
            gkClient.gOpen(JSON.stringify(params));
        } catch (e) {
            this._handleException(e);
        }
    },
    selectPath:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gSelectPathDlg')){
                return;
            }
            var req;
            if(typeof params === 'undefined'){
                req  = '';
            }else{
                req = JSON.stringify(params);
            }
            gkClient.gSelectPathDlg(req,function(re){
                re = typeof re ==='object'?re:JSON.parse(re);
                if(typeof callback === 'function'){
                    callback(re);
                }
            });
        } catch (e) {
            this._handleException(e);
        }
    },
    checkPathIsEmpty:function(params){
        try {
            if(!this.isFuncAvaiable('gCheckEmpty')){
                return {};
            }
            return gkClient.gCheckEmpty(JSON.stringify(params));
        } catch (e) {
            this._handleException(e);
        }
    },
    setLinkPath:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gSetLinkPath')){
                return;
            }
            gkClient.gSetLinkPath(JSON.stringify(params),function(re){
                re =typeof re ==='object'?re: JSON.parse(re);
                if(re && re.error==0){
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                }
            });
        } catch (e) {
            this._handleException(e);
        }
    },
    moveLinkPath:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gMoveLinkPath')){
                return;
            }
            gkClient.gMoveLinkPath(JSON.stringify(params),function(re){
                re =typeof re ==='object'?re: JSON.parse(re);
                if(re && re.error==0){
                    if(typeof callback === 'function'){
                        callback(re);
                    }
                }
            });
        } catch (e) {
            this._handleException(e);
        }
    },
    removeLinkPath:function(params,callback){
        try {
            if(!this.isFuncAvaiable('gDeleteLinkPath')){
                return;
            }
            gkClient.gDeleteLinkPath(JSON.stringify(params),function(re){
                re =typeof re ==='object'?re: JSON.parse(re);
                if(typeof callback === 'function'){
                    callback(re);
                }
            });
        } catch (e) {
            this._handleException(e);
        }
    },
    getRestHost:function(){
        try {
            if(!this.isFuncAvaiable('gRestHost')){
                return '';
            }
            return gkClient.gRestHost();
        } catch (e) {
            this._handleException(e);
        }
    },
    getApiHost:function(){
        try {
            if(!this.isFuncAvaiable('gApiHost')){
                return '/fengcloud';
            }
            return gkClient.gApiHost();
        } catch (e) {
            this._handleException(e);
        }
    },
    getToken:function(){
        try {
            if(!this.isFuncAvaiable('gGetToken')){
                return '';
            }
            return gkClient.gGetToken();
        } catch (e) {
            this._handleException(e);
        }
    },
    getAuthorization:function(ver,webpath,date,mountid){
        if(!this.isFuncAvaiable('gGetAuthorization')){
            return '';
        }
        var params = {
            ver: String(ver),
            webpath: String(webpath),
            date: String(date),
            mountid:parseInt(mountid)
        };
        //onsole.log(params);
        var JSONParams = JSON.stringify(params);
        return gkClient.gGetAuthorization(JSONParams);
    },
    getApiAuthorization:function(params){
        if(!this.isFuncAvaiable('gGetApiAuthorization')){
            return '';
        }
        for(var key in params){
            params[key] = String(params[key]);
        }
        return gkClient.gGetApiAuthorization(JSON.stringify(params));
    },
    setSettings:function(){
        if(!this.isFuncAvaiable('gNetworkAgent')){
            return;
        }
        gkClient.gNetworkAgent();
    },
    setClose:function(){
        if(!this.isFuncAvaiable('gClose')){
            return;
        }
        gkClient.gClose();
    },
    getMessage:function(){
        if(!this.isFuncAvaiable('gGetMessage')){
            return;
        }
        return gkClient.gGetMessage();
    },
    getUserInfo:function(){
        if(!this.isFuncAvaiable('gUserInfo')){
            return;
        }
        return gkClient.gUserInfo();
    },
    setClearCache:function(){
        if(!this.isFuncAvaiable('gClearCache')){
            return;
        }
        gkClient.gClearCache();
    },
    getTransList: function(param){
        if(!this.isFuncAvaiable('gTransList')){
            return {};
        }
        var re = gkClient.gTransList(JSON.stringify(param));
        return JSON.parse(re);
    },
    setLogoff:function(){
        if(!this.isFuncAvaiable('gLogoff')){
            return;
        }
        gkClient.gLogoff();
    },
     setClientInfo:function(params){
         if(!this.isFuncAvaiable('gSetClientInfo')){
             return;
         }
        return gkClient.gSetClientInfo(JSON.stringify(params));
    },
    setChangeLanguage:function(params){
        if(!this.isFuncAvaiable('gChangeLanguage')){
            return;
        }
       gkClient.gChangeLanguage(JSON.stringify(params));
    },
    getUrl:function(params){
        if(!this.isFuncAvaiable('gGetUrl')){
            return params.url;
        }else{
            var url = gkClient.gGetUrl(JSON.stringify(params));
            var clientLanType = this.getLanguage();
            var language = this.getLanguageKey(clientLanType.type);
            if(url.indexOf('?') >= 0){
                url += '&hl=' + language;
            }else{
                url += '?hl=' + language;
            }
           //document.write(url);
            return url;
        }
    },
    setMain:function(data){
        if(!this.isFuncAvaiable('gMain')){
            return;
        }
        return gkClient.gMain(JSON.stringify(data));
    },
    getUIPath: function(){
        if(!this.isFuncAvaiable('gMain')){
            return '';
        }
        return gkClient.gGetUIPath();
    },
    getLocalSyncURI: function(param){
        if(!this.isFuncAvaiable('gGetSyncNormalPath')){
            return '';
        }
        var re =  gkClient.gGetSyncNormalPath (JSON.stringify(param));
        return re;
    },
    setClientInfo: function(params){
        if(!this.isFuncAvaiable('gSetClientInfo')){
            return;
        }
        return gkClient.gSetClientInfo(JSON.stringify(params));
    },
    getLinkPath: function(){
        if(!this.isFuncAvaiable('gGetLinkPath')){
            return '';
        }
        var re = gkClient.gGetLinkPath();
        return JSON.parse(re);
    },
    setSyncStatus: function(params,callback){
        if(!this.isFuncAvaiable('gSetSyncStatus')){
            return;
        }
        gkClient.gSetSyncStatus(JSON.stringify(params),function(re){
            re = typeof re ==='object'?re: JSON.parse(re);
            if(re && re.error==0){
                if(typeof callback === 'function'){
                    callback(re);
                }
            }
        });

    },
    startSync: function(){
        if(!this.isFuncAvaiable('gStartSync')){
            return;
        }
        gkClient.gStartSync();
    },
    stopSync: function(){
        if(!this.isFuncAvaiable('stopSync')){
            return;
        }
        gkClient.gStopSync();
    },
    removeTrans: function(params,callback){
        if(!this.isFuncAvaiable('gRemoveTrans')){
            return;
        }
        gkClient.gRemoveTrans(JSON.stringify(params),function(re){
            re = typeof re ==='object'?re: JSON.parse(re);
            if(re && re.error==0){
                if(typeof callback === 'function'){
                    callback(re);
                }
            }
        });
    },
    setDeviceStatus: function(params){
        if(!this.isFuncAvaiable('setDeviceStatus')){
            return;
        }
        gkClient.gSetDeviceStatus(JSON.stringify(params));
    },
    getUserAgent:function(){
        return navigator.userAgent.split(';')
    },
    getClientOS:function(){
        var os = this.getUserAgent()[2] || '';
        return os.toLowerCase();
    },
    isWindowsClient:function(){
        return this.getClientOS() == 'windows';
    },
    isMacClient:function(){
        return this.getClientOS() == 'mac';
    },
    isClientOS:function(){
      return this.isWindowsClient() || this.isMacClient();
    },
    getClientVersion:function(){
        var version = this.getUserAgent()[1] || '';
        return version.toLowerCase();
    },
    addCache:function(param){
        try {
            if(!this.isFuncAvaiable('gSetLocalCache')){
                return;
            }

            gkClient.gSetLocalCache(JSON.stringify(param));
        } catch (e) {
            this._handleException(e);
        }
    },
    delCache:function(param){
        try {
            if(!this.isFuncAvaiable('gDeleteLocalCache')){
                return;
            }
            if(typeof gkClient.gDeleteLocalCache === 'undefined'){
                return;
            }
            gkClient.gDeleteLocalCache(JSON.stringify(param));
        } catch (e) {
            this._handleException(e);
        }

    },
    getCache:function(param){
        try {
            if(!this.isFuncAvaiable('gGetLocalCache')){
                return '';
            }

            var re = gkClient.gGetLocalCache(JSON.stringify(param));
            if(!re){
                return '';
            }else{
                return JSON.parse(re);
            }

        } catch (e) {
            this._handleException(e);
        }
    },
    clearCache:function(){
        try {
            if(!this.isFuncAvaiable('gClearCache')){
                return '';
            }

            gkClient.gClearCache();
        } catch (e) {
            this._handleException(e);
        }
    },
    getSummaryText:function(count,from,to){
        try {
            if(this.isWebFengCloud() || !this.isFuncAvaiable('gGetMetadataChange')){
                return '';
            }
           return  gkClient.gGetMetadataChange('{"count":' + count + ',"from":' + from + ',"to":' + to + '}');
        }catch(e){
            this._handleException(e);
        }
    },
    getMountStatus:function(mountId){
    	if(!this.isFuncAvaiable('gGetMountStatus')){
                return '';
        }
        var param = {
            mountid:mountId
        }
        var status = 1;
        try {
           status = JSON.parse(gkClient.gGetMountStatus(JSON.stringify(param))).status;
        }catch(e){
            this._handleException(e);
        }
        return status;
    },
    getScreenshotPath:function(param){
        if(this.isWebFengCloud()){
           var filePath = {
               path:'/index/screenshot?filehash='+param.filehash
           }
           return filePath;
        }else {
            if (!this.isFuncAvaiable('gGetScreenshotPath')) {
                return '';
            }
            return JSON.parse(gkClient.gGetScreenshotPath(JSON.stringify(param)));

        }
    },
    api_getMessage:function(param,onSuccess,onError){
        var serverParam = {
            protocol:gkClientInterface.getWebContext('chatServer',true).protocol,
            host:gkClientInterface.getWebContext('chatServer',true).host,
            port:gkClientInterface.getWebContext('chatServer',true).port
        }
        var serverQueryString = $.param(serverParam);
        jQuery.ajax({
            url: '/chat/get-message?' + serverQueryString,
            type: 'GET',
            data: param,
            success: onSuccess,
            error: onError
        });
    },
    api_connectMessage:function(param,onSuccess,onError){
        if(!gkClientInterface.getWebContext('',true) || !gkClientInterface.getWebContext('chatServer',true)) return;
        var serverParam = {
            protocol:gkClientInterface.getWebContext('chatServer',true).protocol,
            host:gkClientInterface.getWebContext('chatServer',true).host,
            port:gkClientInterface.getWebContext('chatServer',true).port
        }
        var serverQueryString = $.param(serverParam);
        jQuery.ajax({
            url: '/chat/connect?' + serverQueryString,
            type: 'GET',
            data: param,
            success: onSuccess,
            error: onError
        });
    },
    getLanguageKey:function(key){
        var languageObj = ['zh_cn','en_US']
        return languageObj[key-1];
    },
    isWinOrMacSystem:function(key){
        if(key == 'window'){
            if(navigator.userAgent.toLowerCase().indexOf('window')>=0){
                return true;
            }
        }else if(key == 'mac'){
            if(navigator.userAgent.toLowerCase().indexOf('mac')>=0){
                return true;
            }
        }
        return false;
    },
    openMountPath:function(mountId,fullpath){
        if(!this.isFuncAvaiable('gOpenMountPath')){
            return;
        }
        var param = {
            mountid:mountId,
            webpath:fullpath
        }
        gkClient.gOpenMountPath(JSON.stringify(param));
    },
    getConfigInfo:function(){
        if(!this.isFuncAvaiable('gConfigInfo')){
            if(this.isWebFengCloud()){
                var source = this.getWebContext('source',true);
                if(source && source == 'shonline'){
                    return {
                        source:'shonline',
                        menu:['transport']
                    };
                }else if(source && source.toLowerCase() == 'xdf'){
                    return {
                        source:'xdf',
                        menu:['transport']
                    };
                }
            }
            return null;

        }
        var re = gkClient.gConfigInfo();
        if(!re || re == '{}'){
            return null;
        }else{
           try{
               return JSON.parse(re);
           }catch(e){
               return null;
           }
        }

    },

    ZZCrypt:function(param){
        console.log('ZZCrypt',param);
        if(!gkClientInterface.isFuncAvaiable('gZZCrypt')){
            return;
        }

        gkClient.gZZCrypt(JSON.stringify(param));

    },

    ZZAuthorize:function(param){
        console.log('ZZAuthorize',param);
        if(!gkClientInterface.isFuncAvaiable('gZZAuthorize')){
            return;
        }
        gkClient.gZZAuthorize(JSON.stringify(param));
    },
      /*
    通知客户端更新文件信息
     */
    updateFileInfo:function(param){
        if(!this.isFuncAvaiable('gUpdateWebPath')){
            return ;
        }
        gkClient.gUpdateWebPath(JSON.stringify(param));
    },
    getEditorContent:function(url,param,callback){
        try {
            var _self = this;
            var options = {
                url: url? url : '/note/get_note?noteserver=' + gkClientInterface.getNoteHost(),
                data: param,
                cache:false,
                success: function (data) {
                    _self.isFunc(callback)&&callback(data);
                },
                error: function (request, textStatus, errorThrown) {
                    var error = _self.getAjaxError(request, textStatus, errorThrown);
                    _self.isFunc(callback)&&callback({
                        error:1,
                        message:error.msg
                    });
                }
            };
            if(!this.isClientOS()){
                if(0){
                //if(jQuery.support.cors){
                    jQuery.extend(options,{
                        url:gkClientInterface.getNoteHost() + '/get_note',
                        xhrFields: {
                            withCredentials: true
                        }
                    })
                }else{
                    jQuery.extend(options,{
                        data:param
                    })
                }
            }

            return jQuery.ajax(options);

        } catch (e) {
            this._handleException(e);
        }
    },
    getNoteHost:function(){
        return this.getWebContext('noteHost',true);
    },
    saveEditor:function(param,callback){
        var _self = this;
        if(!this.isFuncAvaiable('gEditorSave')){
            var options = {
                url: '/note/save_note?noteserver=' + gkClientInterface.getNoteHost(),
                type:'POST',
                data: param,
                success: function (data) {
                    _self.isFunc(callback)&&callback(data);
                },
                error: function (request, textStatus, errorThrown) {
                    var error = _self.getAjaxError(request, textStatus, errorThrown);
                    _self.isFunc(callback)&&callback({
                        error:1,
                        message:error.msg
                    });
                }
            };

            if(0){
            //if(jQuery.support.cors){
                jQuery.extend(options,{
                    url:gkClientInterface.getNoteHost() + '/save_note',
                    xhrFields: {
                        withCredentials: true
                    },
                    crossDomain:true
                });
            }else{
                jQuery.extend(options,{
                    data:param
                });
            }
            jQuery.ajax(options);
        }else{
            gkClient.gEditorSave(JSON.stringify(param), function (re) {
                _self.isFunc(callback)&&callback(re);
            });
        }
    },
    editorStatusChange:function(param){
        if(!this.isFuncAvaiable('gEditorChange')){
            return;
        }else{
            gkClient.gEditorChange(JSON.stringify(param));
        }
    },
    editorExit:function(param){
        if(!this.isFuncAvaiable('gEditorExit')){
            return;
        }else{
            gkClient.gEditorExit(JSON.stringify(param));
        }
    },

    /**
     * 新东方特定使用函数
     */
    XIN_DF:{
        getHelpUrl:function(){
            return "http://www.yuehaola.cn";
        }
    },

    /**
     *  云顿特定使用函数
     */
    YUN_DUN:{
            getSheidStatus:function(){
                if(!gkClientInterface.isFuncAvaiable('gShieldStatus')){
                    return;
                }
                var re = gkClient.gShieldStatus();
                if(!re || re == '{}'){
                    return null;
                }else{
                    try{
                        return JSON.parse(re);
                    }catch(e){
                        return null;
                    }
                }
            },
            getSheildBindInfo:function(mountId){
                if(!gkClientInterface.isFuncAvaiable('gSetSheildBindInfo')){
                    alert('此版本不支持该功能')
                    return;
                }
                var param = {
                    mountid:mountId
                }
                var re = gkClient.gSetSheildBindInfo(JSON.stringify(param));
                if(!re || re == '{}'){
                    return null;
                }else{
                    try{
                        return JSON.parse(re);
                    }catch(e){
                        return null;
                    }
                }

            }

    }

 };

