'use strict';
angular.module('LocalStorageModule').value('prefix', 'gkClientIndex');
angular.module('gkChat', ['gettext','GKCommon', 'ui.bootstrap', 'LocalStorageModule'])
    .run(['GKI18n',function (GKI18n) {
        GKI18n.setLocal();
    }])
    .run(['$rootScope', 'localStorageService', function ($rootScope, localStorageService) {
        $rootScope.PAGE_CONFIG = {
            user: gkClientInterface.getUser(),
            file: null,
            partition: 'teamfile',
            mode: localStorageService.get('gk_mode') || 'chat'
        }

    }])
    .controller('initChat', [
        'GKI18n',
        'gettext',
        '$scope',
        'chatSession',
        '$location',
        '$timeout',
        'chatContent',
        '$rootScope',
        'chatService',
        'GKException',
        'chatMember',
        '$window',
        '$interval',
        'GKApi',
        'localStorageService',
        'GKDialog',
        '$document',
        'chatTopic',
        'GKMount',
        function (GKI18n,gettext,$scope, chatSession, $location, $timeout, chatContent,$rootScope, chatService, GKException, chatMember, $window, $interval, GKApi, localStorageService, GKDialog, $document,chatTopic,GKMount) {
        var maxCount = 20,
            maxMsgTime = 0,
            minMsgTime = 0,
            topWindow = window.parent,
            postedMsg = [],
            isScrolling = false;
        $scope.currentMsgList = $scope.topicHintList = [];
        $scope.currentSession = null;
        $scope.onlyShowTopic = false;
        $scope.showToolAppIndex = "0,2,3";
        if(gkClientInterface.isWebFengCloud()){
            $scope.showToolAppIndex = "0";
            $scope.chatError = gkClientInterface.getWebContext('chatError',true);
        }
        $scope.$on("addOrgSuccess",function(obj,newOrg){
            GKMount.addMount(newOrg);
        });
        var post = function (type, content, metadata, status) {
            metadata = angular.isDefined(metadata) ? metadata : '';
            var now = new Date().getTime();
            var msgData = {
                content: content,
                receiver: $scope.currentSession.orgid,
                sender: $rootScope.PAGE_CONFIG.user.member_name,
                time: now,
                type: type,
                metadata: metadata
            };
            topWindow.gkFrameCallback('ChatMessageUpdate', {
                list:[msgData]
            })
            var newMsg = chatContent.add($scope.currentMsgList, msgData);
            if (!newMsg) {
                return;
            }
            $scope.scrollToIndex = $scope.currentMsgList.length - 1;
            chatService.add(type, $scope.currentSession.orgid, content, metadata, now, status,$rootScope.PAGE_CONFIG.user.member_name).then(function (data) {
                postedMsg.push(now);
                if(data && data.time){
                    maxMsgTime = data.time;
                }
            }, function (re) {
                var errorMsg = GKException.getClientErrorMsg(re);
                chatContent.setItemError(newMsg, errorMsg);
            })
            var matches = content.match(Util.RegExp.POUND_TOPIC);
            if(matches&&matches.length){
                $scope.topicHintList = chatTopic.add($scope.currentSession.orgid,matches[1]);
            }
        };

        var getList = function (lastTime,isBefore, callback) {
            var topic = '';
            if ($scope.onlyShowTopic) {
                topic = ['#', $scope.topic, '#'].join('');
            }
            $scope.loadingHistoryMsg = true;
            var _type = $scope.chatReadOnly ? 'summary' : '';
            chatService.list($scope.currentSession.orgid, lastTime, maxCount, topic,_type,isBefore).then(function (re) {
                if (re && re.list && re.list.length) {
                    angular.forEach(re.list, function (item) {
                        var time = Number(item.time);
                        if (minMsgTime == 0 || time < minMsgTime) {
                            minMsgTime = time;
                        }
                        if (time > maxMsgTime) {
                            maxMsgTime = time;
                        }
                        if (postedMsg.indexOf(time) >= 0) {
                            return;
                        }
                        chatContent.add($scope.currentMsgList, item);
                    });
                }
                if (typeof callback === 'function') {
                    callback();
                }
                $scope.loadingHistoryMsg = false;
                $scope.$broadcast('disabledText',true);
                if(gkClientInterface.isWebFengCloud()) {
                    //更新消息加载时间
                    topWindow.gkFrameCallback('updateMaxMsgTime', {
                        maxMsgTime: maxMsgTime
                    })
                }

            });
        };


        $scope.handleSysKeyDown = function ($event) {
            var ctrlKeyOn = $event.ctrlKey || $event.metaKey;
            if (ctrlKeyOn && $event.keyCode == 86) {
                var sysData = gkClientInterface.getClipboardData();
                if(sysData && sysData.type && sysData.type=='screenshot'){
                 if(confirm(GKI18n.getText(gettext("你确定要发送该屏幕截图吗?")))) {
                     angular.forEach(sysData.list, function (data) {
                         var param = {
                             type: sysData.type,
                             path: data.path,
                             metadata: {
                                 filehash: data.filehash
                             }
                         }
                         $scope.$emit("postMessage", param.type, param.path, JSON.stringify(param.metadata));
                     });
                 }
                }else {
                    if (!sysData || !sysData.list || !sysData.list.length) {
                        return;
                    }
                    topWindow.gkFrameCallback('showSelectFileDialog', {
                        mountId: $scope.currentSession.mountid,
                        list: sysData.list
                    })
                }
            }else if(ctrlKeyOn && $event.keyCode == 68){
                topWindow.gkFrameCallback('openSmartDesktop');
            }
        };

        $scope.openSummaryDetail = function($event,msg){
            var param = {
                mountId:$scope.currentSession.mountid,
                from:msg.metadata.from,
                to:msg.metadata.to
            }
            topWindow.gkFrameCallback('openSummaryDetail',param);
        }

        /**
         * 发布新消息
         * @param $event
         * @param postText
         */
         $scope.$on("postMessage",function($event,type,postText,metadata){
             post(type, postText,metadata);
         });



        /**
         * 滚动加载
         * @param scrollToBottom
         */
        var firstScrollLoad = true;
        $scope.handleScrollLoad = function (scrollToBottom) {
            if(firstScrollLoad){
                firstScrollLoad = false;
                return;
            }
            $scope.loadingHistoryMsg = true;
            scrollToBottom = angular.isDefined(scrollToBottom) ? scrollToBottom : false;
            var minDateline = new Date().getTime();
            if ($scope.currentMsgList.length) {
                minDateline = $scope.currentMsgList[0]['time'];
            }
            $scope.firstLoading = scrollToBottom;
            var topic = '';
            if ($scope.onlyShowTopic) {
                topic = ['#', $scope.topic, '#'].join('');
            }
            chatService.search($scope.currentSession.orgid, minDateline, 10, topic).then(function (data) {
                if (!data || !data.list || !data.list.length) return;
                var list = data.list;
                var len = list.length;
                for (var i = len; i--; i >= 0) {
                    chatContent.add($scope.currentMsgList, list[i], true);
                }
                if (scrollToBottom) {
                    $scope.scrollToIndex = $scope.currentMsgList.length - 1;
                } else {
                    $scope.scrollToIndex = len;
                }

                $scope.loadingHistoryMsg = false;
            })
        };

        /**
         * 打开文件位置
         * @param msg
         */
        $scope.goToFile = function ($event, file) {
            var fullpath = file.path || file.fullpath;
            var mountId = '',rootMountId;
            if(!file.mount_id){
                mountId = $scope.currentSession.mountid;
                rootMountId = 0;
            }else{
                mountId = file.mount_id;
                rootMountId = $scope.currentSession.mountid;
            }
            topWindow.gkFrameCallback('OpenMountPath', {
                mountid: mountId,
                rootMountId: rootMountId,
                webpath: fullpath
            })

            $event.stopPropagation();
        };

        /**
         * 打开文件
         * @param msg
         */
        $scope.openFile = function ($event, msg) {
            var type = msg.type;
            var metadata = msg.metadata;
            if (type == 'file') {
                var mountId = Number(metadata.from_mount_id || metadata.mount_id);
                var file;
                if (!metadata.hash) {
                    if (metadata.fullpath) {
                        file = gkClientInterface.getFileInfo({
                            mountid: Number(mountId),
                            webpath: metadata.fullpath
                        });
                    }
                } else {
                    file = gkClientInterface.getFileInfo({
                        mountid: Number(mountId),
                        uuidhash: metadata.hash
                    });
                }
                if (jQuery.isEmptyObject(file)) {
                    file = null;
                }
                if (metadata.dir == 1) {
                    if (!file) return;
                    var fullpath = file.path;
                    topWindow.gkFrameCallback('OpenMountPath', {
                        mountid: mountId,
                        webpath: fullpath + '/'
                    })
                } else {
                    var permissions = [];
                    if ($scope.currentSession.property) {
                        var properties = typeof $scope.currentSession.property === 'object'?$scope.currentSession.property:JSON.parse($scope.currentSession.property);
                        permissions = properties.permissions ? properties.permissions : [];
                    }
                    if (permissions.indexOf('file_read') < 0 && file) {
                        alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                        return;
                    }
                    var params = {
                        mountid: mountId,
                        filehash: metadata.filehash,
                        uuidhash: metadata.hash
                    };
                    if (!file) {
                        if (metadata.fullpath) {
                            params.webpath = metadata.fullpath;
                        } else {
                            params.webpath = metadata.filename;
                            params.mountid = metadata.from_mount_id;
                        }
                    } else {
                        params.webpath = file.path;
                    }
                    gkClientInterface.open(params);
                }
            }else if(type == 'screenshot'){
                if(gkClientInterface.isWebFengCloud()) return;
                var params = {
                    opentype:'open',
                    mountid: "0",
                    webpath: msg.content
                }
                gkClientInterface.open(params);
            } else {
                var url = metadata.url;
                if (url.indexOf('?') >= 0) {
                    url += '&uuid=' + $rootScope.PAGE_CONFIG.user.uuid;
                } else {
                    url += '?uuid=' + $rootScope.PAGE_CONFIG.user.uuid;
                }
                 url = gkClientInterface.getUrl({
                    url: url,
                    sso: 0
                });
                GKDialog.openUrl(url);
            }
            $event.stopPropagation();
        };
        var setList = function () {
//            if ($rootScope.PAGE_CONFIG.mode != 'chat') {
//                return;
//            }
            postedMsg = [];
            var param = $location.search();
            var mountId = Number(param.mountid);
            var session = chatSession.getSessionByMountId(mountId);
            if (jQuery.isEmptyObject(session)) {
                return;
            }
            $scope.currentSession = session;
            var extendParam = {};
            chatContent.pendingMsg = [];
            $scope.currentMsgList = [];
            $scope.topic = '';
            $scope.onlyShowTopic = false;
            $scope.showTopicLabel = false;
            $scope.textareaStyle = {
                'text-indent': 0
            };
            firstScrollLoad = true;
            getList(gkClientInterface.isWebFengCloud()?new Date().getTime():0, gkClientInterface.isWebFengCloud(),function () {
                //文件
                if (param.fullpath) {
                    extendParam.file = gkClientInterface.getFileInfo({
                        mountid: mountId,
                        webpath: param.fullpath
                    });
                    if (!extendParam.file || jQuery.isEmptyObject(extendParam.file)) {
                        alert(GKI18n.getText(gettext('文件已被删除')));
                        return;
                    }
                    var metadata = JSON.stringify({
                        mount_id: mountId,
                        dir: extendParam.file.dir,
                        hash: extendParam.file.uuidhash,
                        filehash: extendParam.file.filehash,
                        filesize: extendParam.file.filesize,
                        version: extendParam.file.version,
                        fullpath: extendParam.file.path
                    });

                   // $scope.topic = Util.String.baseName(param.fullpath);
                   // toggleTopicLabel('show');
                   // post('file', ['#',$scope.topic,'#'].join(''), metadata, extendParam.file.status == 1 ? 1 : 0);
                }
                $scope.scrollToIndex = $scope.currentMsgList.length - 1;

            });
            $scope.chatLoaded = true;

        };
 
        $scope.$on('chatMessageUpdate', function (event, item) {
            if (!$scope.currentSession) return;
            if (item.receiver != $scope.currentSession.orgid) return;
            getList(maxMsgTime,false,function(){
                if($scope.isScrollBottom){
                    $scope.scrollToIndex = $scope.currentMsgList.length - 1;
                }
            });
        });
        $scope.$on('UpdateScreenshot',function(event,param){
                for (var i = $scope.currentMsgList.length - 1; i >= 0; i--) {
                    var item = $scope.currentMsgList[i];
                    if (item.type == 'screenshot' && item.metadata && item.metadata.filehash) {
                        if (item.metadata.filehash == param.filehash && item.status == 0) {
                            if(param.filepath && param.filepath.length > 0) {
                                $scope.currentMsgList[i].content = param.filepath;
                                $scope.currentMsgList[i].status = 1;
                                break;
                            }else{
                                $scope.currentMsgList[i].status = -1;
                                break;
                            }
                        }
                    }
                }
        });

        $scope.$on('$locationChangeSuccess', function (event, newLocation, oldLocation) {
            $scope.chatLoaded = false;
            var param = $location.search();
            $scope.chatReadOnly = (param.readonly && param.readonly == 'true') ? true : false;
            setList();
        })

        $rootScope.$on('changeMode', function ($event, mode) {
            $rootScope.PAGE_CONFIG.mode = mode;
            if (mode == 'chat' && !$scope.chatLoaded) {
                setList();
            }
        })

        $scope.showDragChat = false;
        $scope.togglerDragChat = function (show) {
            $scope.showDragChat = show;
        };

        //更新库用户列表
        $scope.$on('UpdateMembers', function ($event, param) {
            if ($scope.currentSession && $scope.currentSession.mountid == param.mountid) {
                chatMember.refreshMembers($scope.currentSession.orgid);
                $scope.$broadcast('UpdateMembersCallback');
            }
        })

        var dragFiles;
        $scope.$on('selectAddDirSuccess', function ($event, param) {
            var selectedPath = param.selectedPath;
            var list = param.list || dragFiles.list;
            var params = {
                parent: selectedPath,
                type: 'save',
                list: list,
                mountid: param.mountId
            };
            gkClientInterface.addFile(params, function (re) {
                if (!re.error) {
                    var list = re.list;
                    if (!list || !list.length) return;
                    angular.forEach(list, function (file) {
                        GKApi.dragUpload($scope.currentSession.mountid, file.path);
                        var metadata = JSON.stringify({
                            mount_id: param.mountId,
                            hash: file.uuidhash || '',
                            dir: file.dir,
                            filehash: file.filehash || '',
                            filesize: file.filesize || 0,
                            version: file.version || 0,
                            fullpath: file.path
                        });
                        post('file', '', metadata, file.status == 1 ? 1 : 0);
                    })
                } else {

                }
            })
        })

        $scope.handleChatDrop = function ($event) {
            if(gkClientInterface.isWebFengCloud()){
                return;
            }
            dragFiles = gkClientInterface.getDragFiles();
            topWindow.gkFrameCallback('showSelectFileDialog', {
                mountId: $scope.currentSession.mountid
            })
            $scope.hideTip();
        };

        var lastOffset = 0;
        $interval(function () {
            if (!chatContent.pendingMsg.length) {
                return;
            }
            angular.forEach(chatContent.pendingMsg, function (item, key) {
                if(item){
                    var metadata = item.metadata;
                    var info = gkClientInterface.getTransInfo({
                        mountid: metadata.mount_id,
                        webpath: metadata.fullpath
                    });
                    //上传完成
                    if (info.status == 1) {
                        lastOffset = 0;
                        item.offset = metadata.filesize;
                        chatContent.pendingMsg.splice(key, 1);
                        $timeout(function () {
                            item.file = gkClientInterface.getFileInfo({
                                mountid: metadata.mount_id,
                                webpath: metadata.fullpath
                            });
                            item.file.status = 3;
                            angular.extend(item.metadata, {
                                filehash: item.file.filehash,
                                hash: item.file.uuidhash
                            });
                        }, 500)
                        return;
                    } else {
                        var offset = Number(info.offset || 0);
                        if (offset <= lastOffset) {
                            return;
                        }
                        lastOffset = item.offset = offset;
                    }
                }
            })
        }, 1000);



//        $scope.quoteTopic = function(topic){
//            $scope.topic = topic;
//            toggleTopicLabel('show');
//            $timeout(function(){
//                $scope.focusTextarea = true;
//            })
//        };

        //点击只显示话题
        $scope.$on("onlyShowTopic",function($event,onlyShowTopic,topic){
            if (!$scope.currentSession) return;
            $scope.loadingHistoryMsg = true;
            $scope.onlyShowTopic = onlyShowTopic;
            $scope.topic = topic;
            $scope.currentMsgList = [];
            postedMsg = [];
            getList(minMsgTime,false, function () {
                $scope.loadingHistoryMsg = false;
                $scope.scrollToIndex = $scope.currentMsgList.length - 1;
            });
        });

        //点击用户名或头像at调用的方法
        $scope.atMember = function(at){
            $scope.$broadcast("atMember",at);
        };

       if(gkClientInterface.isWebFengCloud()) {
           $scope.$on('connectMsgList', function (obj, data) {
               var currentMaxTime = maxMsgTime;
               if(data.time && currentMaxTime < data.time){
                   currentMaxTime = data.time;
               }
               chatService.list($scope.currentSession.orgid, data.time - 1, maxCount, false).then(function (data) {
                  if (!data.error) {
                       angular.forEach(data.list, function (item) {
                           var time = Number(item.time);
                           if(time > currentMaxTime){
                               currentMaxTime = time;
                           }
                       });
                       topWindow.gkFrameCallback('ChatMessageUpdate', {
                           list:data.list
                       })
                   }
                   maxMsgTime = currentMaxTime;
                   //更新消息加载时间
                   topWindow.gkFrameCallback('openConnectMessage', {
                       maxMsgTime: currentMaxTime
                   })
               });
           });
       }
    }])
    .factory('chatContent', ['chatMember', function (chatMember) {
        var chatContent = {
            pendingMsg: [],
            formatItem: function (value) {
                var sender = chatMember.getMemberItem(value.receiver, value.sender);
                var extendValue = {
                    sender_name: value.sender_name ? value.sender_name : sender ? sender['member_name'] : value.sender,
                    is_vip: sender && sender.isvip ? true : false
                };
                if (value.metadata) {
                    try{
                        value.metadata = JSON.parse(value.metadata);
                    }catch(e){
                        value.metadata = '';
                        console.log(' JSON Parse Error',e);
                    }
                    if(value.type == 'screenshot' && value.metadata.filehash){
                        var param = {
                            filehash:value.metadata.filehash,
                            token:gkClientInterface.getToken()
                        };
                        var filePath = gkClientInterface.getScreenshotPath(param);
                        value.content = (filePath && filePath).path?filePath.path : "";
                        value.status = (value.content.length > 0)?1:0;
                    }
                    else if (value.metadata.mount_id || value.metadata.from_mount_id) {
                        //判断是拿子库id还是拿父库的id
                        var mountId = value.metadata.from_mount_id || value.metadata.mount_id;
                        value.metadata.mount_id = mountId;
                        value.metadata.mountid = mountId;
                        if (value.metadata.fullpath) {
                            value.metadata.filename = Util.String.baseName(value.metadata.fullpath);
                            value.metadata.ext = Util.String.getExt(value.metadata.filename);
                            value.metadata.webpath = value.metadata.fullpath;
                        }

                        var file = gkClientInterface.getFileInfo(value.metadata);
                        if (file && !jQuery.isEmptyObject(file)) {
                            file.mount_id = Number(mountId);
                            extendValue.file = file;
                        }
                    }
                }
                if(value.type == 'summary' && value.metadata) {
                    var summaryContent = gkClientInterface.getSummaryText(value.metadata.count, value.metadata.from, value.metadata.to);
                    if(summaryContent && summaryContent.length > 0) {
                        value.content = summaryContent;
                    }
                }
                angular.extend(value, extendValue);
                return value;
            },
            setItemError: function (msg, errorMsg) {
                msg.error = 1;
                msg.errorMsg = errorMsg;
            },
            add: function (msgList, newMsg, head) {
                head = angular.isDefined(head) ? head : false;
                newMsg = this.formatItem(newMsg);
                if (!msgList) {
                    msgList = [];
                }
                head ? msgList.unshift(newMsg) : msgList.push(newMsg);
                if (newMsg.type == 'file' && !newMsg.metadata.hash) {
                    this.pendingMsg.push(newMsg);
                }
                return newMsg;
            }
        };
        return chatContent;
    }])

    .factory('chatTopic', ['localStorageService',function (localStorageService) {
        var prefix = 'chat_topic_';
       var chatTopic = {
            get: function (orgId) {
                var re = localStorageService.get(prefix+orgId);
                if(!re){
                    return [];
                }
                return re;
            },
            add:function(orgId,val){
                if(!val) return;
                var oldVal = this.get(orgId);
                var time = new Date().getTime();
                if(!oldVal){
                    oldVal = [];
                }
                var index = -1;
                angular.forEach(oldVal,function(item,key){
                    if(item.value == val){
                        index = key;
                        return false;
                    }
                });
                if(index>=0){
                    oldVal[index].dateline = time;
                }else{
                    oldVal.push({
                        value:val,
                        dateline:time
                    });
                    if(oldVal.length>5){
                        oldVal.shift();
                    }
                }
                localStorageService.add(prefix+orgId, JSON.stringify(oldVal));
                return oldVal;
            }
        };
        return chatTopic;
    }])

    .directive('scrollToBottom', ['$timeout', function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {
                $scope.$watch($attrs.scrollToBottom, function (value) {
                    if (value == true) {
                        $timeout(function () {
                            $element.scrollTop($element[0].scrollHeight);
                        })
                        $scope[$attrs.scrollToBottom] = false;
                    }
                });
            }
        }
    }])

    .directive('chatFile', [function () {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/chat_file.html"
        }
    }])
    .directive('chatText', [function () {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/chat_text.html"
        }
    }])
    .directive('chatSummary', [function () {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/chat_summary.html"
        }
    }])
    .directive('chatExt', [function () {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/chat_ext.html"
        }
    }])
    .directive('chatAudio', [function () {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/chat_audio.html"
        }
    }])

