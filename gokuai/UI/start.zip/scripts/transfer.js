/**
 * Created by admin on 13-11-4.
 */
angular.module('LocalStorageModule').value('prefix', 'gkClientIndex');
angular.module('gkClientTransfer', ['gettext','GKCommon','gkClientIndex.directives','gkClientIndex.services','ui.bootstrap','gkClientIndex.filters','LocalStorageModule'])
    .run(['GKI18n',function (GKI18n) {
        GKI18n.setLocal();
    }])
    .controller('transferCtrl',['GKI18n','gettext','$scope','$location',function(GKI18n,gettext,$scope,$location){
        $scope.tabs = [
            {
                name:'upload',
                title:GKI18n.getText(gettext('上传')),
                icon:'icon_up',
                directive:'tabUpload'
            },
            {
                name:'download',
                title:GKI18n.getText(gettext('下载')),
                icon:'icon_down',
                directive:'tabDownload'
            }
        ];

        $scope.selectedTab = $scope.tabs[0];
        var search = $location.search();
        if(search.tab){
            $scope.selectedTab = Util.Array.getObjectByKeyValue($scope.tabs,'name',search.tab) || $scope.tabs[0];
        }

        $scope.selectTab = function(tab){
            $scope.selectedTab = tab;
        };

        $scope.cancel = function(){
            gkClientInterface.closeWindow();
        };

    }])

/**
 * 设置-上传
 */
    .directive('tabUpload',['GKI18n','gettext','GKQueue','$interval',function(GKI18n,gettext,GKQueue,$interval){
        return {
            restrict: 'E',
            templateUrl:'views/tab_queue.html',
            scope:{
                selectedTab:'='
            },
            link:function($scope){
                $scope.thead = [GKI18n.getText(gettext('文件')),GKI18n.getText(gettext('状态')),GKI18n.getText(gettext('剩余时间'))];
                var fileListTimer = GKQueue.getQueueList($scope,'upload');
                $scope.removeTransfer = function(file){
                    var param = {
                        type:'upload',
                        mountid:file.mountid,
                        webpath:file.webpath
                    };
                    gkClientInterface.removeTrans(param);
                }
                $scope.$on('$destroy',function(){
                    $interval.cancel(fileListTimer);
                    fileListTimer = null;
                })
            }
        }
    }])
/**
 * 设置-下载
 */
    .directive('tabDownload',['GKI18n','gettext','GKQueue','$interval',function(GKI18n,gettext,GKQueue,$interval){
        return {
            restrict: 'E',
            templateUrl:'views/tab_queue.html',
            scope:{
                selectedTab:'='
            },
            link:function($scope){
                $scope.thead = [GKI18n.getText(gettext('文件')),GKI18n.getText(gettext('状态')),GKI18n.getText(gettext('剩余时间'))];
                var fileListTimer = GKQueue.getQueueList($scope,'download');
                $scope.removeTransfer = function(file){
                    var param = {
                        type:'download',
                        mountid:file.mountid,
                        webpath:file.webpath,
                        fullpath:file.path
                    };
                    var re = gkClientInterface.removeTrans(param,function(){
                        Util.Array.removeByValue($scope.fileList,file);
                    });
                }

                $scope.$on('$destroy',function(){
                    if(fileListTimer){
                        $interval.cancel(fileListTimer);
                        fileListTimer = null;
                    }
                })
            }
        }
    }])
/**
 * 设置-同步
 */
    .directive('tabSync',['GKI18n','gettext','GKQueue','$interval',function(GKI18n,gettext,GKQueue,$interval){
        return {
            restrict: 'E',
            templateUrl:'views/tab_queue.html',
            scope:{
                selectedTab:'='
            },
            link:function($scope){
                $scope.thead = [GKI18n.getText(gettext('文件')),GKI18n.getText(gettext('状态')),GKI18n.getText(gettext('剩余时间'))];
                var fileListTimer =  GKQueue.getQueueList($scope,'sync');
                $scope.$on('$destroy',function(){
                    if(fileListTimer){
                        $interval.cancel(fileListTimer);
                        fileListTimer = null;
                    }
                })
            }
        }
    }])
    .filter('getQueueFileName',['GKMount',function(GKMount){
        return function(webPath,mountId){
            if(webPath){
                return Util.String.baseName(webPath);
            }else{
                return GKMount.getMountById(mountId)['name'];
            }
        }
    }])

;