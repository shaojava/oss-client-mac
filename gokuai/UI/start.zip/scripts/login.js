'use strict';
angular.module('LocalStorageModule').value('prefix', 'gkClientIndex');
angular.module('gkClientLogin', ['gettext', 'GKCommon', 'ngAnimate', 'angular-md5', 'gkClientIndex.services', 'gkClientIndex.directives', 'base64', 'ui.bootstrap', 'LocalStorageModule'])
    .run(['GKI18n', function (GKI18n) {
        GKI18n.setLocal();
    }])
    .controller('loginCtrl', ['GKI18n', 'gettext', '$scope', 'md5', 'GKApi', 'GKException', '$base64', function (GKI18n, gettext, $scope, md5, GKApi, GKException, $base64) {
        $scope.step = 'login';
        $scope.registDevice = gkClientInterface.getComputerInfo()['name'];
        $scope.siteDomain = gkClientInterface.getSiteDomain();
        $scope.loading = false;
        $scope.isShOnline = gkClientInterface.isShOnlineClient();
        $scope.logoUrl = 'images/login_logo.png';
        $scope.findpasswordUrl = $scope.siteDomain + '/findpassword';
        //判断是否是新东方
        $scope.isXDFClient = gkClientInterface.isXDFClient();

        var configInfo = gkClientInterface.getConfigInfo();
        if (configInfo) {
            if (configInfo['loginlogopath']) {
                $scope.logoUrl = configInfo['loginlogopath'];
            }
            if (configInfo['source']) {
                $scope.findpasswordUrl += '?source=' + configInfo['source'];
            }
        }

        /**
         * 登录
         */
        $scope.loginSubmit = function () {
            if ($scope.loading) return;
            if (!$scope.username || !$scope.username.length) {
                alert(GKI18n.getText(gettext('请输入用户名或邮箱')));
                return;
            }
            if (!$scope.password || !$scope.password.length) {
                alert(GKI18n.getText(gettext('请输入密码')));
                return;
            }
            var encodePassword = '';
            if ($scope.username.indexOf('/') >= 0 || $scope.username.indexOf('\\') >= 0) {
                encodePassword = encodeURIComponent($base64.encode($scope.password));
            } else {
                encodePassword = md5.createHash($scope.password);
            }
            $scope.loading = true;
            gkClientInterface.login({
                username: $scope.username,
                password: encodePassword
            });
        };

        $scope.showStep = function (step) {
            $scope.step = step;
        };

        /**
         * 监听登录结果的回调
         */
        $scope.$on('LoginResult', function ($event, params) {
            $scope.$apply(function () {
                $scope.loading = false;
                if (params.error != 0) {
                    alert(params.message);
                    return;
                } else {
                    $scope.showStep('device');
                }
            })
        })

        /**
         * 注册
         */
        $scope.registSubmit = function () {
            if ($scope.loading) return;
            if (!$scope.registUsername || !$scope.registUsername.length) {
                alert(GKI18n.getText(gettext('请输入用户名')));
                return;
            }
            if (!$scope.registEmail || !$scope.registEmail.length) {
                alert(GKI18n.getText(gettext('请输入邮箱')));
                return;
            }
            if (!Util.Validation.isEmail($scope.registEmail)) {
                alert(GKI18n.getText(gettext('请输入有效的邮箱地址')));
                return;
            }
            if (!$scope.registPassword || !$scope.registPassword.length) {
                alert(GKI18n.getText(gettext('请输入登录密码')));
                return;
            }
            if (!Util.Validation.isRegName($scope.registUsername)) {
                alert(GKI18n.getText(gettext('用户名只允许使用中文汉字、英文字母、数字或下划线')));
                return;
            }
            var password = $scope.registPassword;
            $scope.loading = true;
            GKApi.regist($scope.registUsername, $scope.registEmail, password, 1).success(function () {
                gkClientInterface.login({
                    username: $scope.registEmail,
                    password: md5.createHash($scope.registPassword)
                });
            }).error(function (request, textStatus, errorThrown) {
                $scope.$apply(function () {
                    $scope.loading = false;
                    GKException.handleAjaxException(request, textStatus, errorThrown);
                })
            });

        }

        $scope.setDevice = function () {
            if ($scope.loading) return;
            if (!$scope.registDevice.length) {
                alert(GKI18n.getText(gettext('请输入设备名')));
                return;
            }
            $scope.loading = true;
            gkClientInterface.setDevice({
                name: $scope.registDevice
            });
            $scope.loading = false;
        }

        $scope.handleKeyDown = function ($event) {
            var keyCode = $event.keyCode;
            if (keyCode == 13) {
                switch ($scope.step) {
                    case 'login':
                        if (!$scope.username) {
                            $scope.focus = 'username';
                            return;
                        }
                        if (!$scope.password) {
                            $scope.focus = 'password';
                            return;
                        }
                        $scope.loginSubmit();
                        break;
                    case 'regist':
                        if (!$scope.registUsername) {
                            $scope.focus = 'regist_username';
                            return;
                        }
                        if (!$scope.registPassword) {
                            $scope.focus = 'regist_password';
                            return;
                        }
                        if (!$scope.registEmail) {
                            $scope.focus = 'regist_email';
                            return;
                        }
                        $scope.registSubmit();
                        break;
                    case 'device':
                        if (!$scope.registDevice) {
                            $scope.focus = 'regist_device';
                            return;
                        }
                        $scope.setDevice();
                        break;
                }
            }
        }

        /**
         * youfu定制客户端不显示注册及找回密码
         */
        $scope.showRegistAndFindPwd = !gkClientInterface.isYoufuClient();

    }])
    .directive('oauthLogin', ['GKI18n', 'gettext', '$timeout', 'GKDialog', function (GKI18n, gettext, $timeout, GKDialog) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: 'views/auth_login.html',
            link: function ($scope, $element, $attrs) {
                $scope.oauthes = [];
                var oauth = ['qq', 'sina', 'mingdao'];
                var getOauthTextByName = function (name) {
                    var text = '';
                    switch (name) {
                        case 'qq':
                            text = GKI18n.getText(gettext('使用腾讯QQ帐号登录'));
                            break;
                        case 'sina':
                            text = GKI18n.getText(gettext('使用新浪微博帐号登录'));
                            break;
                        case 'mingdao':
                            text = GKI18n.getText(gettext('使用明道帐号登录'));
                            break
                    }
                    return text;
                };
                angular.forEach(oauth, function (value) {
                    $scope.oauthes.push({
                        name: value,
                        text: getOauthTextByName(value)
                    });
                })
                $scope.loginByOauth = function (oauth) {
                    var url = '';
                    var key = gkClientInterface.getOauthKey();
                    if (oauth.name == 'xdf') {
                        url = 'http://www.gokuai.com/autologin/xdf?key=' + key + '&logout=1'
                    } else {
                        url = 'http://www.gokuai.com/account/oauth?oauth=' + oauth.name + '&key=' + key + '&client=yk';
                    }
                    GKDialog.openUrl(url, {
                        width: 700,
                        height: 500
                    });
                }

                $scope.otherLogin = function () {
                    var key = gkClientInterface.getOauthKey();
                    var url = gkClientInterface.getSiteDomain() + '/account/sso_login?&key=' + key;
                    GKDialog.openUrl(url, {
                        width: 700,
                        height: 500
                    });
                }
            }
        };
    }])
    .directive('iframScroll', ['$timeout', function ($timeout) {
        return{
            restrict: 'A',
            link: function ($scope, $element, $attr) {
                var loadCount = 0;
                $element.load(function () {
                    if (loadCount > 0) {
                        $timeout(function () {
                            $element.parent().scrollTop(200);
                        })
                    }
                    loadCount++;
                })
            }
        }
    }])





