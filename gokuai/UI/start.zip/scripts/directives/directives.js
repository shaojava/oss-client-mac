'use strict';

/* Directives */
angular.module('gkClientIndex.directives', [])
    .directive('fileContextMenu', ['GKAuth','$rootScope','GKFileList','GKOpt','smartSearchConfig',function (GKAuth,$rootScope,GKFileList,GKOpt,smartSearchConfig) {
        return {
            restrict: 'A',
            link:function($scope, $element, $attrs ){
                jQuery.contextMenu({
                    selector:'.list_body',
                    reposition: false,
                    zIndex: 99,
                    animation: {
                        show: "show",
                        hide: "hide"
                    },
                    build:function(){
                        var searchFlag = 0;
                        if($scope.search.length){
                            searchFlag = 1;
                            //如果是高级搜索
                            var searchArr = $scope.search.split('|');
                            if(searchArr[1] == smartSearchConfig.name) {
                                searchFlag = 2;
                            }
                        }
                        var selectedFile = GKFileList.getSelectedFile();
                        var optKeys = GKOpt.getOpts($rootScope.PAGE_CONFIG.file, selectedFile, $rootScope.PAGE_CONFIG.partition, $rootScope.PAGE_CONFIG.filter, $rootScope.PAGE_CONFIG.mount, searchFlag);
                        var excludeRightOpts = [];
                        var rightOpts = {};
                        //右键操作项
                        angular.forEach(optKeys, function (value) {
                            if (excludeRightOpts.indexOf(value) < 0) {
                                var opt = $scope.allOpts[value];
                                if (opt) {
                                    if (value == 'open_opts' && jQuery.isEmptyObject(opt.items)) {
                                        return;
                                    }
                                    if (value != 'open_opts' && !!opt.items && jQuery.isEmptyObject(GKOpt.checkSubOpt(optKeys, opt.items))) {
                                        return;
                                    }
                                    if (value != 'open_opts' && opt.items) {
                                        var subItems = GKOpt.checkSubOpt(optKeys, opt.items);
                                        if (!jQuery.isEmptyObject(subItems)) {
                                            opt.items = subItems;
                                        }
                                    }
                                    rightOpts[value] = opt;
                                }
                            }
                        });
                        return {
                            items:rightOpts
                        };
                    }
                });

            }
        }
    }])
    .directive('checkAuth', ['GKAuth','$rootScope',function (GKAuth,$rootScope) {
        return {
            restrict: 'A',
            link:function(scope, element, attrs ){
                var checkAuth = attrs.checkAuth;
                scope.$watch('PAGE_CONFIG.mount',function(val){
                    var hasAuth = GKAuth.check(val,$rootScope.PAGE_CONFIG.partition,checkAuth);
                    if(!hasAuth){
                        element.hide();
                    }else{
                        element.show();
                    }
                })
            }
        }
    }])
    .directive('gkVersionContextmenu', ['GKI18n','gettext','$timeout','$rootScope','GKException','GKPath','GKPartition','GKMount','GKFileList','GKApi','GKFile','GKAuth',function (GKI18n,gettext,$timeout,$rootScope,GKException,GKPath,GKPartition,GKMount,GKFileList,GKApi,GKFile,GKAuth) {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {

                var getVersion =  function(triggerElem){
                    if(!triggerElem[0].dataset && gkClientInterface.isWebFengCloud()){
                        var attrs = triggerElem[0].attributes;
                        for(var i=attrs.length - 1;i>=0;i--){
                            if(attrs[i].nodeName == 'data-version'){
                                return triggerElem[0].attributes[i].nodeValue;
                            }
                        }
                    }else {
                        return Number(triggerElem[0].dataset.version);
                    }
                };

                var getDir =  function(triggerElem){
                    if(!triggerElem[0].dataset && gkClientInterface.isWebFengCloud()){
                        var attrs = triggerElem[0].attributes;
                        for(var i=attrs.length - 1;i>=0;i--){
                            if(attrs[i].nodeName == 'data-dir'){
                                return triggerElem[0].attributes[i].nodeValue;
                            }
                        }
                    }else {
                        return Number(triggerElem[0].dataset.dir);
                    }
                };

                var getFullpath =  function(triggerElem){
                    if(!triggerElem[0].dataset && gkClientInterface.isWebFengCloud()){
                        var attrs = triggerElem[0].attributes;
                        for(var i=attrs.length - 1;i>=0;i--){
                            if(attrs[i].nodeName == 'data-fullpath'){
                                return triggerElem[0].attributes[i].nodeValue;
                            }
                        }
                    }else {
                        return triggerElem.data('fullpath') || triggerElem[0].dataset.fullpath;
                    }
                };

                var getMountId = function(triggerElem){
                    if(!triggerElem[0].dataset && gkClientInterface.isWebFengCloud()){
                        var attrs = triggerElem[0].attributes;
                        for(var i=attrs.length - 1;i>=0;i--){
                            if(attrs[i].nodeName == 'data-mountid'){
                                return Number(triggerElem[0].attributes[i].nodeValue);
                            }
                        }
                    }else {
                        return Number(triggerElem[0].dataset.mountid);
                    }
                };

                var getHash = function(triggerElem){
                    if(!triggerElem[0].dataset && gkClientInterface.isWebFengCloud()){
                        var attrs = triggerElem[0].attributes;
                        for(var i=attrs.length - 1;i>=0;i--){
                            if(attrs[i].nodeName == 'data-hash'){
                                return triggerElem[0].attributes[i].nodeValue;
                            }
                        }
                    }else {
                        return triggerElem.data('hash') || triggerElem[0].dataset.hash;
                    }
                };

                var buildContextMenu = function(){
                    /**
                     * 设置右键菜单
                     */
                    jQuery.contextMenu({
                        selector: '#content > li',
                        reposition: true,
                        zIndex: 9999,
                        trigger:'right',
                        className: 'version_contextmenu',
                        events: {
                            show: function () {
                                this.addClass('hover');
                            },
                            hide: function () {
                                this.removeClass('hover');
                            }
                        },
                        build: function($trigger, e) {
                            var triggerElem = jQuery($trigger);
                            var dir = getDir(triggerElem);
                            var fullpath = getFullpath(triggerElem);
                            var mountId = getMountId(triggerElem);
                            var hash = getHash(triggerElem);
                            var items = {};
                            if(dir && dir == 1){
                                if(triggerElem.hasClass('act_0')){
                                    return;
                                }
                                items = {
                                    'open': {
                                        name: GKI18n.getText(gettext('打开')),
                                        callback: function (key,opt) {
                                            $timeout(function(){
                                                var file = gkClientInterface.getFileInfo({
                                                    mountid: Number(mountId),
                                                    uuidhash:hash
                                                });
                                                if(!file || !file.uuidhash){
                                                    alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                    return;
                                                }
                                                $rootScope.$broadcast("closeFileHistoryDialog");
                                                GKPath.gotoFile(mountId,file.path);
                                            })
                                        }
                                    },
                                    'saveto': {
                                        name: GKI18n.getText(gettext('下载')),
                                            callback: function (key,opt) {
                                            var file = gkClientInterface.getFileInfo({
                                                mountid: Number(mountId),
                                                uuidhash:hash,
                                                path:fullpath
                                            });
                                            if(!file || !file.uuidhash){
                                                alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                return;
                                            }
                                            if(!gkClientInterface.isWebFengCloud()) {
                                                var mount = GKMount.getMountById(file.mount_id);
                                                var filepath = file.fullpath || file.path;
                                                var permissions = GKFile.getFilePermit(file.mount_id, filepath, file);
                                                if (!GKAuth.checkPermit(mount, permissions, 'file_read')) {
                                                    alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                                                    return false;
                                                }
                                            }
                                            var param = {
                                                list:[{
                                                    mountid:mountId,
                                                    webpath:file.path,
                                                    dir:1
                                                }]
                                            }
                                            gkClientInterface.saveToLocal(param);
                                        }
                                     },
                                    'goto': {
                                        name: GKI18n.getText(gettext('位置')),
                                        callback: function (key,opt) {
                                            $timeout(function(){
                                                var file = gkClientInterface.getFileInfo({
                                                    mountid: Number(mountId),
                                                    uuidhash:hash,
                                                    path:fullpath
                                                });

                                                if(!file || !file.uuidhash){
                                                    alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                    return;
                                                }
                                                $rootScope.$broadcast("closeFileHistoryDialog");
                                                if(GKPartition.isSmartFolderPartition($rootScope.PAGE_CONFIG.partition)){
                                                    if(gkClientInterface.isWebFengCloud()){
                                                        GKApi.getMountPath(0, mountId).success(function (mountArr) {
                                                            if(! mountArr.list || mountArr.list.length == 0){
                                                                return mountId;
                                                            }
                                                            var mountIdPath = "";
                                                            angular.forEach( mountArr.list,function(mount){
                                                                mountIdPath+=mount.mountid + ".";
                                                            });
                                                            if(mountIdPath.length >0) {
                                                                mountIdPath = mountIdPath.substring(0, mountIdPath.length - 1);
                                                            }

                                                           GKPath.gotoFile(mountIdPath, Util.String.dirName(file.path), file.path);

                                                        });
                                                    }else {
                                                        var mountIdPath = GKMount.getMountPath(0, mountId);
                                                        GKPath.gotoFile(mountIdPath, Util.String.dirName(file.path), file.path);
                                                    }
                                                }else if($rootScope.PAGE_CONFIG.mount.mount_id != mountId){
                                                    var mountIdPath = $rootScope.PAGE_CONFIG.fullMountId;
                                                    GKPath.gotoFile(mountIdPath, Util.String.dirName(file.path), file.path);
                                                }else{
                                                    GKPath.gotoFile(mountId, Util.String.dirName(file.path), file.path);
                                                }
                                            })
                                        }
                                    }
                                };
                            }else{
                                if(triggerElem.hasClass('act_0')){
                                    return;
                                }
                                var version = getVersion(triggerElem);
                                items = {
                                    'open': {
                                        name: GKI18n.getText(gettext('打开')),
                                        callback: function (key,opt) {
                                            var file = gkClientInterface.getFileInfo({
                                                mountid: Number(mountId),
                                                uuidhash:hash,
                                                path:fullpath
                                            });
                                            if(!file || !file.uuidhash){
                                                alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                return;
                                            }
                                            if(!version){
                                                return;
                                            }
                                            if(!gkClientInterface.isWebFengCloud()) {
                                                var mount = GKMount.getMountById(file.mount_id);
                                                var filepath = file.fullpath || file.path;
                                                var permissions = GKFile.getFilePermit(file.mount_id, filepath, file);
                                                if (!GKAuth.checkPermit(mount, permissions, 'file_read')) {
                                                    alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                                                    return false;
                                                }
                                            }
                                            gkClientInterface.open({
                                                mountid:mountId,
                                                webpath:file.path||file.fullpath,
                                                version:version
                                            });
                                        }
                                    },
                                    'saveto': {
                                        name: GKI18n.getText(gettext('下载')),
                                        callback: function (key,opt) {
                                            var file = gkClientInterface.getFileInfo({
                                                mountid: Number(mountId),
                                                uuidhash:hash,
                                                path:fullpath
                                            });
                                            if(!gkClientInterface.isWebFengCloud()) {
                                                var mount = GKMount.getMountById(file.mount_id);
                                                var filepath = file.fullpath || file.path;
                                                var permissions = GKFile.getFilePermit(file.mount_id, filepath, file);
                                                if (!GKAuth.checkPermit(mount, permissions, 'file_read')) {
                                                    alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                                                    return false;
                                                }
                                            }
                                            if(gkClientInterface.isWebFengCloud()){
                                                GKApi.info(file.mountid,file.path).success(function(data){
                                                    file = data;
                                                    if(!file || file.cmd == 0){
                                                        alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                        return;
                                                    }
                                                    if(!version){
                                                        return;
                                                    }
                                                    var param = {
                                                        list:[{
                                                            mountid:mountId,
                                                            webpath:file.path || file.fullpath,
                                                            version:version
                                                        }]
                                                    }
                                                    gkClientInterface.saveToLocal(param);
                                                }).error(function(){
                                                    alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                    return;
                                                })
                                            }else{
                                                if(!file || !file.uuidhash){
                                                    alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                    return;
                                                }
                                                if(!version){
                                                    return;
                                                }
                                                var param = {
                                                    list:[{
                                                        mountid:mountId,
                                                        webpath:file.path,
                                                        version:version
                                                    }]
                                                }
                                                gkClientInterface.saveToLocal(param);
                                            }
                                        }
                                    },
                                    'goto': {
                                        name: GKI18n.getText(gettext('位置')),
                                        callback: function (key,opt) {
                                            $timeout(function(){
                                                var file = gkClientInterface.getFileInfo({
                                                    mountid: Number(mountId),
                                                    uuidhash:hash,
                                                    path:fullpath
                                                });

                                                if(!file || !file.uuidhash){
                                                    alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                    return;
                                                }
                                                $rootScope.$broadcast("closeFileHistoryDialog");
                                                if(GKPartition.isSmartFolderPartition($rootScope.PAGE_CONFIG.partition)){
                                                    if(gkClientInterface.isWebFengCloud()){
                                                        GKApi.getMountPath(0, mountId).success(function (mountArr) {
                                                            if(!mountArr.list || mountArr.list.length == 0){
                                                                return mountId;
                                                            }
                                                            var mountIdPath = "";
                                                            angular.forEach( mountArr.list,function(mount){
                                                                mountIdPath+=mount.mountid + ".";
                                                            });
                                                            if(mountIdPath.length >0) {
                                                                mountIdPath = mountIdPath.substring(0, mountIdPath.length - 1);
                                                            }
                                                            $timeout(function () {
                                                                GKPath.gotoFile(mountIdPath, Util.String.dirName(file.path), file.path);
                                                            })
                                                        });
                                                    }else {
                                                        var mountIdPath = GKMount.getMountPath(0, mountId);
                                                        GKPath.gotoFile(mountIdPath, Util.String.dirName(file.path), file.path);
                                                    }
                                                }else if($rootScope.PAGE_CONFIG.mount.mount_id != mountId){
                                                    var mountIdPath = $rootScope.PAGE_CONFIG.fullMountId;
                                                    GKPath.gotoFile(mountIdPath, Util.String.dirName(file.path), file.path);
                                                }else{
                                                    GKPath.gotoFile(mountId, Util.String.dirName(file.path), file.path);
                                                }
                                            })
                                        }
                                    },
                                    'recover': {
                                        name: GKI18n.getText(gettext('还原')),
                                        callback: function (key,opt) {
                                            var file = gkClientInterface.getFileInfo({
                                                mountid: Number(mountId),
                                                uuidhash:hash,
                                                path:fullpath
                                            });
                                            if(!gkClientInterface.isWebFengCloud()) {
                                                var mount = GKMount.getMountById(file.mount_id);
                                                var filepath = file.fullpath || file.path;
                                                var permissions = GKFile.getFilePermit(file.mount_id, filepath, file);
                                                if (!GKAuth.checkPermit(mount, permissions, 'file_write')) {
                                                    alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                                                    return false;
                                                }
                                            }
                                            if(gkClientInterface.isWebFengCloud()){
                                                GKApi.info(file.mountid,file.path).success(function(data) {
                                                    file = data;
                                                    if (!file || file.cmd == 0) {
                                                        alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                        return;
                                                    }
                                                    var param = {
                                                          mountid:Number(mountId),
                                                          fullpath:fullpath,
                                                          version:version
                                                    }
                                                    gkClientInterface.revert(param,function(data){
                                                           if(data.error &&  data.error == 0 && !data.message){
                                                               alert(GKI18n.getText(gettext("还原成功")));
                                                           }else{
                                                                alert(data.message);
                                                           }
                                                    });
                                                }).error(function(){
                                                    alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                    return;
                                                });
                                            }else {
                                                if (!file || !file.uuidhash) {
                                                    alert(GKI18n.getText(gettext('文件不存在或已删除')));
                                                    return;
                                                }
                                                if (!version) {
                                                    return;
                                                }
                                                gkClientInterface.revert({
                                                    mountid: mountId,
                                                    webpath: file.path,
                                                    version: version
                                                }, function (msg) {
                                                    if (!msg.error) {
                                                        angular.extend(msg, {
                                                            mount_id: mountId
                                                        });
                                                        alert(GKI18n.getText(gettext('恢复成功')));
                                                        $rootScope.$broadcast('UpdateFileInfo', msg);
                                                    } else {
                                                        GKException.handleClientException(msg);
                                                    }
                                                });
                                            }
                                        }
                                    }
                                };
                            }

                            if(gkClientInterface.isWebFengCloud()){
                                 if(items.open){
                                     delete items.open;
                                 }
                            }
                            return {
                                items:items
                            };
                        }
                    });
                }

                $scope.$watch($attrs.gkVersionContextmenu,function(newValue){
                    if(!newValue){
                        jQuery.contextMenu('destroy', '#content > li');
                    }else{
                        buildContextMenu(false);
                    }
                });

                $scope.$on('showContextMenu',function(obj,event,index,history){
                    var current_x =  event.originalEvent.clientX ||event.originalEvent.x ;
                    var current_y = event.originalEvent.clientY || event.originalEvent.y;
                    $('#content > li:eq('+index+')').contextMenu({x: current_x, y: current_y});
                });
                $scope.$on('$destroy',function(){
                    jQuery.contextMenu('destroy', '#content > .item');
                })
            }
        }
    }])
    .directive('fixScroll', ['$timeout', function ($timeout) {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {
                /**
                 * fix列表出现滚动条后列表头部对不齐的问题
                 */
                var checkScroll = function (elem) {
                    var scrollY = false;
                    var st = elem.scrollTop();
                    elem.scrollTop(st > 0 ? -1 : 1);
                    if (elem.scrollTop() !== st) {
                        scrollY = scrollY || true;
                    }
                    elem.scrollTop(st);
                    return scrollY;
                }

                var setListHeaderWidth = function () {
                    if (checkScroll($element.find('.list_body'))) {
                        $element.find('.file_list_header,.file_list_hint').css('right', 8);
                    } else {
                        $element.find('.file_list_header,.file_list_hint').css('right', 0);
                    }
                };

                jQuery(window).on('resize.fixScroll', function () {
                    setListHeaderWidth();
                });

                var fixTimer;

                fixTimer = $timeout(function () {
                    setListHeaderWidth();
                }, 0);

                $scope.$on('$locationChangeSuccess',function(){
                    if (fixTimer) {
                        $timeout.cancel(fixTimer);
                        fixTimer = null;
                    }
                     fixTimer = $timeout(function () {
                        setListHeaderWidth();
                    }, 0);
                })

                $scope.$on('$destroy', function () {
                    jQuery(window).off('resize.fixScroll');
                    if (fixTimer) {
                        $timeout.cancel(fixTimer);
                        fixTimer = null;
                    }
                    setListHeaderWidth = checkScroll = null;
                })
            }
        };
    }])
    .directive('keybroadNav', ['GKFileList', 'GKOpt','$rootScope',function (GKFileList,GKOpt,$rootScope) {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {
                var getColCount = function () {
                    var colCount = 4;
                    if ($scope.view == 'thumb' && $element.find('.file_item').size()) {
                        colCount = Math.floor($element.width() / $element.find('.file_item').eq(0).outerWidth(true));
                    }
                    return colCount;
                };

                /**
                 * up left 键
                 * @param $event
                 */
                var upLeftPress = function ($event) {
                    if (['INPUT', 'TEXTAREA'].indexOf($event.target.nodeName) >= 0) {
                        return;
                    }
                    /**
                     * 非所缩略图模式不激活左右键
                     */
                    if ($scope.view != 'thumb' && $event.keyCode == 37) {
                        return;
                    }
                    var step = 1;
                    if ($scope.view == 'thumb' && $event.keyCode == 38) {
                        step = getColCount();
                    }
                    /**
                     * 初始index是最后一个
                     * @type {number}
                     */
                    var initIndex = $scope.fileData.length + step - 1;
                    /**
                     * 如果已经选中，则取已选中的最小一个
                     */
                    var selectedIndex = GKFileList.getSelectedIndex();
                    if (selectedIndex.length) {
                        initIndex = Math.min.apply('', selectedIndex);
                    }
                    var newIndex = initIndex - step;
                    if (newIndex < 0) {
                        newIndex = 0;
                    }

                    if ($event.shiftKey) {
                        for (var i = (initIndex > ($scope.fileData.length - 1) ? $scope.fileData.length - 1 : initIndex); i >= newIndex; i--) {
                            GKFileList.select($scope, i, true);
                        }
                    } else {
                        GKFileList.unSelectAll($scope);
                        GKFileList.select($scope, newIndex);
                        $scope.shiftLastIndex = newIndex;
                    }
                };

                /**
                 * down right 键
                 * @param $event
                 */
                var downRightPress = function ($event) {
                    if (['INPUT', 'TEXTAREA'].indexOf($event.target.nodeName) >= 0) {
                        return;
                    }
                    /**
                     * 非所缩略图模式不激活左右键
                     */

                    if ($scope.view != 'thumb' && $event.keyCode == 39) {
                        return;
                    }
                    var step = 1;
                    if ($scope.view == 'thumb' && $event.keyCode == 40) {
                        step = getColCount();
                    }
                    /**
                     * 初始index是第一个
                     * @type {number}
                     */
                    var initIndex = -1 * step;
                    /**
                     * 如果已经选中，则取已选中的最大一个
                     */
                    var selectedIndex = GKFileList.getSelectedIndex();
                    if (selectedIndex.length) {
                        initIndex = Math.max.apply('', selectedIndex);
                    }
                    var newIndex = initIndex + step;
                    if (newIndex > $scope.fileData.length - 1) {
                        newIndex = $scope.fileData.length - 1;
                    }
                    if ($event.shiftKey) {
                        for (var i = (initIndex > 0 ? initIndex : 0); i <= newIndex; i++) {
                            GKFileList.select($scope, i, true);
                        }
                    } else {
                        GKFileList.unSelectAll($scope);
                        GKFileList.select($scope, newIndex, true);
                        $scope.shiftLastIndex = newIndex;
                    }
                };
                $scope.$on("openSmartDesktop",function(){
                    $scope.triggleOptByShortCut(GKOpt.getAccessKey('open_smart_desktop'));
                })
                /**
                 * 监听键盘事件
                 */
                jQuery(document).on('keydown.shortcut', function ($event) {
                    //如果是回收站则不允许快捷键
                    if($rootScope.PAGE_CONFIG && $rootScope.PAGE_CONFIG.filter == 'trash'){
                        return false;
                    }
                    
                    if (['INPUT', 'TEXTAREA'].indexOf($event.target.nodeName) >=0) {
                       return;
                    }
                    $scope.$apply(function () {
                        var ctrlKeyOn = $event.ctrlKey || $event.metaKey;
                        switch ($event.keyCode) {
                            case 8: //backspace
                                $event.preventDefault();
                                break;
                            case 13: //enter
                                var selectedFile = GKFileList.getSelectedFile();
                                if (selectedFile && selectedFile.length) {
                                    $scope.handleDblClick(selectedFile[0]);
                                }
                                $event.preventDefault();
                                break;
                            case 68://D
                                if (ctrlKeyOn) {
                                    $scope.triggleOptByShortCut(GKOpt.getAccessKey('open_smart_desktop'));
                                }
                                $event.preventDefault();
                                break;
                            case 37: //up
                            case 38: //left
                                upLeftPress($event);
                                $event.preventDefault();
                                break;
                            case 39: //down
                            case 40: //right
                                downRightPress($event);
                                $event.preventDefault();
                                break;
                            case 46: //Delete
                                $scope.triggleOptByShortCut(GKOpt.getAccessKey('del'));
                                $event.preventDefault();
                                return false;
                                break;
                            case 67: //c
                                if (ctrlKeyOn) {
                                    $scope.triggleOptByShortCut(GKOpt.getAccessKey('copy'));
                                }
                                $event.preventDefault();
                                return false;
                                break;
                            case 80: //p
                                if(!gkClientInterface.isWebFengCloud()) {
                                    if (ctrlKeyOn) {
                                        $scope.triggleOptByShortCut(GKOpt.getAccessKey('view_property'));
                                    }
                                }
                                $event.preventDefault();
                                break;
                            case 83: //s
                                if (ctrlKeyOn) {
                                    $scope.triggleOptByShortCut(GKOpt.getAccessKey('save'));
                                }
                                $event.preventDefault();
                                break;
                            case 86: //v
                                if (ctrlKeyOn) {
                                    $scope.triggleOptByShortCut(GKOpt.getAccessKey('paste'));
                                }
                                $event.preventDefault();
                                break;
                            case 88: //x
                                if (ctrlKeyOn) {
                                    $scope.triggleOptByShortCut(GKOpt.getAccessKey('cut'));
                                }
                                $event.preventDefault();
                                break;
                        }
                    });
                });


                $scope.$on('$destroy', function () {
                    jQuery(document).off('keydown.shortcut')
                    getColCount = upLeftPress = downRightPress = null;

                })
            }
        };
    }])
    .directive('renameFile', ['GKI18n','gettext','$parse', function (GKI18n,gettext,$parse) {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {
                var fileItem = $element,
                    input,
                    nameElem;
                var fn = $parse($attrs.renameFileSubmit);

                var clear = function(){
                    fileItem.removeClass('file_item_edit');
                    if (input) {
                        input.remove();
                        input = null;
                    }
                    if (nameElem) {
                        nameElem.show();
                        nameElem = null;
                    }
                }
                $scope.$watch($attrs.renameFile, function (value, oldValue) {
                    if (value == oldValue) return;
                    if (value == true) {
                        var oldFileName = Util.String.baseName($element.data('fullpath'));
                        var dir = $element.data('dir');
                        input = jQuery('<input name="new_file_name" type="text" id="new_file_name" value="' + oldFileName + '" class="new_file_name form-control" />');
                        fileItem.addClass('file_item_edit');
                        nameElem = fileItem.find('.name');
                        nameElem.hide().after(input);
                        var selectionEnd = oldFileName.length;
                        var extIndex = oldFileName.lastIndexOf('.');
                        if (dir == 0 && extIndex > 0) {
                            selectionEnd = extIndex;
                        }
                        input[0].selectionStart = 0;
                        input[0].selectionEnd = selectionEnd;
                        input.focus();
                        var submit = function(){
                            var newFileName = jQuery.trim(input.val());
                            if (!newFileName.length) newFileName = oldFileName;
                            var extIndex = newFileName.lastIndexOf('.');
                            if(extIndex>=0 && !jQuery.trim(newFileName.slice(0,extIndex))){
                                alert( GKI18n.getText(gettext('请输入文件名')));
                                newFileName = oldFileName;
                            }
                            fn($scope, {filename: newFileName});
                        };

                        input.on('keydown', function (e) {
                            if (e.keyCode == 13) {
                                submit();
                                return false;
                            }
                        });
                        input.on('blur', function () {
                            submit();
                        })
                        input.on('dblclick', function () {
                            submit();
                        })
                    } else {
                        clear();
                    }
                });


                $scope.$on('$destroy',function(){
                    clear();
                })

                $scope.$on('$locationChangeSuccess',function(){
                    clear();
                })
            }
        };
    }])
    .directive('createNewFolder', ['GKFileList', '$compile', '$parse', function (GKFileList, $compile, $parse) {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {
                var newFileItem,
                    fn = $parse($attrs.createFileSubmit);
                $scope.$watch($attrs.createNewFolder, function (value, oldValue) {
                    if (value == oldValue) return;
                    if (value == true) {
                        $element.scrollTop(0);
                        var newFileExt = $attrs.createNewFileExt;
                        var dir = 0;
                        if(!newFileExt){
                            dir = 1 ;
                        }
                        var defaultNewName = GKFileList.getDefualtNewName($scope,newFileExt);
                        var isShare = 0;
                        var isSync = $scope.PAGE_CONFIG.file.syncpath ? 1 : 0;
                        GKFileList.unSelectAll($scope);
                        $scope.submitNewFileName = function (filename) {
                            if (!filename.length) {
                                filename = defaultNewName
                            }
                            if(newFileExt){
                                var ext = Util.String.getExt(filename);
                                if(ext != newFileExt){
                                    filename+='.'+newFileExt;
                                }
                            }

                            fn($scope, {filename: filename,dir:dir});
                        };

                        newFileItem = $compile(angular.element('<new-file-item dir="{{'+dir+'}}" view="{{view}}" default-new-name="' + defaultNewName + '" is-share="{{' + isShare + '}}" is-sync="{{' + isSync + '}}" on-submit="submitNewFileName(filename)"></new-file-item>'))($scope);
                        newFileItem.addClass('selected').prependTo($element);
                    } else {
                        if (newFileItem) {
                            newFileItem.remove();
                        }
                    }
                });

                $scope.$on('$destroy',function(){
                  if(newFileItem){
                      newFileItem.remove();
                      newFileItem = null;
                  }
                })

                $scope.$on('$locationChangeSuccess',function(){
                    if(newFileItem){
                        newFileItem.remove();
                        newFileItem = null;
                    }
                })
            }
        };
    }])
    .directive('editsmartContextmenu',['GKI18n','gettext','GKModal',function(GKI18n,gettext,GKModal){
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {
                /**
                 * 设置右键菜单
                 */
                jQuery.contextMenu({
                    selector: '.smart_desktop_item .item .item_container',
                    reposition: false,
                    zIndex: 9999,
                    className: 'smart_right_contextmenu',
                    animation: {
                        show: "show",
                        hide: "hide"
                    },

                    events: {
                        show: function () {
                            this.addClass('hover');
                        },
                        hide: function () {
                            this.removeClass('hover');
                        }
                    },
                    build: function ($trigger, e) {
                        var   items = {
                            'editSmartName': {
                                name:  GKI18n.getText(gettext('编辑')),
                                callback: function () {
                                    var data = $trigger.data('branch');
                                    GKModal.editSmartFolder(data);
                                }
                            }
                        }
                        return {
                            callback: function () {

                            },
                            items: items
                        }
                    }
                });
            }
        }
    }])
    .directive('contextmenu', ['GKContextMenu', function (GKContextMenu) {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {
                /**
                 * 设置右键菜单
                 */
                jQuery.contextMenu({
                    selector: '.left_sidebar .abn-tree .abn-tree-row',
                    reposition: false,
                    zIndex: 9999,
                    className: 'sidebar_contextmenu',
                    animation: {
                        show: "show",
                        hide: "hide"
                    },
                    events: {
                        show: function () {
                            this.addClass('hover');
                        },
                        hide: function () {
                            this.removeClass('hover');
                        }
                    },
                    build: function ($trigger, e) {
                        var items = GKContextMenu.getSidebarMenu($trigger);
                        return {
                            callback: function () {

                            },
                            items: items
                        }
                    }
                });
            }
        }
    }])
    .directive('queueItem', [function () {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: 'views/queue_item.html'
        }
    }])
    .directive('queueSyncItem', [function () {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: 'views/queue_sync_item.html'
        }
    }])
    .directive('networkUnconnect', [function () {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: 'views/network_unconnect.html'
        }
    }])
    .directive('newFileItem', ['GKI18n','gettext','$timeout', function (GKI18n,gettext,$timeout) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: 'views/new_file_item.html',
            scope: {
                'onSubmit': '&',
                'view': '@',
                'isShare': '@',
                'isSync': '@',
                'defaultNewName': '@',
                'dir':'@'
            },
            link: function ($scope, $element, $attrs) {
                $scope.filename = $scope.defaultNewName ? $scope.defaultNewName :  GKI18n.getText(gettext('新建文件夹'));
                var input = $element.find('input');
                var submit = function(){
                    if ($scope.onSubmit != null) {
                        var extIndex = $scope.filename.lastIndexOf('.');
                        if(extIndex>=0 && !jQuery.trim($scope.filename.slice(0,extIndex))){
                            alert( GKI18n.getText(gettext('请输入文件名')));
                            $scope.filename = $scope.defaultNewName;
                            reset();
                            return;
                        }
                        $scope.onSubmit({
                            filename: $scope.filename
                        });
                    }
                };
                input.on('blur', function (event) {
                    submit();
                })

                input.on('keydown', function (event) {
                    if (event.keyCode == 13) {
                        $scope.$apply(function () {
                            submit();
                        });
                    }
                });
                var reset = function(){
                    $timeout(function () {
                        input[0].select();
                        var selectionEnd = $scope.defaultNewName.length;
                        var extIndex = $scope.defaultNewName.lastIndexOf('.');
                        if ($scope.dir == 0 && extIndex > 0) {
                            selectionEnd = extIndex;
                        }
                        input[0].selectionStart = 0;
                        input[0].selectionEnd = selectionEnd;
                        input.focus();
                    }, 0)
                };

                reset();

                $scope.$on('$destroy', function () {
                    input.off('blur').off('keydown');
                    input = null;
                })
            }
        }
    }])
    .directive('editName', [function () {
        return {
            restrict: 'A',
            link: function ($scope, $element, $attrs) {

            }
        }
    }])
    .directive('gkinput', [function () {
        return {
            restrict: 'E',
            link: function (scope, element, attrs) {

            }
        }
    }])
    .directive('uiSelectable', ['uiSelectableConfig', 'GKFileList', function (uiSelectableConfig, GKFileList) {
        return {
            restrict: 'A',
            require: ['ngModel'],
            link: function (scope, element, attrs, ctrlArr) {

                var ngModel = ctrlArr[0];
                var uiSelectableDragDropCtrl = ctrlArr[1];

                function combineCallbacks(first, second) {
                    if (second && (typeof second === "function")) {
                        return function (e, ui) {
                            first(e, ui);
                            second(e, ui);
                        };
                    }
                    return first;
                }

                var opts = { filter: 'li' };
                angular.extend(opts, uiSelectableConfig);

                var callbacks = {
                    selected: null,
                    selecting: null,
                    start: null,
                    stop: null,
                    unselected: null,
                    unselecting: null
                };

                if (ngModel) {
                    ngModel.$render = function () {
                        element.selectable("refresh");
                    };
                    callbacks.selected = function (e, ui) {
                        scope.$apply(function () {
                            GKFileList.select(scope, jQuery(ui.selected).index(), true);
                        })
                    };
                    callbacks.stop = function (e, ui) {

                    };
                    callbacks.start = function (e, ui) {
                        scope.$apply(function () {
                            GKFileList.unSelectAll(scope);
                        })
                    };
                    callbacks.unselected = function (e, ui) {
                        scope.$apply(function () {
                            GKFileList.unSelect(scope, jQuery(ui.selected).index());
                        })
                    };
//                    callbacks.selecting = function(e, ui) {
//                        var offsetParent = $(ui.selecting).offsetParent();
//                        var position = $(ui.selecting).position();
//                        var grid = position.top - offsetParent.height();
//                        if(grid-20>0){
//                            offsetParent.scrollTop(grid);
//                        }
//                    };
                }

                angular.forEach(callbacks, function (value, key) {
                    opts[key] = combineCallbacks(value, opts[key]);
                });
                element.selectable(opts);
            }
        };
    }])
    .directive('loadingEllipsis', ['$interval', function ($interval) {
        return {
            replace: true,
            restrict: 'E',
            template: '<span ng-bind="ellipsis" style="margin: 0 0 0 3px"></span>',
            link: function ($scope) {
                var cell = '. ';
                $scope.ellipsis = '';
                var max = cell.length * 3;
                $interval(function () {
                    if ($scope.ellipsis.length >= max) {
                        $scope.ellipsis = '';
                    } else {
                        $scope.ellipsis += cell;
                    }
                }, 500)
            }
        }
    }])
    .directive('nofileRightSidebar', [function () {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/nofile_right_sidebar.html"
        }
    }])
    .directive('member', ['GKI18n','gettext','GKPartition','GKDialog', '$rootScope', 'localStorageService','$interval','GKModal','GKNews','GKApi','$timeout','GKBrowserMode',function (GKI18n,gettext,GKPartition,GKDialog,$rootScope,localStorageService,$interval,GKModal,GKNews,GKApi,$timeout,GKBrowserMode) {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/member.html",
            scope: {
                user: '=',
                mode:'=',
                selectBranch:'='
            },
            link: function ($scope, $element) {
                var unreadMsgKey = $rootScope.PAGE_CONFIG.user.member_id+'_unreadmsg';
                $timeout(function(){
                    $scope.newMsg = !!localStorageService.get(unreadMsgKey);
                    $scope.openNews = function(){
                        GKModal.news(GKNews, GKApi);
                    }
                },1500);
                var t,count = 0;
                //判断是否是新东方客户端
                $scope.isXDFClient = $rootScope.isXDFClient;

                $scope.$on('UpdateMessage', function (e,data) {
                        if(t){
                            $interval.cancel(t);
                        }
                        t = $interval(function(){
                            if(count==10){
                                if(t){
                                    $interval.cancel(t);
                                    count = 0;
                                }
                                $scope.newMsg = true;
                                localStorageService.add(unreadMsgKey,$scope.newMsg);
                                return;
                            }
                            $scope.newMsg = !$scope.newMsg;
                            count++;
                        },150);
                })

                $scope.$on('newsOpen',function(){
                    if(t){
                        $interval.cancel(t);
                        count = 0;
                    }
                    $scope.newMsg = false;
                    localStorageService.remove(unreadMsgKey);
                    gkClientInterface.clearMessage();
                })

                $scope.$on("openNews",function(){
                    GKModal.news(GKNews, GKApi);
                });
                $scope.$on("personalOpen",function(){
                    GKDialog.openSetting('account');
                });

                $scope.personalOpen = function ($scope) {
                    GKDialog.openSetting('account');
                };

                $scope.handleCreate = function () {
                    GKModal.createTeam();
                };

                $scope.handleAdd = function () {
                    GKModal.joinTeam();
                };

                $scope.gotoUpgrade = function () {
                    var url = gkClientInterface.getUrl({
                        sso:1,
                        url: gkClientInterface.getSiteDomain()+'/pay/order'
                    });
                    gkClientInterface.openUrl(url);
                };

                var hideTimer;

                var settingsWrapper = $element.find('.setting_wrapper_dropdown');

                $element.find('.account_info,.setting_wrapper_dropdown').on('mouseenter',function(){
                    if(hideTimer){
                       $timeout.cancel(hideTimer);
                    }
                    settingsWrapper.fadeIn(100);
                    $element.addClass('hover');
                })

                $element.find('.account_info,.setting_wrapper_dropdown').on('mouseleave',function(){
                    //return;
                    hideTimer = $timeout(function(){
                        settingsWrapper.fadeOut(100);
                        $element.removeClass('hover');
                    },200)
                })

                $element.find('.toggle_btn_wrapper').click(function(){
                    var $this = jQuery(this);
                    $scope.$apply(function(){
                        if($this.hasClass('toggle_btn_2')){
                            GKBrowserMode.setMode('chat');
                            $this.removeClass('toggle_btn_2');
                            //判断是否为智能文件夹
                            if(GKPartition.isSmartFolderPartition($rootScope.PAGE_CONFIG.partition)){
                                $rootScope.$broadcast("initSelectedBranch");
                            }
                        }else{
                            GKBrowserMode.setMode('file');
                            $this.addClass('toggle_btn_2');
                        }
                    })
                });
                $scope.smartTitle = function(){
                    if(gkClientInterface.isWindowsClient())
                    {
                        return GKI18n.getText(gettext('智能桌面(Ctrl+D)'));
                    }else if(gkClientInterface.isMacClient()){
                        return GKI18n.getText(gettext('智能桌面(⌘+D)'));
                    }else{
                        return '';
                    }

                }
                //打开智能桌面
                $scope.openSmartDesktop = function(){
                    GKModal.smartDesktop($scope.selectBranch);
                }
            }
        }
    }])
    .directive('singlefileRightSidebar', ['GKI18n','gettext','GKFilter', 'GKSmartFolder', '$timeout', 'GKApi', '$rootScope', 'GKModal', 'GKException', 'GKPartition', 'GKFile', 'GKMount', '$interval', 'GKDialog','GKChat','GKPath','$location','GKAuth','$filter','$document','GKMode','GKCilpboard','GKFileList',function (GKI18n,gettext,GKFilter, GKSmartFolder, $timeout, GKApi, $rootScope, GKModal, GKException, GKPartition, GKFile, GKMount, $interval,GKDialog,GKChat,GKPath,$location,GKAuth,$filter,$document,GKMode,GKCilpboard,GKFileList) {
        return {
            replace: true,
            restrict: 'E',
            scope: true,
            templateUrl: "views/singlefile_right_sidebar.html",
            link: function ($scope, $element) {
                $scope.file;
                $scope.fileExist = true;
                var fileInterval,
                    lastGetRequest;
                $scope.smarts = GKSmartFolder.getFolders(['recent','recent_visit']);
                var getOptMountId = function (file) {
                    var mountID;
                    if (!file) {
                        mountID = $rootScope.PAGE_CONFIG.fullMountId;
                    } else {
                        mountID = file['mount_id'] || $rootScope.PAGE_CONFIG.fullMountId;
                    }
                    mountID = Util.object.getCurrentMountId(mountID);
                    return mountID
                };

                var getFileState = function (mountId, fullpath) {
                    //网络断开后不重新连接
                    if($rootScope.PAGE_CONFIG.networkConnected ==0){
                        return;
                    }
                    var info = gkClientInterface.getTransInfo({
                        mountid: mountId,
                        webpath: fullpath
                    });
                    if (info.status == 1) {
                        $scope.sidbarData.icon = '';
                        if (fileInterval) {
                            $interval.cancel(fileInterval);
                            fileInterval = null;
                        }
                        getFileInfo($scope.localFile);
                        return;
                    }
                    if (info.offset == 0 || info.offset === undefined) {
                        $scope.sidbarData.title =  GKI18n.getText(gettext('准备上传中'));
                    } else {
                        var offset = Number(info.offset);
                        var filesize = Number(info.filesize || 0);
                        if (filesize != 0) {
                            if (offset != 0) {
                                var str = Math.round(offset / filesize * 100) + '%';
                                $scope.sidbarData.title =  GKI18n.getText(gettext('正在上传中')) + str;
                            }
                        } else {
                            $scope.sidbarData.title =  GKI18n.getText(gettext('正在上传中'));
                        }
                    }
                };

                var getFileInfo = function (file, options) {
                    if (fileInterval) {
                        $interval.cancel(fileInterval);
                        fileInterval = null;
                    }
                    if(lastGetRequest){
                        lastGetRequest.abort();
                        lastGetRequest = null;
                    }

                    var defaultOptions = {
                        data: '',
                        cache: true,
                        first:false
                    };

                    options = angular.extend({}, defaultOptions, options);
                    var mountId = getOptMountId(file);
                    var mount = GKMount.getMountById(mountId);
                    var fullpath = file.dir == 1 ? file.fullpath + '/' : file.fullpath;
                    var extParam = {
                        type:''
                    };
                    if(!file || (file.moun_id && !file.fullpath)){
                        return;
                    }
                    $scope.fileExist = true;

                    lastGetRequest = GKApi.info(mountId, fullpath,extParam).success(function (data) {
                        $scope.$apply(function () {
                            var formatFile = GKFile.formatFileItem(data, 'api');
                            $scope.file.favorite=formatFile.favorite;
                            formatFile.property = $scope.file.property;
                            if(gkClientInterface.isWebFengCloud() && formatFile.hash){
                                $scope.file = formatFile;
                                $scope.showSync = true;
                                $scope.showChatBtn = GKAuth.check(mount, '', 'file_discuss');
                                $scope.showLinkBtn = mount.ent_id == 0 || GKAuth.check(mount, '', 'file_link');
                                $scope.showHistory = GKAuth.check(mount, '', 'file_history');
                            }
                        });
                    }).error(function (request,textStatus,errorThrown) {
                        var errorCode = GKException.getAjaxErroCode(request);
                        if (errorCode == 404 || String(errorCode).slice(0, 3) != '404') {
                            return;
                        }
                        if (errorCode == 40402 && $scope.localFile.status != 1) {
                            $scope.fileExist = false;
                            $scope.sidbarData = {
                                icon: 'trash',
                                title: '云端已删除'
                            };
                            return;
                        }
                        $scope.sidbarData = {
                            icon: 'uploading'
                        };
                        getFileState(mountId, file.fullpath);
                        fileInterval = $interval(function () {
                            getFileState(mountId, file.fullpath);
                        }, 1000);

                    });
                };

                $scope.$watch('localFile',function(file,oldValue){
                    if(!file) {
                        $scope.fileExist = false;
                        return;
                    }
                    $scope.fileExist = true;
                    $scope.file = file;
                    var mountId = getOptMountId($scope.file);
                    var mount = GKMount.getMountById(mountId);
                    $scope.isYunDun = false;
                    if(mount.property && mount.property.yundun && mount.property.yundun == 1){
                        $scope.isYunDun = true;
                    }
                    if(gkClientInterface.isWebFengCloud() && !$scope.localFile.hash){
                        $scope.showSync = true;
                        $scope.showChatBtn = false;
                        $scope.showLinkBtn = false;
                        $scope.showHistory = false;
                        $scope.showMilestone = false;
                    }else {
                        if(gkClientInterface.isWebFengCloud()){
                            $scope.showSync = true;
                        }else {
                            $scope.showSync = ($scope.file.dir == 1 && !GKFile.isSynced($rootScope.PAGE_CONFIG.file, $scope.file) && GKAuth.check(mount, '', 'file_sync')) ? true : false;
                        }
                        $scope.showChatBtn = GKAuth.check(mount, '', 'file_discuss');
                        $scope.showLinkBtn = mount.ent_id == 0 || GKAuth.check(mount, '', 'file_link');
                        $scope.showHistory = GKAuth.check(mount, '', 'file_history');
                        $scope.showMilestone = GKAuth.check(mount, '', 'file_history_unlimit');
                    }
                    if(lastGetRequest){
                        lastGetRequest.abort();
                        lastGetRequest = null;
                    }

                    getFileInfo($scope.localFile,{first:true});
                });

                /**
                 * 检测是否已加标
                 * @param favorite
                 * @param filter
                 * @returns {boolean}
                 */
                $scope.isSmartAdd = function (favorite, filter) {
                    if (!favorite) favorite = [];
                    var type = GKFilter.getFilterType(filter);
                    if (favorite.indexOf(String(type)) >= 0) {
                        return true;
                    }
                    return false;
                };

                /**
                 * 星标
                 * @param star
                 */
                $scope.toggleSmart = function (filter, favorite) {
                    var fullpath = $scope.file.fullpath;
                    var mountId = $scope.file.mount_id || $scope.PAGE_CONFIG.currentMount.mount_id;
                    if (!fullpath) return;
                    var filterType = String(GKFilter.getFilterType(filter));
                    if (!favorite) favorite = [];
                    var star = favorite.indexOf(filterType) >= 0;
                    if (star) {
                        GKApi.removeFromFav(mountId, fullpath, filterType).success(function () {
                            $scope.$apply(function () {
                                if (GKPartition.isSmartFolderPartition($scope.PAGE_CONFIG.partition) && $scope.filter == filter) {
                                    $scope.$emit('unFav');
                                } else {
                                    Util.Array.removeByValue(favorite, filterType);
                                }
                            })
                        }).error(function (request) {
                            GKException.handleAjaxException(request);
                        });
                    } else {
                        GKApi.addToFav(mountId, fullpath, filterType).success(function () {
                            $scope.$apply(function () {
                                favorite.push(filterType);
                            })
                        }).error(function (request) {
                            GKException.handleAjaxException(request);
                        });
                    }
                };

                /**
                 * 打开生成临时链接的窗口
                 * @param file
                 */
                $scope.publishFile = function(file){
                    if(!$scope.showLinkBtn) return;
                    if(file.status==1){
                        alert(GKI18n.getText(gettext('上传中的文件不能获取分享链接')));
                        return;
                    }
                    GKModal.publish(getOptMountId(file),file);
                };

                //拷贝到邮箱
                $scope.copyToEmail = function(file){
                    if(!$scope.showLinkBtn) return;
                    if(gkClientInterface.isWebFengCloud()){
                        GKModal.openDownload();
                        return;
                    }
                    if(file.status==1){
                        alert(GKI18n.getText(gettext('上传中的文件不能成为云附件')));
                        return;
                    }
                    GKCilpboard.copyModule($rootScope.PAGE_CONFIG.user,file,null,function(){
                        alert(GKI18n.getText(gettext("已将该文件信息保存到剪切板，你可以直接复制到邮件中")));
                    })
                }

                $scope.showMilestoneDialog = function(file){
                    if(!$scope.showChatBtn) return;
                    if(file.status==1){
                        alert(GKI18n.getText(gettext('上传中的文件不能进行讨论')));
                        return;
                    }
                    $scope.$emit("showDiscussHistory",file);
                    return;
                }

                /*打开文件更新消息窗口*/
                $scope.openFileHistoryDialot = function(file){
                    if(!$scope.showHistory) return;
                    var mountId = getOptMountId(file);
                    //var mount = GKMount.getMountById(mountId);
                    var fullpath = file.dir == 1 ? file.fullpath + '/' : file.fullpath;
                    var extParam = {
                        type:'ext'
                    };
                    if(!file || (file.moun_id && !file.fullpath)){
                        return;
                    }
                    var param = {
                        mountId:mountId,
                        fullpath:fullpath,
                        hash:file.hash,
                        extParam:extParam
                    }
                    GKModal.fileHistoryDetail(param);
                };

                $scope.openSyncDialog = function(file){
                   if(!$scope.showSync) return;
                   if(gkClientInterface.isWebFengCloud()){
                       GKModal.openDownload();
                       return;
                   }
                   var currentMountId = $rootScope.PAGE_CONFIG.currentMount.mount_id;
                    //获取当前所在的库
                    if(!GKAuth.check(GKMount.getMountById(currentMountId),'','file_sync')){
                        alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                        return;
                    }
                    GKModal.sync($rootScope.PAGE_CONFIG.fullMountId, file.fullpath);
                };
            }
        }
    }])
    .directive('multifileRightSidebar', [function () {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/multifile_right_sidebar.html"
        }
    }])
    .directive('submountRightSidebar', ['GKI18n','gettext','GKMount','GKAuth','GKModal','GKFile',function (GKI18n,gettext,GKMount,GKAuth,GKModal,GKFile) {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/submount_right_sidebar.html",
            link:function($scope,$element,$attr){
                $scope.$watch('localFile', function (file, oldValue) {
                    if(!$scope.localFile.submountid || $scope.localFile.submountid == '0') return;
                    $scope.showSync = true;
                    var mountId = $scope.localFile.submountid;
                    $scope.selectMount = GKMount.getMountById(mountId);
                    var title = $scope.selectMount  ? $scope.selectMount .name : '';
                    var sideBarData = {
                        title:title,
                        photo: "",
                        attrHtml: '',
                        menus: []
                    };
                    if(GKFile.isSynced($scope.localFile, $scope.localFile)){
                        $scope.showSync = false;
                    }
                    sideBarData.photo = $scope.selectMount.logo;
                    sideBarData.tip = $scope.selectMount.org_description || '';
                    sideBarData.menus = [{icon:'icon_sync',text:GKI18n.getText(gettext('同步')),click:function(){
                        if(gkClientInterface.isWebFengCloud()){
                            GKModal.openDownload();
                            return;
                        }
                        //获取当前所在的库
                        if(!GKAuth.check($scope.selectMount,'','file_sync')){
                            alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                            return;
                        }
                        GKModal.sync(mountId,'');
                    }}];
                    $scope.rootSidebarData = sideBarData;
                })
            }
        }
    }])
    .directive('fileItemOpt', ['GKI18n','gettext','$rootScope','GKFileList','GKMount','$filter','GKApi','GKAuth','GKModal','GKCilpboard',function (GKI18n,gettext,$rootScope,GKFileList,GKMount,$filter,GKApi,GKAuth,GKModal,GKCilpboard) {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/fileitemopt_directives.html",
            link:function($scope,$element,$attr){
                var file = JSON.parse($attr.currentFile)
                var mountId = GKFileList.getOptFileMountId(file);
                var currentMount = GKMount.getMountById(mountId);
                $scope.linkBtnActive = (currentMount.ent_id ==0 || GKAuth.check(currentMount,'','file_link'))?true:false;
                $scope.discussBtnActive = GKAuth.check(currentMount,'','file_discuss');
                $scope.showMilestoneDialog = function($event,file){
                    if(file.status==1){
                        alert( GKI18n.getText(gettext('上传中的文件不能进行讨论')));
                        return;
                    }
                    $scope.$emit("showDiscussHistory",file);
                    $event.stopPropagation();
                }

                //发布外链
                $scope.publishFile = function($event,file){
                    if(file.status==1){
                        alert( GKI18n.getText(gettext('上传中的文件不能获取分享链接')));
                        return;
                    }
                    GKModal.publish(GKFileList.getOptFileMountId(file),file);
                    $event.stopPropagation();
                };
                //拷贝到邮箱
                $scope.copyToEmail = function($event,file){
                    if(file.status==1){
                        alert( GKI18n.getText(gettext('上传中的文件不能成为云附件')));
                        return;
                    }
                    GKCilpboard.copyModule($rootScope.PAGE_CONFIG.user,file,null,function(){
                        alert( GKI18n.getText(gettext("已将该文件信息保存到剪切板，你可以直接复制到邮件中")));
                    })
                    $event.stopPropagation();
                }
            }
        }
    }])
    .directive('toolbar', ['GKI18n','gettext','GKFilter', 'GKPartition', 'GKSmartFolder', 'GKMount', '$location', '$compile', '$timeout','$rootScope', function (GKI18n,gettext,GKFilter, GKPartition, GKSmartFolder, GKMount, $location, $compile, $timeout,$rootScope) {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/toolbar.html",
            link: function ($scope, $element) {
                $scope.$on('$locationChangeSuccess', function () {
                    var param = $location.search(), listName = '';
                    $scope.isSearch = false;
                    if (param.search) {
                        $scope.isSearch = true;
                        var searchArr = param.search.split('|');
                        $scope.searchScope = searchArr[1];
                        listName = GKI18n.getText(gettext('搜索结果'));
                        var searchName = '';
                        if (param.filter) {
                            searchName = GKSmartFolder.getSmartFoldeName(param.filter);
                        } else {
                            if(param.path){
                                searchName = Util.String.baseName(param.path);
                            }else{
                                searchName =  $rootScope.PAGE_CONFIG.mount['name'];
                            }
                        }

                        $scope.searchName = searchName;

                    } else {
                        $scope.isSearch = false;
                        if (GKPartition.isSmartFolderPartition(param.partition) && param.filter) {
                            listName = GKSmartFolder.getSmartFoldeName(param.filter);
                        } else {
                            var mount = GKMount.getMountById(param.mountid);
                            if (mount) {
                                listName = mount['name'];
                            }
                        }
                    }
                    $scope.listName = listName;
                })

                $scope.reSetSearch = function(scope){
                    var param = $location.search();
                    var searchArr = param.search.split('|');
                    if(scope == 'current'){
                        if(GKPartition.isMountPartition(param.partition)){
                            if(!param.path){
                                scope = 'mount';
                            }else{
                                scope = 'path';
                            }
                        }else{
                            scope = 'filter';
                        }

                    }
                    searchArr[1] = scope;
                    $scope.searchScope = scope;
                    var extendParam = {
                        search:searchArr.join('|')
                    };
                    var search = $location.search();
                    $location.search(angular.extend(search, extendParam));
                }

                $scope.$on('editSmartFolder', function ($event, name, code, filter) {
                    if ($scope.listName && $scope.filter == filter) {
                        $scope.listName = name;
                    }
                })

                $scope.$on('editOrgObjectSuccess', function (event, mount) {
                    if (!mount) {
                        return;
                    }
                    if ($scope.listName && $rootScope.PAGE_CONFIG.mount && $rootScope.PAGE_CONFIG.mount.mount_id == mount.mount_id) {
                        $scope.listName = mount.name;
                    }
                })
                var moreBtn;
                var toolOpt = $element.find('.opt_tool');
                var setUI = function () {
                    var grid = $element.width() - toolOpt.outerWidth(true) - $element.find('.opt_view_change').outerWidth(true);
                    var count = 0;
                    while (grid < 0) {
                        if (count > 50) break;
                        if (!moreBtn) {
                            var moreBtnHtml = '<span class="f_l dropdown">';
                            moreBtnHtml += '<a dropdown-toggle class="btn btn-opt opt" href="javascript:void(0);" ng-class="">';
                            moreBtnHtml += '<span translate>更多</span>';
                            moreBtnHtml += '<i class="gk_down_arrow"></i>';
                            moreBtnHtml += '</a>';
                            moreBtnHtml += '<ul class="dropdown-menu">';
                            moreBtnHtml += '</ul>';
                            moreBtnHtml += '</span>';
                            moreBtn = $compile(angular.element(moreBtnHtml))($scope);
                        }
                        var lastBtn = toolOpt.find('span.opt_btn:visible:last');
                        var lastBtnClone = jQuery('<li/>').append(lastBtn.find('> a').clone(true).removeClass('btn btn-opt'));
                        lastBtn.hide();
                        moreBtn.appendTo(toolOpt).find('.dropdown-menu').prepend(lastBtnClone);
                        grid = $element.width() - toolOpt.outerWidth() - $element.find('.opt_view_change').outerWidth(true);
                        count++;
                    }
                };

                var oldWidth = $element.width();
                $scope.$on('resetToolOpts',function(){
                    $timeout(function() {
                        var newWidth = $element.width();
                        if (newWidth <= 0) {
                            return;
                        }
                        var grid = newWidth - oldWidth;
                        var currentOldWidth = oldWidth;
                        if(grid<=0){
                            setUI();
                        }else {
                            while (grid > 0) {
                                var lastHideBtn = toolOpt.find('span.opt_btn:hidden:first');
                                var lastHideBtnWidth = lastHideBtn.outerWidth(true);
                                if (lastHideBtn.size() && grid > lastHideBtnWidth) {
                                    lastHideBtn.show();
                                    if (moreBtn) {
                                        moreBtn.find('.dropdown-menu li:first').remove();
                                        if (moreBtn.find('.dropdown-menu li').size() == 0) {
                                            moreBtn.remove();
                                            moreBtn = null;
                                        }
                                    }
                                    currentOldWidth += lastHideBtnWidth;
                                    grid = newWidth - currentOldWidth;
                                } else {
                                    break;
                                }
                            }
                        }
                    },400);

                })
                jQuery(window).on('resize.tool', function () {
                    var newWidth = $element.width();
                    if(newWidth<=0){
                        return;
                    }
                    var grid = newWidth - oldWidth;
                    if (grid > 0) {
                        var lastHideBtn = toolOpt.find('span.opt_btn:hidden:first');
                        if (lastHideBtn.size() && grid > lastHideBtn.outerWidth(true)) {
                            lastHideBtn.show();
                            if (moreBtn) {
                                moreBtn.find('.dropdown-menu li:first').remove();
                                if (moreBtn.find('.dropdown-menu li').size() == 0) {
                                    moreBtn.remove();
                                    moreBtn = null;
                                }
                            }
                        }
                    } else{
                        $timeout(function(){
                            setUI();
                        })
                    }
                    //TODO:resize完应该重新赋值oldWidth，但无法知道resize end事件
                    //oldWidth = $element.width();
                })

                $scope.$watch('opts', function (val) {
                    if (moreBtn) {
                        moreBtn.remove();
                        moreBtn = null;
                        var hideBtns = toolOpt.find('span.opt_btn:hidden')
                        hideBtns.css("display","");
                    }
                    $timeout(function () {
                        setUI();
                    })
                })

                $scope.$on('$destroy', function () {
                    jQuery(window).off('resize.tool');
                    if (moreBtn && moreBtn.size()) {
                        moreBtn.remove();
                        moreBtn = null;
                        toolOpt = null;
                    }
                })
            }
        }
    }])
    .directive('rightTagInput', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            require: '?ngModel',
            link: function ($scope, $element, $attrs, $ngModel) {
                if (!$ngModel) {
                    return;
                }
                jQuery($element).tagsInput({
                    'height': 'auto',
                    'width': '225px',
                    'interactive': true,
                    'onAddTag': function (tag) {
                        $scope.addTag(tag);
                    },
                    'onRemoveTag': function (tag) {
                        $scope.removeTag(tag);
                    },
                    'onChange': function (input, d, c) {

                    }
                })
            }
        }
    }])
    .directive('breadsearch', ['GKI18n','gettext','$location', '$timeout', 'GKPartition', '$rootScope', 'GKSmartFolder','GKPath','smartSearchConfig', function (GKI18n,gettext,$location, $timeout, GKPartition, $rootScope, GKSmartFolder,GKPath,smartSearchConfig) {
        return {
            replace: true,
            restrict: 'E',
            templateUrl: "views/bread_and_search.html",
            link: function ($scope, $element) {
                var bread = $element.find('.bread');
                var searchIcon = $element.find('.icon-search');
                var eleWidth = $element.width();
                var hideBread = $element.find('.hide_bread');
                $scope.currentSearchScope = null;
                /**
                 * 显示搜索模式
                 * @param $event
                 */
                $scope.showSearch = function ($event) {
                    if($scope.disableSearch) return;
                    if (jQuery($event.target).hasClass('bread_list')
                        || jQuery($event.target).parents('.bread_list').size()
                        || jQuery($event.target).hasClass('searching_label')
                        || jQuery($event.target).parents('.searching_label').size()
                        || jQuery($event.target).hasClass('hide_bread')
                        || jQuery($event.target).parents('.hide_bread').size()
                        || $scope.searchState == 'end'
                        ) {
                        return;
                    }
                    $scope.searchState = 'start';
                    $element.find('input[name="keyword"]').focus();
                };

                $scope.hideBreads = [];

                var setBreadUI = function () {
                    var breadWidth = $element.find('.bread').width();
                    $element.find('.bread_list .bread_item a').css({'max-width': breadWidth});
                    var breadListWidth = $element.find('.bread_list').width();
                    var count = 0;
                    while (breadListWidth > breadWidth && breadListWidth > 0 && breadWidth > 0) {
                        if (count > 50) break;
                        count++;
                        if ($element.find('.bread_list .bread_item:visible').size() == 1) {
                            break;
                        }
                        if ($scope.breads && $scope.breads.length) {
                            var hideBread = $scope.breads[$scope.hideBreads.length];
                            if (hideBread) {
                                $scope.hideBreads.unshift($scope.breads[$scope.hideBreads.length]);
                                $element.find('.bread_list .bread_item:visible').eq(0).hide();
                                breadListWidth = $element.find('.bread_list').width();
                            }
                        }
                    }
                };

                $scope.$watch('breads', function (val) {
                    $scope.hideBreads = [];
                    $element.find('.bread_list .bread_item:hidden').show();
                    $timeout(function () {
                        setBreadUI();
                        return null;
                    }, 0);
                })

                var oldBreadWidth = $element.find('.bread').width();

                jQuery(window).on('resize', function () {
                    $scope.$apply(function () {
                        var newBreadWidth = $element.find('.bread').width();
                        if(newBreadWidth<=0){
                            return;
                        }
                        var grid = newBreadWidth - oldBreadWidth;
                        if (grid > 0) {
                            var lastHideBread = $element.find('.bread_list .bread_item:hidden').last();
                            if (lastHideBread.size()) {
                                if (grid >= lastHideBread.outerWidth()) {
                                    $scope.hideBreads.splice(0, 1);
                                    lastHideBread.show();
                                }
                            }
                        } else if(grid<0) {
                            $timeout(function () {
                                setBreadUI();
                                return null;
                            }, 0)
                        }
                    })
                })


                /**
                 * 点击面包屑后的跳转
                 * @param bread
                 * @param $event
                 */
                $scope.selectBread = function ($event, bread){
                    if(bread.fullMountId == $scope.mountId && bread.path == $scope.path){
                        return;
                    }
                    if($scope.fileUpdate.isFileUpdateView && bread.path) {
                        return false;
                        //$scope.$broadcast('changeView', $scope.oldView);
                    }
                    if($scope.fileUpdate.isFileUpdateView) {
                        $scope.fileUpdate.isFileUpdateView = false;
                        $scope.view = $scope.oldView;
                    }
                    var params = $location.search();
                    GKPath.gotoFile(bread.fullMountId,bread.path || '', '',$scope.view, bread.filter,'file');
                    $event.stopPropagation();
                };

                $scope.$on('searchStateChange',function(event,state){
                    $scope.searchState = state;
                })

                $scope.searchFile = function () {
                    if (!$scope.keyword || !$scope.keyword.length || $scope.searchState == 'loading') {
                        return;
                    }
                    if($scope.keyword.indexOf('|')>=0){
                        alert( GKI18n.getText(gettext("搜索关键字中不能包含字符'|'")));
                        return;
                    }
                    if(!$scope.currentSearchScope){
                        return;
                    }
                    var extendParam = {
                          search:[$scope.keyword,$scope.currentSearchScope.name,$scope.currentSearchScope.mountId].join('|')
                    };
                    var search = $location.search();
                    $location.search(angular.extend(search, extendParam));
                };

                var resetSearch = function () {
                    $scope.keyword = $scope.searchState = '';
//                    $scope.currentSearchScope = null;
                };

                $scope.cancelSearch = function ($event) {
                    if($scope.fileUpdate.isFileUpdateView)
                        $scope.$broadcast('changeView',$scope.oldView);
                    var search = $location.search();
                    $location.search(angular.extend(search, {
                        search: ''
                    }));
                    $event.stopPropagation();
                };

//                $('body').on('mousedown.resetsearch', function (event) {
//                    $scope.$apply(function () {
//                        if (
//                            $(event.target).hasClass('bread_and_search_wrapper')
//                                || $(event.target).parents('.bread_and_search_wrapper').size()
//                                || $scope.searchState == 'loading'
//                                || $scope.searchState == 'end'
//                            ) {
//                            return;
//                        }
//                        resetSearch();
//                    })
//                })


                var getSearchScopes = function () {
                    var searchScopes = [];
                    var params = $location.search();
                    if (params.filter) {
                        searchScopes.push({
                            name: 'filter',
                            text: GKSmartFolder.getSmartFoldeName(params.filter)
                        })
                    } else {
//                        if(GKPartition.isTeamFilePartition(params.partition) || GKPartition.isEntFilePartition(params.partition)){
//                            searchScopes.push({
//                                name: 'partition',
//                                text: '所有云库'
//                            });
//                        }
                        searchScopes.push({
                            name: 'mount',
                            mountId:$rootScope.PAGE_CONFIG.mount.mount_id,
                            text: $rootScope.PAGE_CONFIG.mount['name']
                        });
                        if (params.path) {
                            searchScopes.push({
                                name: 'path',
                                mountId:$rootScope.PAGE_CONFIG.currentMount.mount_id,
                                text: Util.String.baseName(params.path)
                            })
                        }else{
                            if($rootScope.PAGE_CONFIG.mount.mount_id != $rootScope.PAGE_CONFIG.currentMount.mount_id){
                                searchScopes.push({
                                    name: 'mount',
                                    mountId:$rootScope.PAGE_CONFIG.currentMount.mount_id,
                                    text: $rootScope.PAGE_CONFIG.currentMount['name']
                                });
                            }
                        }
                    }
                    return searchScopes;
                };

                var getCurrentSearchScope = function(scope,searchScopes){
                    var currentScope;
                    if(scope == smartSearchConfig.name){
                        currentScope = smartSearchConfig;
                        return currentScope;
                    }
                    angular.forEach(searchScopes,function(val){
                        if(val.name == scope){
                            currentScope = val;
                            return false;
                        }
                    });
                    return currentScope;
                }

                var getSearchParam = function(){
                    var params = $location.search();
                    $scope.searchScopes =  getSearchScopes();
                    if(!params.search){
                        resetSearch();
                        var len = $scope.searchScopes.length;
                        if(len){
                            $scope.currentSearchScope = $scope.searchScopes[len-1];
                        }
                    }else{
                        var searchArr = params.search.split('|');
                        if($scope.keyword == searchArr[0] && ($scope.currentSearchScope && $scope.currentSearchScope.name == searchArr[1])){
                            return;
                        }
                        var currentScope = getCurrentSearchScope(searchArr[1],$scope.searchScopes);
                        if(!currentScope) return;
                        $scope.keyword = searchArr[0];
                        $scope.currentSearchScope = currentScope;
                        $scope.searchState = 'start';
                    }
                };

                $scope.$on('$locationChangeSuccess', function ($e, $new, $old) {
                    getSearchParam();
                });

                getSearchParam();

                $scope.setSearchScope = function (searchScope) {
                    $scope.currentSearchScope = searchScope;
                }

                $scope.$on('$destroy', function () {
                    $('body').off('mousedown.resetsearch');
                    jQuery(window).off('resize');
                })
            }
        }
    }])
    .directive('inputDatepicker', [function () {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                isOpen: "@",
                ngModel: '='
            },
            template: '<div class="form-control input-datepicker">'
                + '<input type="text" datepicker-popup="yyyy年M月d日" show-weeks="false" ng-model="ngModel" is-open="false" current-text="今天" toggle-weeks-text="周" clear-text="清空" close-text="关闭"/>'
                //+'<i class="calendar" ng-class="isOpen=true"></i>'
                + '</div>',
            link: function ($scope, $element, $attrs) {
                $scope.isOpen = false;
            }
        }
    }])
    .directive('resize', ['$document', '$window', function ($document, $window) {
        return {
            restrict: 'E',
            replace: true,
            template: '<div class="resize" ng-style="style" ng-class="moving?\'moving\':\'\'"></div>',
            link: function ($scope, $element, $attrs) {
                $scope.moving = false;

                $element.off('mousedown').on('mousedown', function (e) {
                    $scope.$apply(function () {
                        $scope.moving = true;
                        $document.find('body').addClass('resizing');
                        $document.bind('mousemove.resize', function (e) {
                            $scope.$apply(function () {
                                if (e.pageX < 80) {
                                    return false;
                                }
                                if ($scope.moving) {
                                    $scope.style = {
                                        left: e.pageX - 1
                                    }
                                }

                            })

                        })
                    });
                })

                var setPosition = function (width) {
                    if (width < 160) {
                        width = 160;
                    }
                    if ($document.width() - width < 650) {
                        width = $document.width() - 650;
                    }
                    $document.find('.left_sidebar').css('width', width);
                    $document.find('.main').css('left', width);
                    $scope.style = {
                        left: width - 1
                    }
                };

                $document.bind('mouseup', function (e) {
                    $scope.$apply(function () {
                        if ($scope.moving) {
                            setPosition(e.pageX);
                        }
                        $document.find('body').removeClass('resizing');
                        $scope.moving = false;
                        $document.unbind('mouseup.resize');
                    });
                })

                jQuery(window).off('resize.resizeLeft').on('resize.resizeLeft', function () {
                    var max = jQuery(window).width() - 650;
                    if (max < 0) {
                        return;
                    }
                    if ($document.find('.left_sidebar').width() > max) {
                        $scope.style = {
                            left: max - 1
                        }
                        setPosition(max);
                    }
                })

                $scope.$on('$destory', function () {
                    jQuery(window).off('.resizeLeft');
                })
            }
        }
    }])
    .directive('commonRightSidebar', [function () {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: "views/common_right_sidebar.html"
        }
    }])
    .directive('filterRightSidebar', [function () {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: "views/filter_right_sidebar.html"
        }
    }])
    .directive('discussHistory',['GKI18n','gettext','AppIndex','$timeout','$interval','GKFile','GKApi','$rootScope','GKAuth','GKMount',function(GKI18n,gettext,AppIndex,$timeout,$interval,GKFile,GKApi,$rootScope,GKAuth,GKMount){
        return{
            restrict: 'E',
            replace: true,
            templateUrl: "views/singlefile-right-discusshistory.html",
            link:function(scope, element, attrs){
                var ELEMENT_RIGHT = -300;
                scope.canShowHistory = false;
                scope.currentDiscussFile = null;
                scope.discussionList = [];
                scope.discussContent = "";
                scope.loadDiscussionhistory = true;
                scope.it_isOpen = false;
                scope.showDisscussHitoryWin = false;
                scope.selectObj = {
                    partition:'',
                    mountid:'',
                    path:''
                };
                scope.$on('$locationChangeStart',function() {
                   close();
                });
                scope.$watch('loadDiscussionhistory',function(val){
                    scope.$broadcast('disabledText',!val);
                })
                scope.$watch(function(){
                    return $rootScope.PAGE_CONFIG.mode;
                },function(value,oldValue){
                    if(value == 'chat'){
                        //保存切换前的状态
                       // var opened = scope.showDisscussHitoryWin;
                        close();
                        //重新复制
                        //scope.showDisscussHitoryWin = opened;
                    }
                })
                scope.$on("updateDiscussMsg",function(obj,discussHistoryArr){
                    if(!scope.currentDiscussFile){
                        return;
                    }
                    angular.forEach(discussHistoryArr,function(item){
                        if(item.sender != $rootScope.PAGE_CONFIG.user.member_name){
                            if(item.receiver && item.receiver == $rootScope.PAGE_CONFIG.mount.org_id){
                                var fileInfo = JSON.parse(item.metadata);
                                if(scope.currentDiscussFile.hash == fileInfo.hash){
                                    item.status = true;
                                    scope.discussionList.push(item);
                                    if(scope.currentDiscussFile.discuss_count == '99' || scope.currentDiscussFile.discuss_count == '99+'){
                                        scope.currentDiscussFile.discuss_count = '99+';
                                    }else {
                                        scope.currentDiscussFile.discuss_count = (Number(scope.currentDiscussFile.discuss_count) + 1)+'';
                                    }
                                    scope.scrollToIndex = scope.discussionList.length -1;
                                }
                            }
                        }
                    });
                });
                scope.$on("closeDiscussHistory",function(){
                   close();
                });
                scope.$on("showDiscussHistory",function(obj,file){
                    if(file && !file.mount_id){
                        file.mount_id = $rootScope.PAGE_CONFIG.currentMount.mount_id;
                    }
                    var mount = GKMount.getMountById(file.mount_id);
                    if(!GKAuth.check(mount, '', 'file_discuss')){
                        alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                        return false;
                    }
                    scope.showDisscussHitoryWin = true;
                    scope.loadDiscussionhistory = true;
                    scope.$broadcast("clearInput");
                    scope.discussionList = [];
                    scope.currentDiscussFile = file;
                    scope.canShowHistory = true;
                    element.show();
                    element.animate({right:0},300,function(){
                        scope.focusTextarea = true;
                    });

                    GKFile.getDiscussHistory(file).then(function(data){
                        $rootScope.$broadcast('updateDiscussHistoryTime',data);
                        for(var i=data.list.length-1;i>=0;i--){
                            var value = data.list[i];
                            value.status = true
                            scope.discussionList.push(value);
                        }
                        scope.scrollToIndex = scope.discussionList.length -1;
                        scope.loadDiscussionhistory = false;
                    },function(data){
                        scope.loadDiscussionhistory = false;
                    });
                });



                scope.atMember = function(at){
                    scope.$broadcast("atMember",at);
                };

                scope.$on('showToolIndex',function(obj,showIndex){
                    if(scope.showToolsBtnIndex && scope.showToolsBtnIndex.length > 0){
                        scope.showToolsBtnIndex += ',' + showIndex;
                    }else{
                        scope.showToolsBtnIndex = showIndex;
                    }
                })

                scope.$on("sendDiscussion",function($event,type,message){
                    if(!scope.currentDiscussFile) return;
                    if (!message) {
                        return;
                    }
                    scope.discussContent = "";
                    postMsg("text",message);
                    scope.focusTextarea = true;
                })

                var postMsg = function(type,message){
                    var newDisscussMsg = {
                        content:message,
                        receiver:$rootScope.PAGE_CONFIG.mount.org_id,
                        sender:$rootScope.PAGE_CONFIG.user.member_name,
                        medadata:[],
                        time:new Date().getTime(),
                        status:true,
                        type:type
                    }
                    scope.discussionList.push(newDisscussMsg)
                    if(scope.currentDiscussFile.discuss_count == '99' || scope.currentDiscussFile.discuss_count == '99+'){
                        scope.currentDiscussFile.discuss_count = '99+';
                    }else {
                        scope.currentDiscussFile.discuss_count = (Number(scope.currentDiscussFile.discuss_count) + 1)+'';
                    }
                    scope.scrollToIndex = scope.discussionList.length -1;
                    GKApi.markMilestone($rootScope.PAGE_CONFIG.mount.mount_id,scope.currentDiscussFile.mount_id,scope.currentDiscussFile.fullpath,message,1)
                        .success(function(data){
                            newDisscussMsg.status=true;
                        })
                        .error(function(reqest){
                            newDisscussMsg.status=false;
                        })
                };

                var close = function(){
                    scope.showDisscussHitoryWin = false;
                    scope.loadDiscussionhistory = true;
                    element.animate({right:ELEMENT_RIGHT},200,function(){
                        scope.canShowHistory = false;
                        scope.discussionList = [];
                        element.hide();
                    });
                };

                scope.cancel = function(){
                    close();
                };
                $timeout(function(){
                    element.css("right",ELEMENT_RIGHT+"px");
                    element.hide();
                });
            }
        }
    }])
    .directive('rightScrollbar',['$timeout',function($timeout){
        return {
            restrict: 'A',
            link: function ($scope, $element,$attr) {
                var setScroll = function(){
                    var _containerHeight = $element.height();
                    var _firstChildHeight = $($element.find(">div")[0]).height();
                    $($element.find(">div")[1]).height(_containerHeight - _firstChildHeight);
                    var _h = _containerHeight - _firstChildHeight - 70 - 12;
                    $($element.find(">div")[1]).find(">div.tab_content").height(_h).css("overflow",'auto');
                    var _num = Math.ceil(_h/32);
                    $scope.$emit("changeMemberLen",_num + 1);
                }
                $timeout(function(){
                    setScroll();
                });
                $(window).resize(function(){
                    setScroll();
                });
                $scope.$watch('currTab',function(newVal,oldVal){
                    if(newVal && newVal == 'detail'){
                        setScroll();
                    }
                });
            }
        }
    }]);
