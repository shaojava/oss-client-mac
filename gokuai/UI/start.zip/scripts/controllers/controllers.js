'use strict';

/* Controllers */

angular.module('gkClientIndex.controllers', ['angularBootstrapNavTree'])
    .run(['$rootScope', '$window', 'GKWindowCom', function ($rootScope, $window, GKWindowCom) {
        GKWindowCom.message(function (event) {
            var data = event.data;
            if (!data) {
                return;
            }
            if (data.type == 'gotoFile') {
                gkClientInterface.setWindowTop();
                $rootScope.$broadcast('OpenMountPath', data);
            }
        })
    }])
    .controller('headerCtrl',['$scope',function($scope){
        //判断是否是新东方客户端
        $scope.appTitle = gkClientInterface.isXDFClient() ?'新东方云盘':'够快云库';
    }])
    .controller('initClient', ['ipCookie', 'GKI18n', 'gettext', 'GKBrowserMode', 'localStorageService', '$rootScope', 'GKNews', '$scope', 'GKMount', '$location', 'GKFile', 'GKFileList', 'GKPartition', 'GKModal', 'GKApi' , 'GKDialog', '$timeout', 'GKFrame', 'GKAuth', 'GKPath', '$window', 'GKMode', '$interval', 'chatConnect', function (ipCookie, GKI18n, gettext, GKBrowserMode, localStorageService, $rootScope, GKNews, $scope, GKMount, $location, GKFile, GKFileList, GKPartition, GKModal, GKApi, GKDialog, $timeout, GKFrame, GKAuth, GKPath, $window, GKMode, $interval, chatConnect) {
        //如果是web端，则打开一个长链接
        var maxMsgTime = 0;
        var openConnect = false;
        var connectMessage = function () {
            chatConnect.connect(maxMsgTime).then(function (data) {
                if (!data.error && data.time > 1) {
                    var iframe = GKFrame('ifame_chat');
                    if (iframe && typeof iframe.gkFrameCallback !== 'undefined') {
                        iframe.gkFrameCallback('connectMsgList', data);
                    }
                } else {
                    connectMessage();
                }
            });
        }
        if (gkClientInterface.isWebFengCloud()) {
            $scope.$on('updateMaxMsgTime', function (obj, param) {
                maxMsgTime = param.maxMsgTime;
                if (!openConnect) {
                    openConnect = true;
                    connectMessage();
                }
            });
            $scope.$on('openConnectMessage', function (obj, param) {
                maxMsgTime = param.maxMsgTime;
                connectMessage();
            });
            var key = 'no_launch_' + WEB_CONSTANT.user.member_id;
            if (!ipCookie(key)) {
                //显示下载客户端的modal
                GKModal.welcomeDownload();
            }
        }
        //判断是否是新东方客户端
        $rootScope.isXDFClient = gkClientInterface.isXDFClient();
        $rootScope.PAGE_CONFIG = {
            siteDomain: gkClientInterface.getSiteDomain(),
            user: gkClientInterface.getUser(),
            file: {},
            mount: {},
            path: '',
            fullMountId: '', //在库中访问了子库后的全库ID路径
            currentMount: {},//当前所在的库
            filter: '',
            mode: '',
            progress: false,
            browserMode: GKBrowserMode.getMode(),
            partition: '',
            networkConnected: Number(gkClientInterface.getNetworkStatus()),
            yunDunStatus:0,
            isYunDunMount:0,
            visitHistory: {
                //记录访问历史，实现回退前进功能
                historyArr: [],
                selectedHistory: {},
                //清空历史游标
                clearHistoryFlag: function () {
                    if (this.selectedHistory.index < this.historyArr.length - 1) {
                        for (var i = this.selectedHistory.index + 1; i < this.historyArr.length; i++) {
                            this.historyArr.splice(i, 1);
                            i = i - 1;
                        }
			
			
                    }
                    this.selectedHistory.selected = false;

                },
                renameFolderUpdateHistory: function (file, oldFilePath, newFilePath) {
                    var mountId = GKFileList.getOptFileMountId(file);
                    for (var i = 0; i < this.historyArr.length; i++) {
                        var value = this.historyArr[i];
                        if (value.mountid == mountId && value.path.indexOf(oldFilePath) != -1) {
                            var otherPath = value.path.substring(oldFilePath.length);
                            value.path = newFilePath + otherPath;
                        }
                    }
                },
                removeHistory: function (fullpath, mountId) {
                    var indexArr = [];
                    var selectHistory = {};
                    var isEquils = false;
                    selectHistory = angular.extend(selectHistory, this.selectedHistory)
                    if (fullpath.length > 0) {
                        for (var i = 0; i < this.historyArr.length; i++) {
                            var value = this.historyArr[i];
                            if (value && value.mountid == mountId && value.path.indexOf(fullpath) != -1) {
                                indexArr.push(value.index);
                                if (value.selected) {
                                    if (this.historyArr[value.index - 1])
                                        this.historyArr[value.index - 1].selected = true;
                                    else if (this.historyArr[value.index + 1])
                                        this.historyArr[value.index + 1].selected = true;
                                }
                            }
                        }
                    } else if (fullpath.length == 0) {
                        for (var i = 0; i < this.historyArr.length; i++) {
                            var value = this.historyArr[i];
                            var currentMountId = "";
                            if (value.mountid) {
                                currentMountId = value.mountid + "";
                            }
                            if (value && currentMountId.indexOf(mountId) >= 0) {
                                indexArr.push(value.index);
                                if (value.selected) {
                                    if (this.historyArr[value.index - 1]) {
                                        this.historyArr[value.index - 1].selected = true;
                                    }
                                    else if (this.historyArr[value.index + 1]) {
                                        this.historyArr[value.index + 1].selected = true;
                                    }
                                }
                            }
                        }
                    }
                    if (!indexArr || indexArr.length == 0) return;
                    for (var i = indexArr.length - 1; i >= 0; i--) {
                        this.historyArr.splice(indexArr[i], 1);
                    }
                    if (Util.object.checkObjEquils(selectHistory, this.selectedHistory)) {
                        isEquils = true;
                    }

                    for (var i = 0; i < this.historyArr.length; i++) {
                        this.historyArr[i].index = i;
                        if (this.historyArr[i].selected) this.selectedHistory = this.historyArr[i];
                    }

                    if (isEquils) {
                        $location.search(this.selectedHistory);
                    }
                },
                hasPrev: function () {
                    if (this.historyArr) {
                        var len = this.historyArr.length;
                        if (len > 1) {
                            var currIndex = this.selectedHistory.index;
                            if (currIndex > 0) return true;
                        }
                    }
                    return false;
                },
                hasNext: function () {
                    if (this.historyArr) {
                        var len = this.historyArr.length;
                        if (len > 1) {
                            var currIndex = this.selectedHistory.index;
                            if (currIndex < len - 1) return true;
                        }
                    }
                    return false;
                },
                clickPrev: function () {
                    if (this.hasPrev()) {
                        var index = this.selectedHistory.index;
                        this.historyArr[index].selected = false;
                        this.historyArr[index - 1].selected = true;
                        this.selectedHistory = this.historyArr[index - 1];
                        this.selectedHistory.view = this.selectedHistory.history_view;
                        $location.search(this.selectedHistory);
                    }
                },
                clickNext: function () {
                    if (this.hasNext()) {
                        var index = this.selectedHistory.index;
                        this.historyArr[index].selected = false;
                        this.historyArr[index + 1].selected = true;
                        this.selectedHistory = this.historyArr[index + 1];
                        this.selectedHistory.view = this.selectedHistory.history_view;
                        $location.search(this.selectedHistory);
                    }
                }
            }
        };
        $scope.hideRight = false;
        $scope.hideRightTitleText = GKI18n.getText(gettext('隐藏右侧'))
        $scope.setHideRight = function () {
            $scope.hideRight = !$scope.hideRight;
            if ($scope.hideRight) {
                $scope.hideRightTitleText = GKI18n.getText(gettext('显示右侧'))
            } else {
                $scope.hideRightTitleText = GKI18n.getText(gettext('隐藏右侧'))
            }
            //设置工具条
            $scope.$broadcast('resetToolOpts');
        }
        $scope.showLoading = gkClientInterface.needLoading() == 1 ? true : false;

        $scope.$on('LoadFinish', function (e, data) {
            $scope.$apply(function () {
                window.location.reload();
                //$scope.showLoading = false
            })
        })
        /**
         * 监听打开消息的通知
         */
        $scope.$on('ShowMessage', function (e, data) {
            if (!$rootScope.showNews) {
                GKModal.news(GKNews, GKApi);
            }
        })

        $scope.$on('ShowAction', function (e, data) {
            if (!data) {
                return;
            }
            if (data.type == 'addMember') {
                GKModal.teamMember(data.orgId);
            }
        })

        $scope.$on('OpenChatOrg', function (e, data) {
            if (!data || !data['orgid']) {
                return;
            }
            var mount = GKMount.getMountByOrgId(data['orgid']);
            if (!mount) return;
            $scope.$apply(function () {
                GKPath.gotoFile(mount['mount_id'], '', '', '', '', 'chat');
            })
        })

        $rootScope.$on('createTeamSuccess', function (event, param) {
            var orgId = param.orgId;
            gkClientInterface.notice({type: 'getOrg', 'org_id': Number(orgId)}, function (newOrg) {
                if (newOrg) {
                    $scope.$apply(function () {
                        $rootScope.$broadcast('createOrgSuccess', newOrg);
                        if (param.close == 1) {
                            $rootScope.$broadcast('closeModal');
                        }
                    });
                }
            })
        })

        //更新云库
        $scope.$on('updateTeam', function (event, param) {
            if (!param) {
                return;
            }
            gkClientInterface.notice({type: 'getOrg', 'org_id': Number(param.orgId)}, function (newMount) {
                if (newMount) {
                    $scope.$apply(function () {
                        $rootScope.$broadcast('EditOrgObject', newMount);
                        $rootScope.$broadcast('closeModal', 'changeTeamLogo');
                    });
                }
            })
        })

        $scope.$on('teamSecurity', function ($event, orgId) {
            if (!orgId) {
                return;
            }
            GKModal.teamManage(orgId);
        })

        /*打开文件更新消息窗口*/
        $scope.$on('openSummaryDetail', function (scope, option) {
            GKModal.summaryDetail(option);
        });
        $scope.$on('openUrl', function ($event, param) {
            var sso = Number(param.sso) || 0;
            var url = gkClientInterface.getUrl({
                sso: sso,
                url: param.url
            });
            var type = param.type;
            var title = param.title;
            if (type == 'browser') {
                gkClientInterface.openUrl(url);
            } else if (type == 'dialog') {
                GKDialog.openUrl(url);
            } else if (type == 'modal') {
                GKModal.openNew(url, title);
            }
        })

        $scope.$on('addMember', function ($event, orgId) {
            if (!orgId) {
                return;
            }
            GKModal.teamMember(orgId);

        })

        $scope.$on('viewSubscriber', function ($event, orgId) {
            if (!orgId) {
                return;
            }
            GKModal.teamSubscribe(orgId);

        })

        $scope.$on('qr', function ($event, orgId) {
            if (!orgId) {
                return;
            }
            GKModal.teamQr(orgId);
        })

        $scope.$on('UserInfo', function (event, param) {
            $scope.$apply(function () {
                $rootScope.PAGE_CONFIG.user = param;
            });
        })

        var setPageConfig = function () {
            var param = $location.search();
            var mountId = Util.object.getRootMountId(param.mountid);
            var currentMountId = Util.object.getCurrentMountId(param.mountid);
            if (!param.partition) return;
            var mode = GKMode.getMode();
            var yunDunStatus = gkClientInterface.YUN_DUN.getSheidStatus();
            var extend = {
                filter: param.filter || '',
                partition: param.partition,
                entId: param.entid || 0,
                path: param.path || '',
                yunDunStatus:yunDunStatus ? yunDunStatus.status : 0
            };
            if (GKPartition.isMountPartition(param.partition)) {
                if (!param.filter) {
                    if (currentMountId) {
                        extend.file = GKFile.getFileInfo(currentMountId, param.path);
                        if(gkClientInterface.isWebFengCloud()){
                            jQuery.extend(extend.file,{
                                dir:param.isfile == 1 ? 0 : 1
                            });
                        }
                    }
                    //双击的是子库
                    if (!param.path && mountId != currentMountId) {
                        var currentMount = GKMount.getMountById(currentMountId);
                        extend.file.submountid = currentMount['mount_id'];
                    }
                } else {
                    extend.file = {};
                }
                if (currentMountId == mountId && !param.path) {
                    var mount = GKMount.getMountById(currentMountId);
                    if (mount) {
                        extend.file.filename = mount['name'];
                    }
                }

                extend.mount = GKMount.getMountById(mountId);
                extend.fullMountId = param.mountid;
                extend.isYunDunMount = GKMount.isYundunMount(extend.mount) ? 1 : 0;
                extend.currentMount = GKMount.getMountById(currentMountId);
                var mount = gkClientInterface.getMount({
                    mountid: Number(mountId)
                });



                angular.extend(extend.mount, {
                    trash_size: mount.size_recycle,
                    trash_dateline: mount.dateline_recycle
                })


            } else {
                extend.file = {};
                extend.mount = {};
                extend.currentMount = {};
                extend.fullMountId = '';
            }
            angular.extend($rootScope.PAGE_CONFIG, extend);
            GKMode.setMode(mode);
        }

        /**
         * 监听路径的改变
         */
        $scope.$on('$locationChangeSuccess', function () {
            setPageConfig();
        })

        $scope.$on('UpdateFileList', function () {
            var param = $location.search();
            var oldSyncPath = $rootScope.PAGE_CONFIG.file.syncpath;
            angular.extend($rootScope.PAGE_CONFIG, {
                file: GKFile.getFileInfo(Util.object.getCurrentMountId(param.mountid), param.path)
            });
            if (oldSyncPath && !$rootScope.PAGE_CONFIG.file.syncpath) {
                $scope.$broadcast('editFileSuccess', 'unsync', param.mountid, param.path);
            }
        })

        $scope.$on('LinkStatus', function ($event, param) {
            $scope.$apply(function () {
                $rootScope.PAGE_CONFIG.networkConnected = param.link;


            });
        })

        $scope.$on('UpdateShieldStatus',function($event, param){
            $scope.$apply(function () {
                $rootScope.PAGE_CONFIG.yunDunStatus = param.status;
                if(GKPartition.isMountPartition($rootScope.PAGE_CONFIG.partition)){
                    if(GKMount.isYundunMount($rootScope.PAGE_CONFIG.mount)){
                        $rootScope.$broadcast('UpdateFileList');
                    }
                }
            });
        })

        if (!localStorageService.get('silde_guide_shown')) {
            $scope.showSildeGuide = true;
            localStorageService.add('silde_guide_shown', true);
        }

        if (!localStorageService.get('show_new_guide')) {
            $scope.showNewGuide = true;
            localStorageService.add('show_new_guide', true);
        }

        $scope.$on('removeSlideGuide', function () {
            $scope.showSildeGuide = false;
            $scope.showNewGuide = false;
        });

        $scope.$on('editOrgObjectSuccess', function (event, mount) {
            if (!mount) {
                return;
            }
            //如果是隐藏的库，则去除其访问记录
            if (mount.property && mount.property.hide && mount.property.hide == 1) {
                $rootScope.PAGE_CONFIG.visitHistory.removeHistory("", mount.mount_id);
            }
            if ($rootScope.PAGE_CONFIG.mount && $rootScope.PAGE_CONFIG.mount.mount_id == mount.mount_id) {
                angular.extend($rootScope.PAGE_CONFIG.mount, mount)
            }
        })

        $scope.$on('UpdateMembers', function (event, param) {
            $rootScope.$broadcast('UpdateMembersCallback', param);
            var iframe = GKFrame('ifame_chat');
            if (iframe && typeof iframe.gkFrameCallback !== 'undefined') {
                iframe.gkFrameCallback('UpdateMembers', param);
            }
        })

        /**
         * 网站iframe成员管理的回调
         */
        $scope.$on('_inviteMember', function ($event, param) {
            var orgId = param.orgId;
            var mount = GKMount.getMountByOrgId(orgId);
            if (!mount) return;
            $rootScope.$broadcast('UpdateMembers', {mountid: mount.mount_id});
        })

        $scope.$on('_uninviteMember', function ($event, param) {
            var orgId = param.orgId;
            var mount = GKMount.getMountByOrgId(orgId);
            if (!mount) return;
            $rootScope.$broadcast('UpdateMembers', {mountid: mount.mount_id});
        })

        $scope.$on('_editMember', function ($event, param) {
            var orgId = param.orgId;
            var mount = GKMount.getMountByOrgId(orgId);
            if (!mount) return;
            gkClientInterface.editMember({
                mountid: mount.mount_id,
                userid: Number(param.memberId),
                type: Number(param.memberType)
            });
        })

        $scope.$on('_delMember', function ($event, param) {
            var orgId = param.orgId;
            var mount = GKMount.getMountByOrgId(orgId);
            if (!mount) return;
            gkClientInterface.removeMember({
                mountid: mount.mount_id,
                userid: Number(param.memberId)
            });
        })

        $scope.$on('showSelectFileDialog', function ($event, param) {
            var mountId = param.mountId;
            var mount = GKMount.getMountById(mountId);
            if (!mount) {
                return;
            }
            /*if(!GKAuth.check(mount,'','file_write')){
             alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
             return;
             }*/
            GKModal.selectFile(mountId, GKI18n.getText(gettext('请选择添加到哪个目录'))).result.then(function (re) {
                var iframe = GKFrame('ifame_chat');
                if (iframe && typeof iframe.gkFrameCallback !== 'undefined') {
                    angular.extend(re, {
                        list: param.list
                    })
                    iframe.gkFrameCallback('selectAddDirSuccess', re);
                }
                return;
            });
        })

    }])
    .controller('leftSidebar', ['GKI18n', 'gettext', '$scope', '$location', 'GKPath' , 'GKFile', '$rootScope', 'GKSmartFolder', 'GKMount', 'GKFilter', 'GKPartition', 'GKModal', 'GK', 'GKFileList', 'GKFileOpt', 'GKSideTree', 'GKApi', '$q', '$timeout', '$interval', 'localStorageService', 'GKWindowCom', 'GKFrame', 'GKAuth', 'GKMode', function (GKI18n, gettext, $scope, $location, GKPath, GKFile, $rootScope, GKSmartFolder, GKMount, GKFilter, GKPartition, GKModal, GK, GKFileList, GKFileOpt, GKSideTree, GKApi, $q, $timeout, $interval, localStorageService, GKWindowCom, GKFrame, GKAuth, GKMode) {
        var allMounts = GKMount.getMounts(),
            orgMount = GKMount.getOrgMounts(),
            smartFolders = GKSmartFolder.getFolders();

        $scope.browseMode = 'chat';

        $scope.GKPartition = GKPartition;

        /**
         * 我的云库
         */
        $scope.orgTreeList = GKFile.dealTreeData(orgMount, 0);

        /**
         * 企业云库
         */
        $scope.entTreeList = GKSideTree.getTreeList(allMounts);


        /**
         * 智能文件夹
         * @type {*}
         */
//        $scope.smartTreeList = GKFile.dealTreeData(smartFolders,0);

        var allTreeList = $scope.orgTreeList.concat([]);

        angular.forEach($scope.entTreeList, function (val) {
            allTreeList = allTreeList.concat(val.data);
        });
        $scope.allTreeList = allTreeList;

        /**
         * 初始选中
         * @type {*}
         */
        $scope.selectedBranch = null;
        if (!$location.search().partition) {
            $scope.initSelectedBranch = $scope.orgTreeList[0];
        }

        //监听是否转入搜索视图
        $scope.searchText = "";
        $scope.curIsActive = false;
        $scope.$watch(function () {
            return $scope.allTreeList.length;
        }, function (nValue, oValue) {
            $scope.$emit("searchTextChange", $scope.searchText);
        });
        $scope.$on('searchTextChange', function (obj, searchText) {
            if (searchText && searchText.length > 0) {
                $scope.searchTreeList = [];
                angular.forEach($scope.allTreeList, function (treeNode) {
                    if (treeNode.label.toLowerCase().indexOf(searchText.toLowerCase()) != -1) {
                        $scope.searchTreeList.push(treeNode);
                    }
                });
                $rootScope.PAGE_CONFIG.isSearch = true;
            } else {
                $rootScope.PAGE_CONFIG.isSearch = false;
            }
        });
        $scope.$watch("searchText", function (nValue, oValue) {
            $scope.$emit("searchTextChange", nValue);
        });
        //清空搜索
        $scope.clearSearch = function () {
            $scope.searchText = "";
        }
        //end
        $scope.$on('initSelectedBranch', function (obj, branch) {
            if (!branch || angular.equals($scope.selectedBranch, branch)) {
                $timeout(function () {
                    unSelectAllBranch();
                    $scope.allTreeList[0].newMsgTime = new Date().getTime();
                    selectBreanch($scope.allTreeList[0], $scope.allTreeList[0].data.partition, true);
                })
            }
        })

        var unSelectAllBranch = function () {
            if ($scope.selectedBranch) {
                $scope.selectedBranch.selected = false;
                $scope.selectedBranch = null;
            }
        };

        var selectBreanch = function (branch, partition, isListFile) {

            if (!angular.equals($scope.selectedBranch, branch)) {
                branch.selected = true;
                $scope.selectedBranch = branch;
                if (isListFile) {
                    $scope.handleSelect(branch, partition);
                }
            }
        };

        $scope.$on('RemoveMagicObject', function ($event, param) {
            $scope.$apply(function () {
                var code = param.condition;
                GKSmartFolder.removeSmartFolderByCode(code);
//                GKSideTree.removeSmartNode($scope.smartTreeList, code);
            })
        })

        $scope.$on('AddMagicObject', function ($event, param) {
            $scope.$apply(function () {
                var name = param.name,
                    code = param.condition;
                var node = GKSmartFolder.addSmartFolder(name, code);
//                GKSideTree.addSmartNode($scope.smartTreeList, node);
            })
        })

        $scope.$on('editSmartFolder', function ($event, name, code) {
            GKSmartFolder.editSmartFolder(name, code);
//            GKSideTree.editSmartNode($scope.smartTreeList, code, name);
        })

        /**
         * 选中树节点的处理函数
         * @param branch
         */
        $scope.handleSelect = function (branch) {
            var mode = 'file';
            var partition = branch.data.partition;
            var pararm = {
                partition: partition
            };

            if (GKPartition.isMountPartition(partition)) {
                pararm['path'] = branch.data.fullpath;
                pararm['mountid'] = branch.data.mount_id;
                pararm['entid'] = branch.data.ent_id || 0;
                pararm['filter'] = branch.data.filter || '';
                mode = $rootScope.PAGE_CONFIG.mode || 'chat';
            } else if (GKPartition.isSmartFolderPartition(partition)) {
                pararm['filter'] = branch.data.filter;
            } else {
                return;
            }
            GKMode.setMode(mode);
            $timeout(function () {
                $location.search(pararm);
            })
        };

        /**
         * drop to treeNode
         * @param branch
         */
        $scope.handleDrop = function (branch) {
            if ($rootScope.PAGE_CONFIG.partition && "smartfolder" == $rootScope.PAGE_CONFIG.partition) {
                alert(GKI18n.getText(gettext("智能文件夹下的文件不允许此操作")));
                return;
            }
            var selectedFile = GKFileList.getSelectedFile();
            var file = branch.data;
            var toFullpath = file.fullpath,
                toMountId = file.mount_id,
                fromFullpathes = [],
                fromMountId = $rootScope.PAGE_CONFIG.mount.mount_id;

            angular.forEach(selectedFile, function (value) {
                fromFullpathes.push({
                    webpath: value.fullpath
                });
            });

            GKModal.selectFile(file.mount_id, GKI18n.getText(gettext('请选择复制到哪个目录'))).result.then(function (re) {
                GKFileOpt.copy(re.selectedPath, file.mount_id, fromFullpathes, fromMountId);
            });
        };

        /**
         * 企业管理入口
         * @param tree
         */
        $scope.handleHeaderClick = function (tree) {
            var url = gkClientInterface.getUrl({
                sso: 1,
                url: gkClientInterface.getSiteDomain() + '/ent/dispatch?ent_id=' + tree.entId
            });
            gkClientInterface.openUrl(url);
        };

        var selectBranchOnLocationChange = function (param) {

            var branch;
            var mountId = Util.object.getRootMountId(param.mountid);
            if (GKPartition.isTeamFilePartition(param.partition)) {
                angular.forEach($scope.orgTreeList, function (value) {
                    if (value.data.mount_id == mountId) {
                        branch = value;
                        return false;
                    }
                })

            } else if (GKPartition.isSmartFolderPartition(param.partition)) {
                unSelectAllBranch();
                return false;
            } else if (GKPartition.isEntFilePartition(param.partition)) {
                var entId = param.entid;
                if ($scope.entTreeList[entId]) {
                    var list = $scope.entTreeList[entId].data;
                    angular.forEach(list, function (value) {
                        if (value.data.mount_id == mountId) {
                            branch = value;
                            return false;
                        }
                    })
                }
            }
            /**
             * 如果当前的路径分区与选择的节点分区不同，则需要手动unselect已选择的节点
             */
            if (branch && branch != $scope.selectedBranch) {
                unSelectAllBranch();
                selectBreanch(branch, param.partition);
            }
        };

        $scope.$on('$locationChangeSuccess', function () {
            var param = $location.search();
            if (param.search) {
                return;
            }
            var filter = '';
            if ($scope.selectedBranch) {
                filter = $scope.selectedBranch.data.filter || '';
            }
            if (!$scope.selectedBranch) {
                selectBranchOnLocationChange(param);
            } else {
                if ($scope.selectedBranch.data.partition != param.partition) {
                    selectBranchOnLocationChange(param);
                } else {
                    if (GKPartition.isSmartFolderPartition($scope.selectedBranch.data.partition)) {
                        if (filter != param.filter) {
                            selectBranchOnLocationChange(param);
                        }
                    } else {
                        if ($scope.selectedBranch.data.mount_id != param.mountid || $scope.selectedBranch.data.fullpath != param.path || filter != param.filter) {
                            selectBranchOnLocationChange(param);
                        }
                    }
                }
            }
        })

        /**
         * 监控增加云库的回调
         */
        $scope.$on('AddOrgObject', function (event, param, selected) {
            if (!param) {
                return;
            }
            $scope.$apply(function () {
                var newOrg = param;
                if (GKMount.checkMountExsit(newOrg.mountid || newOrg.mount_id)) {
                    return;
                }
                var partition = GKPartition.getPartitionByMountType(newOrg['type'] || newOrg['member_type'], newOrg['ent_id']);
                var mount = GKMount.addMount(newOrg);
                newOrg = GKFile.dealTreeData([mount], 0)[0];
                if (GKPartition.isTeamFilePartition(partition)) {
                    $scope.orgTreeList.push(newOrg);
                    $scope.allTreeList.push(newOrg);
                } else if (GKPartition.isEntFilePartition(partition)) {
                    var entId = mount['ent_id'];
                    if (!$scope.entTreeList[entId]) {
                        var tempData = GKSideTree.getTreeList([mount]);
                        angular.extend($scope.entTreeList, tempData);
                    } else {
                        $scope.entTreeList[entId].data.push(newOrg);

                    }
                    $scope.allTreeList.push(newOrg);
                }
                if (selected) {
                    unSelectAllBranch();
                    selectBreanch(newOrg, partition, true);
                }
            });
        })

        $scope.$on('EditOrgObject', function (event, param) {
            if (!param) {
                return;
            }
            if (!GKMount.checkMountExsit(param.mountid || param.mount_id)) {
                return;
            }
            var editMount = GKMount.formatMountItem(param);
            var newMount = GKMount.editMount(param.mountid || param.mount_id, editMount);
            if (!newMount) {
                return;
            }
            var type = GKPartition.getPartitionByMountType(newMount['type'], newMount['ent_id']);
            var list, allArrItem;
            if (GKPartition.isTeamFilePartition(type)) {
                list = $scope.orgTreeList;
                allArrItem = $scope.allTreeList;
            } else if (GKPartition.isEntFilePartition(type)) {
                var entId = newMount['ent_id'];
                list = $scope.entTreeList[entId]['data'];
                allArrItem = $scope.allTreeList;
            }
            if (!list || !list.length) return;
            if (!allArrItem || !allArrItem.length) return;
            var newNode = GKFile.dealTreeData([newMount], newMount['mount_id'])[0];
            $timeout(function () {
                GKSideTree.editNode(list, newMount['mount_id'], '', newNode);
                GKSideTree.editNode(allArrItem, newMount['mount_id'], '', newNode);
            });
            $rootScope.$broadcast('editOrgObjectSuccess', newMount);
        })

        /**
         * 监控删除云库的回调
         */
        $scope.$on('RemoveOrgObject', function (event, param) {
            $scope.$apply(function () {
                if (!param) {
                    return;
                }
                var mount = null;
                if (param.mountid) {
                    mount = GKMount.getMountById(param.mountid);
                } else if (param.org_id) {
                    mount = GKMount.getMountByOrgId(param.org_id);
                }
                if (!mount) return;
                $rootScope.PAGE_CONFIG.visitHistory.removeHistory("", mount.mount_id);
                var partition = GKPartition.getPartitionByMountType(mount['type'], mount['ent_id']);
                if (GKPartition.isTeamFilePartition(partition)) {
                    GKMount.removeTeamList($scope, mount.org_id);
                } else if (GKPartition.isEntFilePartition(partition)) {
                    GKMount.removeEntFileList($scope, mount.org_id, mount.ent_id);
                }
                var currentMountId = $location.search().mountid;
                if (currentMountId == mount.mount_id) {
                    selectBreanch($scope.orgTreeList[0], GKPartition.teamFile, true);
                }
            });
        })


        /**
         * 创建云库成功
         */
        $scope.$on('createOrgSuccess', function (event, newOrg) {
            if (GKMount.checkMountExsit(newOrg.mountid || newOrg.mount_id)) {
                return;
            }
            //将新增的库添加到库数组中
            var iframe = GKFrame('ifame_chat');
            if (iframe && typeof iframe.gkFrameCallback !== 'undefined') {
                iframe.gkFrameCallback('addOrgSuccess', newOrg);
            }

            var partition = GKPartition.getPartitionByMountType(newOrg['type'], newOrg['ent_id']);
            newOrg = GKFile.dealTreeData([GKMount.addMount(newOrg)], 0)[0];
            if (GKPartition.isTeamFilePartition(partition)) {
                $scope.orgTreeList.push(newOrg);
                $scope.allTreeList.push(newOrg);
            }
            unSelectAllBranch();
            selectBreanch(newOrg, partition, true);
        })

        var setNewMsgTime = function (orgId, newMsgTime, timeType) {
            timeType = angular.isDefined(timeType) ? timeType : 'newMsgTime';
            newMsgTime = parseInt(newMsgTime);
            var mount = GKMount.getMountByOrgId(orgId);
            if (!mount) {
                return;
            }

            if ($scope.browseMode == 'chat') {
                list = $scope.allTreeList;
            } else {
                var partition = GKPartition.getPartitionByMountType(mount['type'], mount['ent_id']);
                var list;
                if (GKPartition.isTeamFilePartition(partition)) {
                    list = $scope.orgTreeList;
                } else if (GKPartition.isEntFilePartition(partition)) {
                    if (!$scope.entTreeList[mount['ent_id']]) {
                        return;
                    }
                    list = $scope.entTreeList[mount['ent_id']].data;
                }
            }
            var extObj = {};
            extObj[timeType] = newMsgTime;
            var node = GKSideTree.editNode(list, mount['mount_id'], '', extObj);
            if (node && (node.newMsgTime > node.visitTime) && ($rootScope.PAGE_CONFIG.mode == 'file' || $rootScope.PAGE_CONFIG.mount.org_id != orgId)) {
                GKSideTree.editNode(list, mount['mount_id'], '', {
                    showNewIcon: true
                });

            } else {
                GKSideTree.editNode(list, mount['mount_id'], '', {
                    showNewIcon: false
                });
            }
        };

        var setChatState = function (list) {
            angular.forEach(list, function (item) {
                var orgId = item.receiver;
                var mount = GKMount.getMountByOrgId(orgId);
                if (!mount) return;
                if (!GKAuth.check(mount, '', 'file_discuss')) {
                    return;
                }
                setNewMsgTime(orgId, item.time);
                var iframe = GKFrame('ifame_chat');
                if (iframe && typeof iframe.gkFrameCallback !== 'undefined') {
                    iframe.gkFrameCallback('chatMessageUpdate', item);
                }
            });
        }

        var chatState = gkClientInterface.getChateState();
        if (chatState && chatState['list']) {
            setChatState(chatState['list']);
        }

        $scope.$on('ChatMessageUpdate', function (event, param) {
            if (!param || !param['list'] || !param['list'].length) {
                return;
            }
            var list = param['list'];
            $scope.$apply(function () {
                setChatState(list);
            });
            $scope.$parent.$broadcast("loadDiscussHistory", list);
        })

        $scope.$on('UpdateScreenshot', function (event, param) {
            var iframe = GKFrame('ifame_chat');
            if (iframe && typeof iframe.gkFrameCallback !== 'undefined') {
                iframe.gkFrameCallback('UpdateScreenshot', param);
            }
        });

        $rootScope.$on('clearMsgTime', function (event, param) {
            var orgId = param.orgId;
            setNewMsgTime(orgId, new Date().getTime(), 'visitTime');
        })
    }])
    .controller('fileBrowser', ['localStorageService', 'GKI18n', 'gettext', '$location', '$interval', 'GKDialog', '$scope', '$filter', 'GKPath', 'GK', 'GKException', 'GKOpt', '$rootScope', '$q', 'GKFileList', 'GKPartition', 'GKFileOpt', '$timeout', 'GKFile', 'GKFileListView', 'GKModal', 'GKAuth', 'GKMount', 'chatService', 'smartSearchConfig', 'GKApi', function (localStorageService, GKI18n, gettext, $location, $interval, GKDialog, $scope, $filter, GKPath, GK, GKException, GKOpt, $rootScope, $q, GKFileList, GKPartition, GKFileOpt, $timeout, GKFile, GKFileListView, GKModal, GKAuth, GKMount, chatService, smartSearchConfig, GKApi) {
        $scope.fileDataArr = null;//文件存储备份
        $scope.oldView = 'list';
        $scope.fileUpdate = {
            isFileUpdateView: false,
            canShow: true,
            fileUpdateView: "fileupdate",
            viewtimes: 0,
            dateline: 0
        }
        $scope.fileData = []; //文件列表的数据
        $scope.errorMsg = '';
        $scope.mountReadable = true;
        $scope.order = '+filename'; //当前的排序
        $scope.allOpts = null;
        $scope.rightOpts = [];
        $scope.showHint = false;
        $scope.totalCount = 0;
        $scope.shiftLastIndex = 0; //shift键盘的起始点
        $scope.search = '';
        $scope.view = 'list';
        $scope.isFile = 0;
        $scope.editorStatus = 0;
        $scope.isEditor = 0;

        var draging = false;
        $scope.$on('closeSyncTools', function () {
            $scope.showHint = false;
        });

        $scope.$on('EditorStatus', function (event, status) {
            $scope.editorStatus = status;
            if(status == 1){
                $timeout(function(){
                    $scope.noteTip = '';
                })
            }
        });

        $scope.$on('OpenFileFinish', function (obj, param) {
            var searchParam = $location.search();
            $rootScope.PAGE_CONFIG.progress = false;
            if (param.mountid != searchParam.mountid || searchParam.path != param.webpath || searchParam.isfile != 1 || searchParam.iseditor != 1) {
                return;
            }
            $rootScope.GKNoteParam = param;
            GKFile.getEditorUrl(param.mountid, param.webpath, $rootScope.GKNoteParam).then(function (url) {
                $scope.filePreviewUrl = url;
            });
        });

        var setBread = function () {
            var param = $location.search();
            if (!param.partition) return;
            $scope.breads = GKPath.getBread($scope);
            $scope.path = $rootScope.PAGE_CONFIG.file.fullpath || '';
        }

        $scope.$on('editSmartFolder', function ($event, name, code, filter) {
            angular.forEach($scope.breads, function (value) {
                if (value.filter == filter) {
                    value.name = name;
                }
            });
        })

        $scope.$on('editOrgObjectSuccess', function (event, mount) {
            if (!mount) {
                return;
            }
            if ($rootScope.PAGE_CONFIG.mount && $rootScope.PAGE_CONFIG.mount.mount_id == mount.mount_id) {
                if ($scope.breads && $scope.breads.length) {
                    angular.extend($scope.breads[0], {
                        logo: mount.logo,
                        name: mount.name
                    })
                }
            }
        })

        var getOpenWithMenu = function (mountId, file, parentItem, topOptKeys) {
            if (!parentItem) return;
            if (!parentItem['items']) {
                parentItem['items'] = {};
            }
            var ext = '.' + file.ext;
            var re = gkClientInterface.getOpenWithMenu({
                'ext': ext
            });
            if (!re) {
                return;
            }
            var list = re['list'];
            if (!list || !list.length) {
                return;
            }
            var subMenu = {};
            angular.forEach(list, function (value, key) {
                var item = {
                    name: value['name'],
                    callback: function () {
                        var mount = GKMount.getMountById(mountId);
                        if (!mount) return;
                        var permissions = GKFile.getFilePermit(mountId, file.fullpath, file);
                        if (!GKAuth.checkPermit(mount, permissions, 'file_read')) {
                            alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                            return;
                        }
                        if (!$rootScope.PAGE_CONFIG.networkConnected && !file.cache) {
                            alert(GKI18n.getText(gettext('该文件无本地缓存，离线状态下无法查看')));
                            return;
                        }
                        gkClientInterface.open({
                            webpath: file.fullpath,
                            mountid: mountId,
                            openpath: value.openpath
                        });
                    }
                }
                var key = 'open_with_' + key;
                topOptKeys.push(key);
                subMenu[key] = item;
            })
            jQuery.extend(parentItem['items'], subMenu);
        };

        var excludeOpts = ['del','file_share','rename','paste','sync', 'set_folder_permit', 'dir_open', 'open_opts', 'default_open', 'open_with', 'base_opts', 'on_line_view', 'view_property', 'order_by', 'link'],
            previewExcludeOpts = ['sync', 'set_folder_permit', 'dir_open', 'on_line_view', 'view_property', 'order_by', 'link'],
            excludeRightOpts = [], //右键要排除的操作
            optKeys,
            topOptKeys,
            excludeRightOpts; // 顶部要排除的操作

        $scope.setOpts = function (selectedFile) {
            selectedFile = angular.isDefined(selectedFile) ? selectedFile : [];
            $scope.allOpts = GKOpt.getAllOpts($scope, selectedFile);
            var searchFlag = 0;
            if ($scope.search.length) {
                searchFlag = 1;
                //如果是高级搜索
                var searchArr = $scope.search.split('|');
                if (searchArr[1] == smartSearchConfig.name) {
                    searchFlag = 2;
                }
            }
            optKeys = GKOpt.getOpts($scope.PAGE_CONFIG.file, selectedFile, $scope.partition, $scope.filter, $scope.PAGE_CONFIG.currentMount, searchFlag, $scope.isEditor);
            $scope.opts = null;
            $scope.opts = [];
            $scope.rightOpts = null;
            $scope.rightOpts = {};
            topOptKeys = [];

            /**
             * 如果选择了文件，那么把currentOpts中的“同步”，“取消同步” 去掉
             */

            if (selectedFile.length) {
                var currentOpts = [];
                currentOpts = GKOpt.getOpts($rootScope.PAGE_CONFIG.file, false, $scope.partition, $scope.filter, $scope.PAGE_CONFIG.mount, searchFlag, $scope.isEditor);
                angular.forEach(['sync', 'unsync'], function (value) {
                    var index = currentOpts.indexOf(value)
                    if (index >= 0) {
                        currentOpts.splice(index, 1);
                    }
                })

                topOptKeys = jQuery.merge(currentOpts, optKeys);
                //topOptKeys = Util.Array.unique(topOptKeys);

                if (selectedFile.length == 1 && selectedFile[0].dir == 0) {
                    getOpenWithMenu(GKFileList.getOptFileMountId(selectedFile[0]), selectedFile[0], $scope.allOpts['open_opts'], topOptKeys);
                }
            } else {
                topOptKeys = optKeys;
                if ($scope.isFile && !$scope.isEditor) {
                    getOpenWithMenu(GKFileList.getOptFileMountId($rootScope.PAGE_CONFIG.file), $rootScope.PAGE_CONFIG.file, $scope.allOpts['open_opts'], topOptKeys);
                }
            }

            if ($scope.fileUpdate.isFileUpdateView) {
                angular.forEach(['sync', 'new_file', 'add'], function (value) {
                    var index = topOptKeys.indexOf(value)
                    if (index >= 0) {
                        topOptKeys.splice(index, 1);
                    }
                })
            }
            //工具条上操作项
            angular.forEach(topOptKeys, function (value) {
                var extOpt = excludeOpts;
                if ($rootScope.PAGE_CONFIG.file.dir == 0 && $rootScope.PAGE_CONFIG.file.fullpath) {
                    extOpt = previewExcludeOpts;
                }
                if (extOpt.indexOf(value) < 0 && value != 'base_opts') {
                    var opt = $scope.allOpts[value];
                    if (opt) {
                        if (opt.items) {
                            var subItems = GKOpt.checkSubOpt(topOptKeys, opt.items);
                            if (jQuery.isEmptyObject(subItems)) {
                                return;
                            } else {
                                opt.items = subItems;
                            }
                        }
                        $scope.opts.push(opt);
                    }

                }
                if(value == 'file_discuss'){
                    if($scope.allOpts['base_opts']){
                        var o = $scope.allOpts['base_opts']['items']['file_discuss'];
                        $scope.opts.push(o);
                    }
                }
                if(value == 'file_history'){
                    if($scope.allOpts['base_opts']){
                        var o = $scope.allOpts['base_opts']['items']['file_history'];
                        $scope.opts.push(o);
                    }
                }

            });
        };


        $scope.triggleOptByShortCut = function (shortcut) {
            var opt = GKOpt.getOptByShortCut($scope.allOpts, shortcut);
            if (opt) {
                opt['callback']();
            }
        };

        /**
         * 改变视图
         */
        $scope.changeView = function (view) {
            GKFileList.changeView($scope, view);
        };

        $scope.$on('changeView', function (event, view) {
            if (arguments.length >= 2) {
                GKFileList.changeView($scope, view);
            } else {
                $scope.$apply(function () {
                    GKFileList.changeView($scope, view);
                })
            }
        })

        var selectedFile;

        $scope.$on('refreshOpt', function ($event) {
            $scope.setOpts(selectedFile);
        })


        $scope.$watch('order', function (newValue) {
            if ($scope.rightOpts && $scope.rightOpts['order_by'] && $scope.rightOpts['order_by']['items']) {
                angular.forEach($scope.rightOpts['order_by']['items'], function (value, key) {
                    if (key == 'order_by_' + $scope.order.slice(1)) {
                        value['className'] = 'current';
                    } else {
                        value['className'] = '';
                    }
                });
            }
            if (!newValue) {
                return;
            }
            var order = newValue;
            var localCompare = false;
            if (newValue.indexOf('filename') >= 0) {
                localCompare = true;
                var desc = newValue.indexOf('-') ? '-' : '+';
                order = [desc + 'dir', newValue];
            }
            var newFileData = $filter('orderBy')($scope.fileData, order, localCompare).concat();
            $scope.fileData = null;
            $scope.fileData = newFileData;
            GKFileList.reIndex($scope.fileData);
        })

        /**
         * 取消收藏
         */
        $scope.$on('unFav', function ($event) {
            GKFileList.removeAllSelectFile($scope);
        })

        $scope.$on('UpdateWebpath', function (event, param) {
            $scope.$apply(function () {
                var upPath = Util.String.dirName(param.webpath);
                if (upPath == $scope.PAGE_CONFIG.file.fullpath) {
                    GKFileList.refreahData($scope);
                }
            });
        })

        /**
         * 监听对文件的操作事件,同步文件列表和左侧的树
         */
        $scope.$on('editFileSuccess', function (event, opt, mountId, fullpath, extraParam) {
            if (!mountId) {
                return;
            }
            var fullpathArr = !angular.isArray(fullpath) ? [fullpath] : fullpath;
            if (!fullpathArr.length) {
                return;
            }
            var forEachFullpath = function (callback) {
                angular.forEach(fullpathArr, function (path) {
                    if (angular.isFunction(callback)) {
                        callback(path);
                    }
                })
            };
            if ($rootScope.PAGE_CONFIG.currentMount.mount_id != mountId) {
                switch (opt) {
                    case 'sync':
                        angular.forEach($scope.fileData, function (value, key) {
                            if (value.submountid == mountId) {
                                value.sync = 1;
                                GKFileListView.updateFileItem(key, value);
                            }
                        });
                        break;
                    case 'unsync':
                        $rootScope.PAGE_CONFIG.file.syncpath = '';
                        $scope.showHint = false;
                        angular.forEach($scope.fileData, function (value, key) {
                            if (value.submountid == mountId) {
                                value.sync = 0;
                                GKFileListView.updateFileItem(key, value);
                            }
                        });
                    case 'del':
                        GKFileList.removeAllSelectFile($scope);
                        angular.forEach($scope.fileData, function (value, key) {
                            if (value.mount_id == mountId) {
                                GKFileList.remove($scope, value);
                            }
                        });
                        break;

                }

            } else if ($rootScope.PAGE_CONFIG.file && fullpathArr[0] === $rootScope.PAGE_CONFIG.file.fullpath) {

                switch (opt) {
                    case 'sync':
                        forEachFullpath(function (fullpath) {
                            if (!fullpath) fullpath = '/';
                            $rootScope.PAGE_CONFIG.file.syncpath = fullpath;
                            $scope.showHint = true;
                        });
                        break;
                    case 'unsync':
                        forEachFullpath(function (fullpath) {
                            $rootScope.PAGE_CONFIG.file.syncpath = '';
                            $scope.showHint = false;
                        });
                        break;
                    case 'del':
                        forEachFullpath(function (fullpath) {
                            GKPath.gotoFile(mountId, Util.String.dirName(fullpath), '', '', '', 'file');
                        });
                        break;
                    case 'create':
                        GKFileList.refreahData($scope, extraParam.fullpath);
                        break;
                    case 'lock':
                        forEachFullpath(function (fullpath) {
                            if(typeof extraParam.lock !== 'undefiend'){
                                $rootScope.PAGE_CONFIG.file.lock = extraParam.lock;
                            }
                            if(typeof extraParam.lock_member_name !== 'undefiend'){
                                $rootScope.PAGE_CONFIG.file.lock_member_name = extraParam.lock_member_name;
                            }
                            if(typeof extraParam.lock_member_id !== 'undefiend'){
                                $rootScope.PAGE_CONFIG.file.lock_member_id = extraParam.lock_member_id;
                            }
                        });
                        break;
                }
            } else {

                var forEachFile = function (callback) {
                    forEachFullpath(function (path) {
                        angular.forEach($scope.fileData, function (value, key) {
                            if (value && value.fullpath === path && angular.isFunction(callback)) {
                                callback(value, key);
                            }
                        });
                    })

                };
                switch (opt) {
                    case 'sync':
                        forEachFile(function (value, key) {
                            value.sync = 1;
                            GKFileListView.updateFileItem(key, value);
                        })
                        break;
                    case 'unsync':
                        forEachFile(function (value, key) {
                            value.sync = 0;
                            GKFileListView.updateFileItem(key, value);
                        })
                        break;
                    case 'del':
                        GKFileList.removeAllSelectFile($scope);
                        forEachFile(function (value) {
                            GKFileList.remove($scope, value);
                        })
                        break;
                    case 'set_open':
                        forEachFile(function (value, key) {
                            value.open = extraParam.open;
                            GKFileListView.updateFileItem(key, value);
                        })
                        break;
                    case 'lock':
                        forEachFile(function (value, key) {
                            value.lock = 2;
                            value.lock_member_name = $rootScope.PAGE_CONFIG.user.member_name;
                            value.lock_member_id = $rootScope.PAGE_CONFIG.user.member_id;
                            GKFileListView.updateFileItem(key, value);
                            $scope.setOpts(GKFileList.getSelectedFile());
                        })
                        break;
                    case 'unlock':
                        forEachFile(function (value, key) {
                            value.lock = 0;
                            value.lock_member_name = '';
                            value.lock_member_id = 0;
                            GKFileListView.updateFileItem(key, value);
                            $scope.setOpts(GKFileList.getSelectedFile());
                        })
                        break;
                }

            }
        })

        $scope.$on('clearTrashSuccess', function (event, mountId) {
            if ($scope.mountId != mountId || $scope.filter != 'trash') {
                return;
            }
            GKFileList.refreahData($scope);
        })

        var loadFiledata = function (param) {
            $scope.setOpts();
            var isFile = $scope.isFile;

            if (isFile) {
                if (!$scope.isEditor) {
                    $scope.filePreviewUrl = GKFile.getFilePreviewUrl($scope.mountId, $scope.path, $rootScope.GKNoteParam);
                }else if($scope.isEditor && gkClientInterface.isWebFengCloud()){
                    GKFile.getEditorUrl($scope.mountId, $scope.path, $rootScope.GKNoteParam).then(function(url){
                        $rootScope.PAGE_CONFIG.progress = false;
                        $scope.filePreviewUrl = url;
                    },function(){
                        $rootScope.PAGE_CONFIG.progress = false;
                    });
                }
            } else {
                $scope.filePreviewUrl = '';
                if (param.view) {
                    GKFileList.changeView($scope, param.view);
                }
                GKFileList.unSelectAll($scope);
                GKFileList.refreahData($scope, param.selectedpath);

                if (GKPartition.isMountPartition($scope.partition)) {
                    //可读权限不能进行拖拽操作
                    $scope.mountReadable = GKAuth.check($rootScope.PAGE_CONFIG.currentMount, '', 'file_read');
                }
                $scope.fileDataLoaded = true;
            }
        };

        var getFileData = function () {
            var param = $location.search();
            if (!param.partition) return;
            $scope.previewFrameLoaded = false;
            $scope.fileDataLoaded = false;
            $scope.path = param.path || '';
            $scope.partition = param.partition || GKPartition.teamFile;
            $scope.filter = param.filter || '';
            $scope.selectedpath = param.selectedpath || '';
            $scope.mountId = Util.object.getCurrentMountId(param.mountid) || Util.object.getCurrentMountId($rootScope.PAGE_CONFIG.fullMountId);
            $scope.search = param.search || '';
            $scope.isFile = param.isfile == 1 ? 1 : 0 || 0;
            $scope.isEditor = param.iseditor == 1 ? 1 : 0 || 0;
            $scope.disableSearch =  $scope.isFile;
            $scope.noteTip = '';

            //判断当前库是否有讨论权限
            $scope.hasDiscussPermit = true;
            var mount = GKMount.getMountById($scope.mountId);
            if(!GKAuth.check(mount, '', 'file_discuss')){
                $scope.hasDiscussPermit = false;
            }

            if (!param.search) {
                $scope.showHint = $rootScope.PAGE_CONFIG.file.syncpath ? true : false;
            }
            $scope.order = "+filename";
            loadFiledata(param);
        };
        //如果在动态模式下，再切换回文件模式需要从新加载数据
        $scope.$watch('PAGE_CONFIG.mode', function (val) {
            if (val == 'file' && !$scope.fileDataLoaded && !$scope.isFile) {
                loadFiledata($location.search());
            }
        })

        $scope.limit = 100;

        $scope.$on('$locationChangeStart', function (event) {
            var searchParam = $location.search();
            if ($scope.isFile && $scope.isEditor) {
                var status = $scope.editorStatus;
                if (status == 1) {
                    if (!confirm('你还有未保存的改动，确定离开当前页面吗？')) {
                        event.preventDefault();
                        return;
                    }
                }
                var mountId = $scope.mountId,
                    path = $scope.path;
                if ($rootScope.PAGE_CONFIG.file.lock > 0 && $rootScope.PAGE_CONFIG.file.lock_member_id == $rootScope.PAGE_CONFIG.user.member_id) {
                    gkClientInterface.toggleLock({
                        status: 0,
                        webpath: path,
                        mountid: mountId
                    }, function () {
                        $timeout(function () {
                            $rootScope.$broadcast('editFileSuccess', 'unlock', mountId, path);
                        }, 100);
                    });
                }
                $scope.editorStatus = 0;
                gkClientInterface.editorExit({
                    mountid: mountId,
                    webpath: path
                })
            }
            if (searchParam.isfile == 1 && searchParam.iseditor == 1 && !gkClientInterface.isWebFengCloud()) {
                GK.open({
                    mountid: parseInt(searchParam.mountid),
                    webpath: searchParam.path,
                    opentype: 'unopen'
                });
            }
            $scope.isFile = 0;
            $rootScope.PAGE_CONFIG.GKNoteParam = null;
            //return;
        })

        $scope.$on('$locationChangeSuccess', function () {
            var param = $location.search();
            $scope.fileUpdate.viewtimes = 0;
            $scope.fileUpdate.dateline = 0;
            $scope.disableSearch = false;
            //记录访问历史
            if ($rootScope.PAGE_CONFIG.mode && $rootScope.PAGE_CONFIG.mode == 'file' && !param.isHistory) {
                var history = $rootScope.PAGE_CONFIG.visitHistory.selectedHistory;
                //如果当前点击的节点跟当前选中的历史节点相同，则不做处理
                var curParam = {};
                for (var pro in history) {
                    if (pro != 'index' && pro != 'selected' && pro != 'isHistory' && pro != 'history_view') {
                        curParam[pro] = history[pro];
                    }
                }
                if (!Util.object.checkObjEquils(param, curParam)) {
                    $rootScope.PAGE_CONFIG.visitHistory.clearHistoryFlag();
                    param.selected = true;
                    param.isHistory = true;
                    param.index = $rootScope.PAGE_CONFIG.visitHistory.historyArr.length;
                    param.history_view = $scope.view;
                    $rootScope.PAGE_CONFIG.visitHistory.selectedHistory = param;
                    $rootScope.PAGE_CONFIG.visitHistory.historyArr.push(param);
                }

            }
            getFileData();
            setBread();
        })

        $scope.getItemClasses = function (file) {
            var classes = {
                //'selected':file.selected
                'nocache' : file.cache==0 && file.dir==0,
                'has_tag':file.property && file.property.tag

            };
            return classes;
        };

        $scope.renameFileSubmit = function (filename, index) {
            if (!GKFile.checkFilename(filename)) {
                return;
            }
            var file = $scope.fileData[index];
            if (!file) return;
            var mountId = GKFileList.getOptFileMountId(file);
            if (filename === file.filename) {
                file.rename = false;
            } else {
                var oldFilePath = file.fullpath;
                var upPath = Util.String.dirName(file.fullpath);
                var newpath = upPath + (upPath ? '/' : '') + filename;
                GK.rename({
                    oldpath: file.fullpath,
                    newpath: newpath,
                    mountid: mountId
                }).then(function () {
                    file.fullpath = newpath;
                    file.filename = filename;
                    file.ext = Util.String.getExt(filename);
                    file.rename = false;
                    GKFileListView.updateFileItem(index, file);
                    $rootScope.PAGE_CONFIG.visitHistory.renameFolderUpdateHistory(file, oldFilePath, newpath);
                }, function (error) {
                    file.rename = false;
                    GKException.handleClientException(error);
                });
            }
        };

        $scope.createFileNameSubmit = function (filename, dir) {
            if (!GKFile.checkFilename(filename)) {
                return;
            }
            var webpath = $scope.path ? $scope.path + '/' + filename : filename;
            var params = {
                webpath: webpath,
                dir: Number(dir),
                mountid: $scope.mountId
            };
            GK.createFolder(params).then(function () {
                $scope.createNewFolder = false;
                $rootScope.$broadcast('editFileSuccess', 'create', $scope.mountId, $scope.path, {fullpath: webpath})
            }, function (error) {
                GKException.handleClientException(error);
            });
        }

        /**
         * 处理点击
         * @param $event
         * @param index
         */
        var maxCount = 20,
            maxMsgTime = 0,
            minMsgTime = 0;
        $scope.$on('updateDiscussHistoryTime', function (obj, re) {
            angular.forEach(re.list, function (item) {
                var time = Number(item.time);
                if (minMsgTime == 0 || time < minMsgTime) {
                    minMsgTime = time;
                }
                if (time > maxMsgTime) {
                    maxMsgTime = time;
                }
            })
        });

        $scope.$on("loadDiscussHistory", function (obj, items) {
            chatService.list($scope.PAGE_CONFIG.mount.org_id, maxMsgTime, maxCount, '').then(function (re) {
                var discussHistoryArr = [];
                if (re && re.list && re.list.length) {
                    angular.forEach(re.list, function (item) {
                        var time = Number(item.time);
                        if (minMsgTime == 0 || time < minMsgTime) {
                            minMsgTime = time;
                        }
                        if (time > maxMsgTime) {
                            maxMsgTime = time;
                        }
                        //如果是当前用户发送的消息，直接过滤

                        if (item.sender != $rootScope.PAGE_CONFIG.user.member_name && item.type && item.type == 'file') {
                            discussHistoryArr.push(item);
                        }
                    });
                    if (discussHistoryArr.length > 0) {
                        $scope.$broadcast("updateDiscussMsg", discussHistoryArr);
                    }
                }
            });
        });


        $scope.handleClick = function ($event, index, file) {
            if ($scope.showDisscussHitoryWin) {
                var mountId = GKFileList.getOptFileMountId(file);
                var mount = GKMount.getMountById(mountId);
                if ((file.submountid && file.submountid != 0 ) || !GKAuth.check(mount, '', 'file_discuss')) {
                    $scope.$broadcast('hideTip');
                    $scope.$broadcast('closeDiscussHistory');
                } else {
                    $scope.$broadcast('showDiscussHistory', file);
                }
            }
            var fileItem = jQuery($event.target).hasClass('item') ? jQuery($event.target) : jQuery($event.target).parents('.item');
            var file = $scope.fileData[index];
            if ($event.ctrlKey || $event.metaKey) {
                if (fileItem.hasClass('selected')) {
                    GKFileList.unSelect($scope, index);
                } else {
                    GKFileList.select($scope, index, true);
                }
            } else if ($event.shiftKey) {
                var lastIndex = $scope.shiftLastIndex;
                GKFileList.unSelectAll($scope)
                if (index > lastIndex) {
                    for (var i = lastIndex; i <= index; i++) {
                        GKFileList.select($scope, i, true);
                    }
                } else if (index < lastIndex) {
                    for (var i = index; i <= lastIndex; i++) {
                        GKFileList.select($scope, i, true);
                    }
                }

            } else {
                //file.selected = true;
                if(fileItem.hasClass('selected')){
                    return;
                }
                GKFileList.select($scope, index);
            }
            if (!$event.shiftKey) {
                $scope.shiftLastIndex = index;
            }
            $event.stopPropagation();
        };

        var renameTimer;

        $scope.showRename = function($event,index){
            if(renameTimer){
                $timeout.cancel(renameTimer);
                renameTimer = null;
                return;
            }
            var selectedFile = GKFileList.getSelectedFile();
            if(selectedFile.length > 1){
                return;
            }
            var fileItem = jQuery($event.target).parents('.item');
            if(!fileItem.hasClass('selected')){
                return;
            }
            renameTimer = $timeout(function(){
                if($scope.allOpts.rename && typeof $scope.allOpts.rename.callback === 'function'){
                    $scope.allOpts.rename.callback();
                    renameTimer = null;
                }
            },300);

        }

        /**
         * 双击文件
         * @param $event
         * @param file
         */
        $scope.handleDblClick = function ($event,file) {
            var checkFolderPermit = function(mountId,path,selectFile){
                if(selectFile.dir == 1) {
                    //判断对文件夹是否有权限
                    var permissions = GKFile.getFilePermit(mountId, path, selectFile);
                    if (!GKAuth.checkPermit(mount, permissions, 'file_preview') && !GKAuth.checkPermit(mount, permissions, 'file_read')){
                        alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                        return false;
                    }
                }
                return true;
            };
            /**
             * 文件夹
             */
            if ($scope.filter == 'trash') {
                return;
            }
            //如果双击的是库
            if (file.submountid && file.submountid != '0') {
                $rootScope.PAGE_CONFIG.fullMountId += "." + file.submountid;
                GKPath.gotoFile($rootScope.PAGE_CONFIG.fullMountId, '');
                return;
            }
            if (file.dir == 1) {
                //如果是高级搜索
                var isSearch = false;
                if ($scope.search && $scope.search.length > 0) {
                    var searchArr = $scope.search.split('|');
                    if (searchArr[1] == smartSearchConfig.name) {
                        isSearch = true;
                    }
                }
                if (GKPartition.isSmartFolderPartition($rootScope.PAGE_CONFIG.partition) || isSearch) {
                    var mountIdPath = null;
                    if (gkClientInterface.isWebFengCloud()) {
                        GKApi.getMountPath(0, GKFileList.getOptFileMountId(file)).success(function (mountArr) {
                            if (!mountArr.list || mountArr.list.length == 0) {
                                return mountId;
                            }
                            var mountIdPath = "";
                            angular.forEach(mountArr.list, function (mount) {
                                mountIdPath += mount.mountid + ".";
                            });
                            if (mountIdPath.length > 0) {
                                mountIdPath = mountIdPath.substring(0, mountIdPath.length - 1);
                            }
                            //验证文件夹权限
                            if(!checkFolderPermit(GKFileList.getOptFileMountId(file),file.fullpath,file)){
                                return false;
                            };
                            GKPath.gotoFile(mountIdPath, file.fullpath);
                        })
                    } else {
                        mountIdPath = GKMount.getMountPath(0, GKFileList.getOptFileMountId(file));
                        //验证文件夹权限
                        if(!checkFolderPermit(GKFileList.getOptFileMountId(file),file.fullpath,file)){
                            return false;
                        };
                        GKPath.gotoFile(mountIdPath, file.fullpath);
                    }

                } else {
                    //如果当前选中了云库
                    if ($rootScope.PAGE_CONFIG.mount.mount_id) {
                        //如果当前没有选中子库
                        if (file.mount_id && (file.mount_id == $rootScope.PAGE_CONFIG.mount.mount_id || $rootScope.PAGE_CONFIG.mount.mount_id == $rootScope.PAGE_CONFIG.currentMount.mount_id)) {
                            //验证文件夹权限
                            if(!checkFolderPermit($rootScope.PAGE_CONFIG.mount.mount_id,file.fullpath,file)){
                                return false;
                            };
                            GKPath.gotoFile($rootScope.PAGE_CONFIG.mount.mount_id, file.fullpath);
                        } else {
                            //验证文件夹权限
                            if(!checkFolderPermit($rootScope.PAGE_CONFIG.currentMount.mount_id,file.fullpath,file)){
                                return false;
                            };
                            //如果当前选中了子库
                            GKPath.gotoFile($rootScope.PAGE_CONFIG.fullMountId, file.fullpath);
                            return;
                        }
                    } else {
                        //如果没有选中的云库
                        if (gkClientInterface.isWebFengCloud()) {
                            GKApi.getMountPath(0, GKFileList.getOptFileMountId(file)).success(function (mountArr) {
                                if (!mountArr.list || mountArr.list.length == 0) {
                                    return mountId;
                                }
                                var mountIdPath = "";
                                angular.forEach(mountArr.list, function (mount) {
                                    mountIdPath += mount.mountid + ".";
                                });
                                if (mountIdPath.length > 0) {
                                    mountIdPath = mountIdPath.substring(0, mountIdPath.length - 1);
                                }
                                //验证文件夹权限
                                if(!checkFolderPermit(GKFileList.getOptFileMountId(file),file.fullpath,file)){
                                    return false;
                                };
                                GKPath.gotoFile(mountIdPath, file.fullpath);
                            })
                        } else {
                            var mountIdPath = GKMount.getMountPath(0, file.mount_id);
                            //验证文件夹权限
                            if(!checkFolderPermit(file.mount_id
                                ,file.fullpath,file)){
                                return false;
                            };
                            GKPath.gotoFile(mountIdPath, file.fullpath);
                        }
                    }
                }
            } else {
                var mountId = GKFileList.getOptFileMountId(file);
                var mount = GKMount.getMountById(mountId);
                if (!mount) return;
                var permissions = GKFile.getFilePermit(mountId, file.fullpath, file);
                if (!GKAuth.checkPermit(mount, permissions, 'file_read')) {
                    alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                    return;
                }
//                if (!GKAuth.checkPermit(mount, permissions, 'file_preview')) {
//                    alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
//                    return;
//                }
                //如果是离线状态，并且这个文件已缓存
                if (!$scope.PAGE_CONFIG.networkConnected && file.cache) {
                    GK.open({
                        mountid: mountId,
                        webpath: file.fullpath
                    });
                    return;
                }
                if (!$scope.PAGE_CONFIG.networkConnected && !file.cache) {
                    alert(GKI18n.getText(gettext('该文件无本地缓存，离线状态下无法查看')));
                    return;
                }
                if(gkClientInterface.isClientOS()){
                    $rootScope.PAGE_CONFIG.progress = true;
                }
                if (file.ext == 'gknote') {
                    GKPath.gotoFile(mountId, file.fullpath, '', '', '', '', 1, 1);
                } else {
                    GK.open({
                        mountid: mountId,
                        webpath: file.fullpath
                    }, function () {
                        $timeout(function(){
                            $rootScope.PAGE_CONFIG.progress = false;
                        })
                    });
                }
            }
            $event.stopPropagation();
        };

        /**
         * 右键文件
         * @param $event
         * @param file
         */
        $scope.handleRightClick = function ($event) {
            var jqTarget = jQuery($event.target);
            var fileItem = jqTarget.hasClass('file_item') ? jqTarget : jqTarget.parents('.file_item');
            if (fileItem.size()) {
                var index = fileItem.index();
                if (!GKFileList.checkIsSelectedByIndex(index)) {
                    GKFileList.select($scope, index);
                }
            } else {
                GKFileList.unSelectAll($scope);
            }
        };

        /**
         * 设置order
         * @param order
         */
        $scope.setOrder = function (order) {
            GKFileList.setOrder($scope, order);
        };

        $scope.openDiscussDialog = function ($event, file) {
            if (file.status == 1) {
                alert(GKI18n.getText(gettext('上传中的文件不能进行讨论')));
                return;
            }
            $scope.$broadcast("showDiscussHistory", file);
            $event.stopPropagation();
        };

        /**
         * unselect all file
         * @param event
         */
        $scope.unSelectAllFile = function (event) {
            var $target = jQuery(event.target);
            if ((['TEXTAREA', 'INPUT', 'BUTTON'].indexOf(event.target.nodeName)) >= 0) {
                return;
            }
            if (!$target.hasClass('file_item') && !$target.parents('.file_item').size()) {
                //如果文件或文件夹讨论历史窗口被打开，则关闭
                if ($scope.showDisscussHitoryWin) {
                    $scope.$broadcast("hideTip");
                    $scope.$broadcast('closeDiscussHistory');
                }
                GKFileList.unSelectAll($scope);
            }
        };

        $scope.dragBegin = function (event, index) {
            var file = $scope.fileData[index];
            if (!file) {
                return;
            }
            if (!GKFileList.checkIsSelectedByIndex(index)) {
                GKFileList.select($scope, index);
            }
            draging = true;
            var selectedFile = GKFileList.getSelectedFile();
            var dragIcon = jQuery('#drag_helper')[0];
            event.dataTransfer.setDragImage(dragIcon, -10, -10);
            var list = [];
            angular.forEach(selectedFile, function (value) {
                value.disableDrop = true;
                var mountId = GKFileList.getOptFileMountId(value);
                var mount = GKMount.getMountById(mountId);
                if (mount && GKAuth.check(mount, '', 'file_read')) {
                    list.push({
                        webpath: value.fullpath,
                        mountid: mountId,
                        filehash: value.filehash
                    })
                }
            });
            list.length && gkClientInterface.setDragStart({
                list: list
            });
        };

        /**drag drop **/
        $scope.getHelper = function () {
            var selectFileName = $scope.fileData[$scope.shiftLastIndex].filename;
            var selectedFile = GKFileList.getSelectedFile();
            var len = selectedFile.length;
            var selectFileName = selectedFile[0].filename;
            var moreInfo = len > 1 ? GKI18n.getReplaceText(gettext(' 等 [0] 个文件或文件夹'), [len]) : '';
            return '<div class="helper">' + selectFileName + moreInfo + '</div>';
        };


        $scope.dragEnd = function (event, index) {
            draging = false;
            var list = [];
            angular.forEach(GKFileList.getSelectedFile(), function (value) {
                value.disableDrop = false;
                var mountId = GKFileList.getOptFileMountId(value);
                var mount = GKMount.getMountById(mountId);
                if (mount && GKAuth.check(mount, '', 'file_read')) {
                    list.push({
                        webpath: value.fullpath,
                        mountid: mountId,
                        filehash: value.filehash
                    })
                }
            });
            list.length && gkClientInterface.setDragEnd({
                list: list
            });
        };

        $scope.handleOver = function (event, index) {
            GKFileListView.hoverItem(index);
        };

        $scope.handleOut = function (event, index) {
            GKFileListView.unhoverItem(index);
        };

        //drop files to folder
        $scope.handleDrop = function (file, index) {
            if (!draging) return;
            var toMountId = $scope.mountId,
                toFullpath = file.fullpath,
                fromMountId = $scope.mountId,
                fromFullpathes = [];

            angular.forEach(GKFileList.getSelectedFile(), function (value) {
                fromFullpathes.push({
                    webpath: value.fullpath
                });
            });
            if (!fromFullpathes.length) {
                return;
            }
            var msg = GKI18n.getReplaceText(gettext('你要将 [0] [1] 复制到还是移动到 [2] 中？'), [Util.String.baseName(fromFullpathes[0]['webpath']), fromFullpathes.length > 1 ? GKI18n.getReplaceText(gettext(' 等 [0] 个文件或文件夹'), [fromFullpathes.length]) : ' ', Util.String.baseName(toFullpath)]);
            var choseModal = GKModal.choseDrag(msg).result.then(function (type) {
                if (type == 'move') {

                    var fromMount = GKMount.getMountById(fromMountId);
                    if (!fromMount) return;
                    var hasPermitFlag = 0;
                    for (var i = 0; i < fromFullpathes.length; i++) {
                        var currentFile = GKFile.getFileInfo(fromMountId, fromFullpathes[i].webpath);
                        var permissions = GKFile.getFilePermit(fromMountId, fromFullpathes[i].webpath, currentFile);
                        if (GKAuth.checkPermit(fromMount, permissions, 'file_delete')) {
                            hasPermitFlag++;
                        } else {
                            break;
                        }
                    }
                    if (hasPermitFlag == fromFullpathes.length) {
                        var toMount = GKMount.getMountById(toMountId);
                        var currentFile = GKFile.getFileInfo(toMountId, toFullpath);
                        var permissions = GKFile.getFilePermit(toMountId, toFullpath, currentFile);
                        if (!GKAuth.checkPermit(toMount, permissions, 'file_write')) {
                            alert(GKI18n.getText(gettext('目标文件夹没有操作权限')));
                            return;
                        }
                    } else {
                        alert(GKI18n.getText(gettext('当前操作的文件或文件夹没有删除权限')));
                        return;
                    }

                    GKFileOpt.move(toFullpath, toMountId, fromFullpathes, fromMountId).then(function () {
                        GKFileList.refreahData($scope);
                    }, function () {

                    });
                } else {

                    var fromMount = GKMount.getMountById(fromMountId);
                    if (!fromMount) return;
                    var hasPermitFlag = 0;
                    for (var i = 0; i < fromFullpathes.length; i++) {
                        var currentFile = GKFile.getFileInfo(fromMountId, fromFullpathes[i].webpath);
                        var permissions = GKFile.getFilePermit(fromMountId, fromFullpathes[i].webpath, currentFile);
                        if (GKAuth.checkPermit(fromMount, permissions, 'file_read')) {
                            hasPermitFlag++;
                        } else {
                            break;
                        }
                    }
                    if (hasPermitFlag == fromFullpathes.length) {
                        var toMount = GKMount.getMountById(toMountId);
                        var currentFile = GKFile.getFileInfo(toMountId, toFullpath);
                        var permissions = GKFile.getFilePermit(toMountId, toFullpath, currentFile);
                        if (!GKAuth.checkPermit(toMount, permissions, 'file_write')) {
                            alert(GKI18n.getText(gettext('目标文件夹没有操作权限')));
                            return;
                        }
                    } else {
                        alert(GKI18n.getText(gettext('当前操作的文件或文件夹没有读取权限')));
                        return;
                    }

                    GKFileOpt.copy(toFullpath, toMountId, fromFullpathes, fromMountId).then(function () {
                        GKFileListView.unhoverItem(index);
                    }, function () {

                    });
                }
            }, function () {
                GKFileListView.unhoverItem(index);
            });
        };

        $scope.handleSysDrop = function ($event) {
            if (gkClientInterface.isWebFengCloud()) {
                return;
            }
            if (draging || !$scope.mountId) return;
            var dragFiles = gkClientInterface.getDragFiles();
            if (GKPartition.isSmartFolderPartition($scope.partition) || GKPartition.isSubscribePartition($scope.partition) || $rootScope.PAGE_CONFIG.filter == 'trash') {
                alert(GKI18n.getText(gettext('不能在当前路径添加文件')));
                return;
            }
            var targetMount = GKMount.getMountById($scope.mountId);
            //如果是拖拽到最近文件更新的视图下
            if ($scope.fileUpdate.isFileUpdateView) {
                GKModal.selectFile($rootScope.PAGE_CONFIG.mount.mount_id, GKI18n.getText(gettext('请选择添加到哪个目录'))).result.then(function (param) {
                    var selectedPath = param.selectedPath;
                    var list = param.list || dragFiles.list;
                    var params = {
                        parent: selectedPath,
                        type: 'save',
                        list: list,
                        mountid: param.mountId
                    };
                    GK.addFile(params).then(function () {
                        //如果是将文件拖拽到当前选中库中
                        if (param.mountId === $rootScope.PAGE_CONFIG.mount.mount_id) {
                            GKFileList.refreahData($scope);
                        }
                    }, function (error) {
                        GKException.handleClientException(error);
                    })
                    return;
                });
                return;
            }


            var permissions = GKFile.getFilePermit($scope.mountId, $scope.path, $rootScope.PAGE_CONFIG.file);
            if (!GKAuth.checkPermit(targetMount, permissions, 'file_write')) {
                alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                return;
            }

            var target = jQuery($event.target);
            var parent = $scope.path;
            var item = target.hasClass('file_item') ? target : target.parents('.file_item');
            if (item.size() && item.data('dir') == 1) {
                parent = item.data('fullpath');
            }
            var params = {
                parent: parent,
                type: 'save',
                list: dragFiles.list,
                mountid: $scope.mountId
            };
            GK.addFile(params).then(function () {
                //if(parent === $scope.path){
                GKFileList.refreahData($scope);
                //}
            }, function (error) {
                GKException.handleClientException(error);
            })
        };

        $scope.goToLocal = function () {
            gkClientInterface.open({
                mountid: Util.object.getCurrentMountId($rootScope.PAGE_CONFIG.fullMountId),
                webpath: $rootScope.PAGE_CONFIG.file.fullpath
            });
        };

        $scope.showSyncSetting = function () {
            GKDialog.openSetting('sync');
        }

        $scope.handleScrollLoad = function () {
            if (GKPartition.isSubscribePartition($scope.partition)) {
                var start = $scope.fileData.length;
                if (start >= $scope.totalCount) return;

                GKFileList.getFileData($scope, {start: start}).then(function (list) {
                    $scope.fileData = $scope.fileData.concat(list);
                })
            } else if (GKPartition.isTeamFilePartition($scope.partition) || GKPartition.isEntFilePartition($scope.partition)) {
                if ($scope.fileUpdate.isFileUpdateView) {
                    $scope.fileUpdate.viewtimes++;
                    GKFileList.scrollLoadFileUpdate($scope);
                }
                $scope.limit += 50;
            }

        }

        $scope.$on('UpdateFileList', function () {
            if ($scope.createNewFolder) { //新建文件（夹）的情况下忽略该回调
                return;
            }
            var selectedFiles = GKFileList.getSelectedFile();

            var selectedPath = [];
            angular.forEach(selectedFiles, function (value) {
                var selectFilePath = value.fullpath;
                if (value.submountid && value.submountid != '0') {
                    selectFilePath = value.submountid + "";
                }
                selectedPath.push(selectFilePath);
            })
            GKFileList.refreahData($scope, selectedPath.join('|'));
        })

        $scope.$on('UpdateFileInfo', function ($event, file) {
            var fileItem = GKFile.formatFileItem(file, 'client');
            var isSelected = false;
            var index;
            $scope.$apply(function () {
                if (GKPartition.isMountPartition($scope.partition)) {
                    if (fileItem.mount_id != $rootScope.PAGE_CONFIG.currentMount.mount_id) return;
                    if(fileItem.fullpath == $rootScope.PAGE_CONFIG.file.fullpath){
                        angular.extend($rootScope.PAGE_CONFIG.file,fileItem);
                    }else{
                        angular.forEach($scope.fileData, function (value, key) {
                            if (value.fullpath === fileItem.fullpath) {
                                angular.extend(value, fileItem);
                                index = key;
                                return false;
                            }
                        })
                    }

                } else if (GKPartition.isSmartFolderPartition($scope.partition)) {
                    if(fileItem.fullpath == $rootScope.PAGE_CONFIG.file.mount_id){
                        angular.extend($rootScope.PAGE_CONFIG.file,fileItem);
                    }else{
                        angular.forEach($scope.fileData, function (value, key) {
                            if (value.fullpath === fileItem.fullpath && value.mount_id == fileItem.mount_id) {
                                angular.extend(value, fileItem);
                                index = key;
                                return false;
                            }
                        })
                    }

                }
            })
            if (index !== undefined) {
                isSelected = GKFileList.checkIsSelectedByIndex(index);
                GKFileListView.updateFileItem(index, fileItem);
                if (isSelected) {
                    $scope.$broadcast('refreshSidebar', '');
                }
            }
        })

        /**
         * ctrlV结束
         */
        $scope.$on('ctrlVEnd', function (event, newFileData) {
            $scope.fileData = $filter('orderBy')(newFileData, $scope.order);
        });

        $scope.$on('LinkStatus', function () {
            $scope.$apply(function () {
                var selectPath = [];
                angular.forEach(GKFileList.getSelectedFile(), function (value) {
                    selectPath.push(value.fullpath);
                })
                GKFileList.refreahData($scope, selectPath.join('|'));
            });
        })

        /**
         * 监听侧边栏的搜索
         */
        $scope.$on('invokeSearch', function ($event) {
            GKFileList.refreahData($scope);
        })

        $scope.$on('OpenMountPath', function ($event, param) {
            if ($scope.view == 'chat' || $scope.view == 'fileupdate') {
                GKFileList.changeView($scope, 'list');
            }
            var mountId = param.mountid,
                fullpath = param.webpath,
                rootMountId = param.rootMountId || 0,
                selectFile = '',
                path = '';
            var mountIdPath = mountId;

            var lastStr = Util.String.lastChar(fullpath);
            if (lastStr === '/') {
                path = Util.String.rtrim(fullpath, '/');
                selectFile = '';
            } else {
                path = Util.String.dirName(fullpath);
                selectFile = fullpath;
            }
            //如果是web端
            if (gkClientInterface.isWebFengCloud()) {
                if (mountId != rootMountId) {
                    GKApi.getMountPath(rootMountId, mountId).success(function (mountArr) {
                        if (!mountArr.list || mountArr.list.length == 0) {
                            return mountId;
                        }
                        var mountIdPath = "";
                        angular.forEach(mountArr.list, function (mount) {
                            mountIdPath += mount.mountid + ".";
                        });
                        if (mountIdPath.length > 0) {
                            mountIdPath = mountIdPath.substring(0, mountIdPath.length - 1);
                        }
                        $timeout(function () {
                            GKPath.gotoFile(mountIdPath, path, selectFile, '', '', 'file');
                        })
                    });
                } else {
                    $timeout(function () {
                        GKPath.gotoFile(mountIdPath, path, selectFile, '', '', 'file');
                    })
                }
            } else {
                if (mountId != rootMountId) {
                    mountIdPath = GKMount.getMountPath(rootMountId, mountId)
                }
                $timeout(function () {
                    GKPath.gotoFile(mountIdPath, path, selectFile, '', '', 'file');
                })
            }
        })

        $scope.$on('$destroy', function () {
            jQuery.contextMenu('destroy', '.file_list .list_body');
        })

        //banner 广告
        var key = 'hide_banner';
        var closeBannerTime = localStorageService.get(key);
        $scope.showBanner = !gkClientInterface.isShOnlineClient() && (!closeBannerTime || new Date().getTime() - parseInt(closeBannerTime) > 86400000) && !GKMount.hasEntMount() && $rootScope.PAGE_CONFIG.user.product_id == 100;
        if ($scope.showBanner) {
            localStorageService.remove(key);
        }
        $scope.closeBanner = function () {
            $scope.showBanner = false;
            localStorageService.add(key, new Date().getTime());
        };

        $scope.goToUpgrade = function () {
            var url = gkClientInterface.getUrl({
                sso: 1,
                url: '/pay/order'
            });
            gkClientInterface.openUrl(url);
        }

    }])
    .controller('header', ['GKI18n', 'gettext', '$scope', 'GKPath', '$location', '$filter', 'GKApi', '$rootScope', '$document', '$compile', '$timeout', 'GKDialog', 'GKFind', 'GKModal', 'GKPartition', 'localStorageService', '$interval', 'GKNews', 'GKConstant', 'GKMode', 'GKLanOptions', 'GKMount', function (GKI18n, gettext, $scope, GKPath, $location, $filter, GKApi, $rootScope, $document, $compile, $timeout, GKDialog, GKFind, GKModal, GKPartition, localStorageService, $interval, GKNews, GKConstant, GKMode, GKLanOptions, GKMount) {
        $scope.langOptions = GKLanOptions.languageOptions;

        $scope.$on('$locationChangeSuccess', function () {
            var param = $location.search();

            if (GKPartition.isSmartFolderPartition($rootScope.PAGE_CONFIG.partition)) {
                $scope.currMount = {
                        name:'智能桌面'
                }
            }else {
                $scope.currMount = GKMount.getMountById(param.mountid);
            }
        });

        $scope.changeLan = function (val) {
            var language = gkClientInterface.getLanguageKey(val);
            localStorageService.add('lan', language);
            location.href = '?hl=' + language;
        };

        $scope.visitBBS = function () {
            var url = gkClientInterface.getUrl({
                sso: 1,
                url: '/account/bbs'
            });
            gkClientInterface.openUrl(url);
        }

        $scope.visitStory = function () {
            var url = gkClientInterface.getUrl({
                sso: 0,
                url: gkClientInterface.getSiteDomain() + '/story'
            });
            gkClientInterface.openUrl(url);
        }

        $scope.goToUpgrade = function () {
            var url = gkClientInterface.getUrl({
                sso: 1,
                url: gkClientInterface.getSiteDomain() + '/pay/order'
            });
            gkClientInterface.openUrl(url);
        }


        $scope.showTrans = !gkClientInterface.isWebFengCloud();
        $scope.showTransferQueue = function () {
            GKDialog.openTransfer();
        }

        $scope.$on('TransferState', function (event, param) {
            $timeout(function () {
                $scope.transfering = param.state;
            })
        })

        var configInfo = gkClientInterface.getConfigInfo();
        var isMenuEnable = function (key) {
            return !configInfo || !$.isArray(configInfo['menu']) || $.inArray(key, configInfo['menu']) > -1;
        };

        $scope.showMenu = function (menuName) {
            var enable = false;
            switch (menuName) {
                case 'upgrade':
                    enable = isMenuEnable('buy') && !gkClientInterface.isWebFengCloud();
                    break;
                case 'trans':
                    enable = isMenuEnable('transport');
                    break;
                case 'bbs':
                    enable = isMenuEnable('bbs');
                    break;
                case 'blog':
                    enable = isMenuEnable('blog');
                    break;
            }
            return enable;
        };

        $scope.items = [
            {
                item: GKI18n.getText(gettext("创建云库")),
                menuclick: function () {
                    var createTeamDialog = GKModal.createTeam();
                }
            },
            {
                item: GKI18n.getText(gettext("设置")),
                menuclick: function () {
                    GKDialog.openSetting();
                }
            },
            {
                item: GKI18n.getText(gettext("帮助")),
                menuclick: function () {
                    var url = gkClientInterface.getUrl({
                        sso: 1,
                        url: '/help'
                    });
                    if(gkClientInterface.isXDFClient()){
                        var config = gkClientInterface.getConfigInfo();
                        if(config.help){
                            url = config.help;
                        }
                    }
                    gkClientInterface.openUrl(url);
                }
            }

        ];

        if(gkClientInterface.isXDFClient()){
            $scope.items.splice(0,1);
        }

        if (gkClientInterface.isShOnlineClient()) {
            $scope.items.splice(2, 1);
        }

        if (!gkClientInterface.isWebFengCloud()) {
            var about = {
                item: GKI18n.getText(gettext("关于")),
                menuclick: function () {
                    gkClientInterface.openAbout();
                }
            };
            $scope.items.push(about);
        }
        var exit = {
            item: GKI18n.getText(gettext("退出")),
            menuclick: function () {
                gkClientInterface.quit();
            }
        };
        $scope.items.push(exit);
    }])
    .controller('rightSidebar', ['GKI18n', 'gettext', '$scope', 'GKFile', 'GKOpen', 'GKFilter', '$rootScope', 'GKApi', '$http', '$location', 'GKFileList', 'GKPartition', 'GKModal', 'GKMount', 'GKSmartFolder', 'GKDialog', 'GKChat', 'GKFrame', 'GKAuth', '$timeout', 'GKSope', 'GKEnt', 'GKMode', function (GKI18n, gettext, $scope, GKFile, GKOpen, GKFilter, $rootScope, GKApi, $http, $location, GKFileList, GKPartition, GKModal, GKMount, GKSmartFolder, GKDialog, GKChat, GKFrame, GKAuth, $timeout, GKSope, GKEnt, GKMode) {
        GKSope.rightSidebar = $scope;
        $scope.GKPartition = GKPartition;
        /**
         * 监听已选择的文件
         */
        $scope.shareMembers = []; //共享参与人
        $scope.remarks = []; //讨论
        $scope.histories = []; //历史
        $scope.localFile = null;
        $scope.sidebar = 'nofile';
        $scope.localFile = $rootScope.PAGE_CONFIG.file;
        $scope.showMemberManageBtn = false;
        $scope.showSync = true;
        $scope.members = [];
        $scope.firstLoadMembers = true;
        $scope.disableLoadingMore = false;
        //右侧动态和详细切换
        $scope.currTab = 'detail';
        var pageNum = 0;
        $scope.loadMembers = true;
        //右侧人员搜索关键字
        $scope.memberKeyword = {
            member_name: ''
        }
        $scope.clearSearch = function () {
            $scope.memberKeyword.member_name = '';
        }

        $scope.changeTab = function (tab) {
            $scope.currTab = tab;
            if (tab == 'dynamic') {
                GKMode.setMode('chat');
            } else {
                GKMode.setMode('file');
            }
        };
        var getSidbarData = function (params) {
            var sideBarData;
            if (params.search) {
                sideBarData = {
                    title: GKI18n.getText(gettext('搜索结果')),
                    tip: '',
                    icon: 'search'
                };
            } else if (params.filter) {
                var filterName = GKSmartFolder.getSmartFoldeName(params.filter);
                sideBarData = {
                    title: filterName,
                    tip: GKFilter.getFilterTip(params.filter),
                    icon: params.filter
                };
            }
            return sideBarData;
        };

        var getRootSidebarData = function (params) {
            var title = $rootScope.PAGE_CONFIG.mount ? $scope.PAGE_CONFIG.mount.name : '';
            var sideBarData = {
                title: title,
                tip: GKI18n.getText(gettext('将文稿，照片，视频等文件保存在我的文件夹里，文件将自动备份到云端。可以使用手机，平板来访问它们，使设备之间无缝，无线连接')),
                photo: "",
                attrHtml: '',
                menus: []
            };
            var currentMount = $rootScope.PAGE_CONFIG.mount;

            var parentFile = gkClientInterface.getFileInfo({
                mountid: currentMount.mount_id,
                webpath: Util.String.dirName($scope.localFile.fullpath)
            });

            if (GKFile.isSynced(parentFile, $scope.localFile)) {
                $scope.showSync = false;
            }
            sideBarData.photo = $rootScope.PAGE_CONFIG.mount.logo;
            sideBarData.tip = $rootScope.PAGE_CONFIG.mount.org_description || '';
            var isYunDun = false;

            if (currentMount.property && currentMount.property.yundun && currentMount.property.yundun == 1) {
                isYunDun = true;
            }
            var syncText = isYunDun ? GKI18n.getText(gettext('同步云盾信息')) : GKI18n.getText(gettext('同步'))
            sideBarData.menus = [
                {icon: 'icon_sync', text: syncText, click: function () {
                    if (gkClientInterface.isWebFengCloud()) {
                        GKModal.openDownload();
                        return;
                    }
                    var currentMountId = $rootScope.PAGE_CONFIG.currentMount.mount_id;
                    if (isYunDun) {
                        gkClientInterface.YUN_DUN.getSheildBindInfo(currentMountId);
                    } else {
                        //获取当前所在的库
                        if (!GKAuth.check(GKMount.getMountById(currentMountId), '', 'file_sync')) {
                            alert(GKI18n.getText(gettext('你没有权限进行当前的操作')));
                            return;
                        }
                        GKModal.sync($rootScope.PAGE_CONFIG.fullMountId, '');
                    }
                }}
            ];
            if (GKPartition.isTeamFilePartition(params.partition) || GKPartition.isEntFilePartition(params.partition)) {
                sideBarData.atrrHtml = GKI18n.getReplaceText(gettext('成员[0]人'), [$rootScope.PAGE_CONFIG.mount.member_count]);
            }
            return sideBarData;
        };

        $scope.hideNoFile = true;

        $scope.sidbarData = getSidbarData($location.search());

        $scope.rootSidebarData = getRootSidebarData($location.search());

        var unSelectSmartFolder = function (list) {
            angular.forEach(list, function (value) {
                value.active = false;
            })
        }


        $scope.$on('$locationChangeSuccess', function () {
            var param = $location.search();
            $scope.members = [];
            $scope.loadMembers = true;
            $scope.memberKeyword.member_name = '';
            $scope.localFile = $rootScope.PAGE_CONFIG.file;
            $scope.rootSidebarData = getRootSidebarData(param);
            $scope.smartSidebar = false;
            $scope.firstLoadMembers = true;
            if ($scope.localFile.submountid && $scope.localFile.submountid != '0') {
                $scope.sidebar = 'submount';
                $scope.hideNoFile = true;
                return;
            }
            $scope.showMemberSearchWrapper = false;
            if (param.path) {
                $scope.sidebar = 'singlefile';
            } else if (param.filter || param.search) {
                $scope.sidebar = 'nofile';
                if (param.search || param.filter == 'trash') {
                    $scope.smartSidebar = false;
                    $scope.sidbarData = getSidbarData(param);
                } else {
                    $scope.smartSidebar = true;
                    $scope.sidebarData = GKSmartFolder.getFolders();
                    angular.forEach($scope.sidebarData, function (value) {
                        value.active = false;
                        value.edit = false;
                        if (value.filter == param.filter) {
                            value.active = true;
                        }
                    });

                    $scope.selectSmartFolder = function (smart) {
                        unSelectSmartFolder($scope.sidebarData);
                        smart.active = true;
                        var pararm = {
                            partition: smart.partition,
                            filter: smart.filter
                        };
                        $timeout(function () {
                            $location.search(pararm);

                        })
                    }
                }
            } else {
                $scope.showMemberSearchWrapper = true;
            }
            $scope.currentTab = 'member';
            $timeout(function () {
                getPendingMembers();
                var _start = $scope.members.length;
                getMember(pageNum,_start,false);
            });
//            if($rootScope.PAGE_CONFIG.mode == 'chat'){
//                $scope.hideNoFile = false;
//                $scope.showMemberSearchWrapper = true;
//            }else{
            if (param.path) {
                $scope.showMemberSearchWrapper = false;
                $scope.hideNoFile = true;
            } else {
                if (param.search || param.filter) {
                    $scope.showMemberSearchWrapper = false;
                    $scope.hideNoFile = true;
                } else {
                    $scope.showMemberSearchWrapper = true;
                    $scope.hideNoFile = false;
                }

            }
            //}
            /**
             * 显示或隐藏成员管理功能
             * @type {boolean}
             */
            $scope.showMemberManageBtn = false;
            if (GKPartition.isTeamFilePartition($rootScope.PAGE_CONFIG.partition)) {
                if (GKMount.isAdmin($rootScope.PAGE_CONFIG.mount) && !gkClientInterface.isXDFClient()) {
                    $scope.showMemberManageBtn = true;
                }
            } else if (GKPartition.isEntFilePartition($rootScope.PAGE_CONFIG.partition)) {
                var ent = GKEnt.getEnt($rootScope.PAGE_CONFIG.entId);
                if (ent && ent.entname) {
                    if (ent.property) {
                        $scope.showMemberManageBtn = GKAuth.check($rootScope.PAGE_CONFIG.mount, '', 'ent_org') && !gkClientInterface.isXDFClient();
                    }
                }
            }
            $scope.isSmartFolder = false;
            if (GKPartition.isSmartFolderPartition($rootScope.PAGE_CONFIG.partition)) {
                $scope.isSmartFolder = true;
                $scope.currTab = 'detail';
            }
            var hasDiscussPermit = GKAuth.check($rootScope.PAGE_CONFIG.mount, '', 'file_discuss');
            GKChat.setSrc($rootScope.PAGE_CONFIG.mount.mount_id,'','',!hasDiscussPermit);
            $scope.gkChat = GKChat;
        })

        $scope.$watch('PAGE_CONFIG.mode', function (val) {
            var param = $location.search();
//            if(val == 'chat'){
//                $scope.showMemberSearchWrapper = true;
//                $scope.hideNoFile = false;
//            }else{
            if (param.path) {
                $scope.showMemberSearchWrapper = false;
                $scope.hideNoFile = true;
            } else {
                if (GKFileList.getSelectedFile().length) {
                    $scope.showMemberSearchWrapper = false;
                    $scope.hideNoFile = true;
                } else {
                    if (param.search || param.filter) {
                        $scope.showMemberSearchWrapper = false;
                        $scope.hideNoFile = true;
                    } else {
                        $scope.showMemberSearchWrapper = true;
                        $scope.hideNoFile = false;
                    }

                }
            }
            //}
        })

        $scope.setRightSidebar = function (selectedFile) {
            if ($rootScope.PAGE_CONFIG.filter == 'trash') {
                return;
            }
//            if($rootScope.PAGE_CONFIG.mode == 'chat'){
//                return;
//            }
            var hideNoFile;
            $scope.selectedFileLength = selectedFile.length;
            if (!selectedFile.length) {
                $scope.localFile = $rootScope.PAGE_CONFIG.file;
                if ($scope.localFile.submountid && $scope.localFile.submountid != '0') {
                    $scope.sidebar = 'submount';
                    $scope.hideNoFile = true;
                    $scope.showMemberSearchWrapper = false;
                }
                else if (!$scope.localFile.fullpath) {
                    $scope.sidebar = 'nofile';
                    if ([GKPartition.teamFile, GKPartition.entFile].indexOf($rootScope.PAGE_CONFIG.partition) >= 0) {
                        $scope.hideNoFile = false;
                        $scope.showMemberSearchWrapper = true;
                    } else {
                        $scope.showMemberSearchWrapper = false;
                        $scope.hideNoFile = true;
                    }
                } else {
                    $scope.showMemberSearchWrapper = false;
                    $scope.sidebar = 'singlefile';
                    $scope.hideNoFile = true;
                }

            } else if (selectedFile.length == 1) {
                $scope.localFile = selectedFile[0];
                if ($scope.localFile.submountid && $scope.localFile.submountid != '0') {
                    $scope.sidebar = 'submount';
                    $scope.showMemberSearchWrapper = false;
                    $scope.hideNoFile = true;
                } else {
                    $scope.sidebar = 'singlefile';
                    $scope.showMemberSearchWrapper = false;
                    $scope.hideNoFile = true;
                }
            } else {
                $scope.localFile = null;
                $scope.sidebar = 'multifile';
                $scope.showMemberSearchWrapper = false;
                $scope.hideNoFile = true;
            }
        }

        $scope.toggleNoFile = function () {
            $scope.hideNoFile = !$scope.hideNoFile;
        }

        $scope.$on('editSmartFolder', function ($event, name, code, filter) {
            if ($scope.filter == filter) {
                $scope.sidbarData.title = name;
            }
        })

        $scope.$on('editOrgObjectSuccess', function (event, mount) {
            if (!mount) {
                return;
            }
            if ($rootScope.PAGE_CONFIG.mount && $rootScope.PAGE_CONFIG.mount.mount_id == mount.mount_id) {
                angular.extend($scope.rootSidebarData, {
                    photo: mount.logo,
                    title: mount.name
                })
            }
        })


        $scope.showAddMember = function () {
            GKModal.teamMember($rootScope.PAGE_CONFIG.mount.mount_id);
        };

        //监听滚动条的滚动
        $scope.handleScrollLoad = function(){
            var pageCount = 51,
                start = $scope.members.length;
            getMember(pageCount,start,true);
        }
        //监听计算第一次出现滚动条的数据条数
        $scope.$on('changeMemberLen',function(obj,len){
            if(len > pageNum) {
                pageNum = (len >= 50)?len:50;
            }else{
                return;
            }
            if($scope.members.length > pageNum){
                return;
            }
            var pageCount = pageNum,
                start = $scope.members.length;
            getMember(pageCount,start,false);
        })
        $scope.$watch('memberKeyword.member_name',function(nVal,oVal){
            $scope.members = [];
            var start = $scope.members.length;
            getMember(pageNum,start,false);
        });
        var getPendingMembers = function(){
            $scope.pendingMembers = [];
            //已经邀请但还未接受的成员
            try {
                GKApi.pendingMembers($rootScope.PAGE_CONFIG.mount.org_id).success(function (data) {
                    $scope.$apply(function () {
                        $scope.pendingMembers = data.members || [];
                    })
                })
            }catch(e){};
        }
        var getMember = function (_pageCount,_start,loadMore) {
            $scope.loadMembers = true;
            $scope.disableLoadingMore = true;
            if(_pageCount == 0) return;
            if (gkClientInterface.isClientOS()) {
                var re = gkClientInterface.getOrgMebersByPage({
                    orgid: $rootScope.PAGE_CONFIG.mount.org_id,
                    start:_start,
                    count:_pageCount,
                    searchkey:$scope.memberKeyword.member_name
                })
                var members = re.list || [];
                members.sort(function (a, b) {
                    if (a.member_id == $rootScope.PAGE_CONFIG.user.member_id) {
                        return -1;

                    } else if (b.member_id == $rootScope.PAGE_CONFIG.user.member_id) {
                        return 1;
                    }
                    else {
                        return Number(a.member_type) - Number(b.member_type);
                    }
                });
                $scope.members=$scope.members.concat(members);
                if(loadMore && members.length < _pageCount - 1){
                    $scope.disableLoadingMore = true;
                }else{
                    $scope.disableLoadingMore = false;
                }
                $scope.loadMembers = false;
                $scope.firstLoadMembers = false;
            } else {
                GKApi.orgMembers($rootScope.PAGE_CONFIG.mount.org_id,_start,_pageCount,$scope.memberKeyword.member_name).success(function (data) {
                    $scope.members=$scope.members.concat(data.members);
                    if(loadMore && data.members.length < _pageCount - 1){
                        $scope.disableLoadingMore = true;
                    }else{
                        $scope.disableLoadingMore = false;
                    }
                    $scope.loadMembers = false;
                    $scope.firstLoadMembers = false;
                }).error(function (request) {
                    $scope.loadMembers = false;
                    $scope.firstLoadMembers = false;
                    alert("网络不稳定，请刷新后重试");
                })
            }
        };

        var getSubscriber = function () {
            GKApi.subscriberList($rootScope.PAGE_CONFIG.currentMount.org_id, 0, 500).success(function (data) {
                $scope.$apply(function () {
                    $scope.memberLoading = false;
                    $scope.subscribers = data.members;
                })
            }).error(function () {
                $scope.$apply(function () {
                    $scope.memberLoading = false;
                })
            })
        };


        $scope.$on('UpdateMembers', function ($event, param) {
            if ($rootScope.PAGE_CONFIG.currentMount.mount_id == param.mountid) {
                $timeout(function () {
                    getMember();
                })
            }
        })

        $scope.showMember = function () {
            GKModal.teamMember($rootScope.PAGE_CONFIG.mount.mount_id);
        };

        $scope.showSubscriber = function () {
            GKModal.teamSubscribe($rootScope.PAGE_CONFIG.mount.org_id);
        };

        $scope.headClick = function () {
            GKModal.teamOverview($rootScope.PAGE_CONFIG.mount.mount_id);
        };

        $scope.showTeamCard = function (member) {
            GKModal.teamCard($rootScope.PAGE_CONFIG.mount.mount_id, member.member_id);
        };

        $scope.atMember = function ($event, member) {
            if (GKMode.getMode() != 'chat') {
                GKMode.setMode('chat');
            }
            var iframe = GKFrame('ifame_chat');

            if (iframe && typeof iframe.gkFrameCallback !== 'undefined') {
                iframe.gkFrameCallback('atMember', member.member_name);
            }
            $event.stopPropagation();
        };
    }])
    .controller('slide', ['$scope', function ($scope) {
        var currentIndex = 0;
        $scope.slides = [];

        if ($scope.showSildeGuide) {
            $scope.showNewGuide = false;
            for (var i = 1; i < 4; i++) {
                $scope.slides.push({
                    image: 'images/guider/firstlogin/guide_' + i + '.png?v=2'
                });
            }
        }
        else if ($scope.showNewGuide) {
            for (var i = 1; i < 8; i++) {
                $scope.slides.push({
                    image: 'images/guider/firstlogin/guide_2_' + i + '.png?v=1'
                });
            }
        }
        $scope.handleClick = function (index) {
            if ($scope.slides[currentIndex]) {
                $scope.slides[currentIndex].active = false;
            }
            $scope.slides[index + 1].active = true;
            currentIndex = index + 1;
        }
        $scope.handleClick(-1);
        $scope.nextCallback = function (index) {
            if (index == 0) {
                $scope.$emit('removeSlideGuide');
                $scope.$destroy();
                return false;
            }
        }
    }])
;



