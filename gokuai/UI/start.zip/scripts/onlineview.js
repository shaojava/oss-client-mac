/**
 * Created by gokuai on 14-5-29.
 */
angular.module('LocalStorageModule').value('prefix', 'gkClientIndex');
angular.module('gkClientOnlineView', ['GKCommon', 'ui.bootstrap','gkClientIndex.directives','gkClientIndex.services','LocalStorageModule'])
    .config(['$sceDelegateProvider',function ($sceDelegateProvider) {
        var siteDomain = gkClientInterface.getSiteDomain();
        $sceDelegateProvider.resourceUrlWhitelist([
            'self',
            'http://127.0.0.1/**',
            'http://localhost/**',
            'http://*.goukuai.cn/**',
            'https://*.goukuai.cn/**',
            'http://*.gokuai.cn/**',
            'https://*.gokuai.cn/**',
            'http://*.gokuai.com/**',
            'https://*.gokuai.com/**',
            'http://*.yunku.cn/**',
            'https://*.yunku.cn/**'
        ])
    }])

    .controller('onLineViewCtrl', ['$scope', '$location', '$rootScope', 'GKApi', function ($scope, $location, $rootScope, GKApi) {
        $rootScope.PAGE_CONFIG = {
            user: gkClientInterface.getUser()
        };
        var param = $location.search();
        $scope.file = param;
        var url = gkClientInterface.getUrl({
              sso:1,
              url:'/app/gk_viewer?header=0&mount_id='+param.mount_id+"&fullpath="+encodeURIComponent(param.fullpath)
        })
        $scope.url = url;

  }])